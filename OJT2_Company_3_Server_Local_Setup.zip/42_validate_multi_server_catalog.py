"""Offline regression: three instances, duplicate DB names, atomic refresh, no business SQL.

Uses synthetic cursor responses and temporary SQLite only. Does not connect to SQL.
"""
from __future__ import annotations

from contextlib import closing
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import sqlite3
import subprocess
import sys
from tempfile import TemporaryDirectory
from types import ModuleType
from unittest.mock import patch

from ojt2_catalog_scope import database_scope_key, resolve_scope, validate_catalog_scope
from ojt2_multi_server import load_config, connection_string, inspect_sources, _legacy, write_snapshot

ROOT=Path(__file__).resolve().parent


class FakeODBC(ModuleType):
    def __init__(self):
        super().__init__('pyodbc')
        self.connections=[]; self.fail=None

    def drivers(self): return ['ODBC Driver 18 for SQL Server']

    def connect(self, cs, timeout):
        label=next(s for s in ('DGA','IT1','IT2') if 'SERVER={'+s+'}' in cs)
        database='master' if 'DATABASE={master}' in cs else 'Empty' if 'DATABASE={Empty}' in cs else 'SharedDB'
        if self.fail==label and database=='SharedDB' or self.fail==label+'_discovery' and database=='master':
            raise Exception('08001','driver diagnostic must not escape')
        cn=FakeConnection(label,database); self.connections.append(cn); return cn


class FakeConnection:
    def __init__(self,label,database):
        self.label=label; self.database=database; self.closed=False; self.queries=[]
    def close(self): self.closed=True
    def cursor(self): return self
    def execute(self, sql):
        self.queries.append(sql)
        if sql=='SELECT @@SERVERNAME, DB_NAME()': self.rows=[(self.label+'\\SQL',self.database)]
        elif 'FROM sys.databases' in sql:
            assert 'database_id > 4' in sql and 'HAS_DBACCESS(name)=1' in sql
            self.rows=[('SharedDB',),('Empty',)]
        elif self.database=='Empty': self.rows=[]
        elif 'FROM sys.columns AS c' in sql:
            self.rows=[(oid,n,name,typ,100,0,0,1,0) for oid in (1,2)
                       for n,(name,typ) in enumerate([('ProjectID','int'),('TowerName','nvarchar')]+([('City','nvarchar')] if self.label!='DGA' else []),1)]
        elif 'FROM sys.sql_expression_dependencies AS d' in sql:
            self.rows=[(2,None,None,'dbo','Project',1,0,0)]
        elif 'FROM sys.objects AS o' in sql:
            self.rows=[(1,'dbo','Project','U ','USER_TABLE',None,None,None),
                       (2,'dbo','vwProject','V ','VIEW',None,None,'CREATE VIEW dbo.vwProject AS SELECT ProjectID, TowerName FROM dbo.Project')]
        else: raise AssertionError('Unexpected/source-business SQL: '+sql)
        return self
    def fetchone(self): return self.rows[0]
    def fetchall(self): return self.rows


def load_reader():
    spec=importlib.util.spec_from_file_location('multi_reader',ROOT/'11_metadata_explorer_streamlit.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod


def main():
    with TemporaryDirectory() as directory:
        temp=Path(directory)
        os.environ['OJT2_APP_DATA_DIR']=str(temp/'app')
        os.environ['OJT2_SEMANTIC_MODEL_PATH']=str(temp/'no_model')
        source={'id':'DGA','server':'DGA','authentication':'sql','username':'reader','password_env':'OJT2_TEST_PASSWORD','databases':'all_accessible'}
        content={'version':1,'catalog_path':str(temp/'catalog.sqlite'),'servers':[dict(source,id=s,server=s) for s in ('DGA','IT1','IT2')]}
        cfg=temp/'servers.json';cfg.write_text(json.dumps(content))
        config=load_config(cfg)
        cs=connection_string(source,'ODBC Driver 18 for SQL Server','db;name','x};PWD=oops')
        assert 'DATABASE={db;name}' in cs and 'PWD={x}};PWD=oops}' in cs
        assert 'Encrypt=yes' in cs and 'TrustServerCertificate=no' in cs
        assert 'Trusted_Connection=yes' in connection_string(dict(source,authentication='windows'),'Driver','db')
        for bad in [dict(source,password='secret'),dict(source,databases=['*']),dict(source,trust_server_certificate='yes')]:
            cfg.write_text(json.dumps(dict(content,servers=[bad])))
            try: load_config(cfg)
            except ValueError: pass
            else: raise AssertionError('Bad config accepted')
        fake=FakeODBC(); logs=[]
        with patch.dict(sys.modules,pyodbc=fake),patch.dict(os.environ,OJT2_TEST_PASSWORD='temporary-not-persisted'):
            inspect_sources(config,mode='list',selected='DGA',odbc=fake,emit=logs.append)
            assert not config['catalog_path'].exists()
            inspect_sources(config,mode='check',odbc=fake,emit=logs.append)
            assert not config['catalog_path'].exists()
            result=inspect_sources(config,mode='sync',odbc=fake,emit=logs.append)
            assert result['objects']==6 and len(result['sources'])==6
            path=config['catalog_path']; digest=hashlib.sha256(path.read_bytes()).hexdigest()
            fake.fail='IT2'
            try: inspect_sources(config,mode='sync',odbc=fake,emit=logs.append)
            except RuntimeError as exc:
                assert '08001' in str(exc) and 'driver diagnostic' not in str(exc)
            else: raise AssertionError('Partial sync accepted')
            assert digest==hashlib.sha256(path.read_bytes()).hexdigest()
            fake.fail='DGA_discovery'
            try: inspect_sources(config,mode='check',odbc=fake,emit=logs.append)
            except RuntimeError as exc: assert 'SQLSTATE=08001' in str(exc) and 'master' in str(exc)
            else: raise AssertionError('Discovery connection failure accepted')
            assert digest==hashlib.sha256(path.read_bytes()).hexdigest()
            fake.fail=None
            try: inspect_sources(config,mode='sync',selected='DGA',odbc=fake,emit=logs.append)
            except ValueError: pass
            else: raise AssertionError('Selected-server partial replacement allowed')
            # Roll back a persistence error, preserving objects + registrations + run.
            with closing(sqlite3.connect(path)) as cn:
                objects=cn.execute('SELECT * FROM catalog_objects').fetchall()
                before=[cn.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in ('catalog_objects','catalog_columns','catalog_runs','catalog_source_scopes')]
            try: write_snapshot(path,_legacy().DDL,'test',[objects[0],objects[0]],[],[],[('DGA','DGA\\SQL','SharedDB')])
            except sqlite3.IntegrityError: pass
            else: raise AssertionError('Duplicate identity accepted')
            with closing(sqlite3.connect(path)) as cn:
                after=[cn.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in ('catalog_objects','catalog_columns','catalog_runs','catalog_source_scopes')]
                assert before==after
        assert all(c.closed for c in fake.connections)
        assert all('temporary-not-persisted' not in s for s in logs)
        subprocess.run([sys.executable,str(ROOT/'09_build_lineage_edges.py'),'--catalog',str(path)],check=True,capture_output=True,text=True)
        reader=load_reader();data=reader.read_catalog(path);index=reader.make_index(data)
        assert len({o['object_key'] for o in data['objects']})==6
        for edge in data['edges']:
            if edge['target_key']:
                assert index['objects'][edge['source_key']]['physical_server']==index['objects'][edge['target_key']]['physical_server']
        options={o['logical_server']:database_scope_key(o) for o in data['objects']}
        assert len(resolve_scope(data['objects'],None))==3
        assert not resolve_scope(data['objects'],[])
        try: resolve_scope(data['objects'],['SharedDB'])
        except ValueError: pass
        else: raise AssertionError('Ambiguous database widened scope')
        from ojt2_adaptive_core import discover,find_supporting
        req={'purpose':'Find tower name','source_hint':'','required_fields':['ProjectID','TowerName']}
        with patch('ojt2_semantic_engine.warm_semantic_cache'):
            hits=discover(data,index,req,[options['DGA']])
            assert hits and {h['object']['logical_server'] for h in hits}=={'DGA'}
            assert discover(data,index,req,[])==[]
            all_hits=discover(data,index,req,None)
            assert {h['object']['logical_server'] for h in all_hits}=={'DGA','IT1','IT2'}
        main=next(h for h in hits if h['object']['object_type']=='V')
        main=dict(main,field_map=[{'requested':'City','actual':None,'status':'MISSING','factor':0.0}])
        support=find_supporting(data,index,main,dict(req,required_fields=['City']),[options['DGA'],options['IT1']])
        assert support and {s['source']['logical_server'] for s in support}=={'IT1'}
        # Persisted source label remains distinguishable for identically named DBs.
        import ojt2_discovery_core as core
        saved=core.save_review(req,hits[0],[],'PIC','Synthetic validation',[options['DGA']],1,path=temp/'history.sqlite')
        record=next(r for r in core.list_reviews(path=temp/'history.sqlite') if r['id']==saved)
        assert 'DGA\\SQL' in record['candidate_fqn']
        # Real catalog can be opened and database selection remains isolated in UI.
        from streamlit.testing.v1 import AppTest
        with patch.dict(os.environ,OJT2_CATALOG_PATH=str(path)):
            app=AppTest.from_file(str(ROOT/'15_adaptive_workflow_streamlit.py')).run(timeout=30)
            assert not app.exception, [e.message for e in app.exception]
            box=next(c for c in app.checkbox if c.label=='Pilih database tertentu')
            box.check().run()
            widget=next(m for m in app.multiselect if m.label=='Database')
            assert len(widget.options)==3 and len(set(widget.options))==3
            widget.set_value([options['DGA']]).run()
            assert not app.exception
            assert app.session_state['custom_dbs']==[options['DGA']]
        # Launcher sets company catalog only in child environment, preserving localhost.
        cfg.write_text(json.dumps(content))
        with patch.object(sys,'argv',['43_start_company_local.py','--config',str(cfg)]),patch('subprocess.call',return_value=0) as launch:
            try: runpy.run_path(str(ROOT/'43_start_company_local.py'),run_name='__main__')
            except SystemExit as exc: assert exc.code==0
            command=launch.call_args.args[0]
            assert command[command.index('--server.address')+1]=='127.0.0.1'
            assert launch.call_args.kwargs['env']['OJT2_CATALOG_PATH']==str(path)
        # Real snapshots cannot bypass registration by editing the scope table.
        with closing(sqlite3.connect(path)) as cn:
            with cn: cn.execute('DELETE FROM catalog_source_scopes')
        try: reader.read_catalog(path)
        except RuntimeError: pass
        else: raise AssertionError('Unregistered real catalog accepted')
        # Old DEMO snapshots remain compatible without new registration.
        with closing(sqlite3.connect(':memory:')) as cn:
            cn.execute('CREATE TABLE catalog_runs(run_id INTEGER)')
            validate_catalog_scope(cn,[{'database_name':'DEMO_Test'}])
    print('PASS: SQL/Windows config, ODBC escaping/TLS defaults, dynamic accessible DB discovery, check/list without writes, 3 physical instances, same-name DB isolation, empty scope, supporting scope, history labels, Streamlit company UI/scope, localhost launcher, connection closure, atomic failures, lineage/reader registration, legacy DEMO compatibility.')


if __name__=='__main__': main()
