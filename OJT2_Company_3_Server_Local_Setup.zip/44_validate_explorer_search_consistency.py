"""Offline regression for object search vs shared field matcher; no SQL connection."""
from __future__ import annotations

from contextlib import ExitStack
import importlib.util
import os
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent


def load_explorer():
    spec=importlib.util.spec_from_file_location('search_consistency_explorer',ROOT/'11_metadata_explorer_streamlit.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def fixture(rows):
    objects=[]; columns=[]
    for row in rows:
        name,names,*extra=row
        server=extra[0] if extra else 'DGA'
        kind=extra[1] if len(extra)>1 else 'U'
        key=f'{server}|SharedDB|dbo|{name}|{kind}'
        obj={'object_key':key,'physical_server':server,'logical_server':server,
             'database_name':'SharedDB','schema_name':'dbo','object_name':name,
             'object_type':kind,'object_type_desc':'USER_TABLE' if kind=='U' else 'VIEW'}
        objects.append(obj)
        columns.extend({'object_key':key,'column_name':n,'sql_type':'int' if n.endswith('ID') else 'nvarchar'} for n in names)
    return {'objects':objects,'columns':columns,'edges':[]}


class ExplorerSearchConsistency(unittest.TestCase):
    def setUp(self):
        from ojt2_field_matching import BASE_TERMS
        self.explorer=load_explorer()
        self.stack=ExitStack();self.addCleanup(self.stack.close)
        self.semantic=self.stack.enter_context(patch('ojt2_semantic_engine.semantic_candidates',return_value=[]))
        self.stack.enter_context(patch('ojt2_field_matching.get_term_rules',return_value=BASE_TERMS))
        self.stack.enter_context(patch('ojt2_field_matching.get_alias_decisions',return_value={}))
        self.stack.enter_context(patch('ojt2_shared_learning.load_shared_feedback',return_value={}))

    def search(self,rows,q,**kwargs):
        data=fixture(rows);index=self.explorer.make_index(data)
        return self.explorer.search_objects(data,index,q,**kwargs)

    def test_literal_and_bilingual_results_are_unioned(self):
        rows=[('KaryawanLegacy',['LegacyText']),('Payroll',['EmployeeName']),('StaffAudit',['PegawaiID']),('Employee',['ID','Name']),('Other',['UnicornSpeed'])]
        for q in ['Karyawan','Pegawai','Employee']:
            with self.subTest(query=q):
                self.assertEqual({o['object_name'] for o in self.search(rows,q)}, {'KaryawanLegacy','Payroll','StaffAudit','Employee'})
        self.semantic.assert_not_called()

    def test_reference_key_and_attribute_options_are_source_evidence(self):
        rows=[('OnlyKey',['EmployeeID']),('OnlyName',['EmployeeName']),('Options',['EmployeeName','EmployeeStatus'])]
        self.assertEqual({o['object_name'] for o in self.search(rows,'Karyawan')},{'OnlyKey','OnlyName','Options'})
        from ojt2_adaptive_core import _field_evidence
        from ojt2_field_matching import BASE_TERMS
        result=_field_evidence([{'column_name':'EmployeeName','sql_type':'nvarchar'}], 'Karyawan',None,
            decisions={},term_rules=BASE_TERMS,shared_feedback={})
        self.assertEqual(result['status'],'ATTRIBUTE_EXTENSION_REVIEW')
        self.assertEqual(result['factor'],0)

    def test_object_names_and_sql_prefixes_work_without_subject_columns(self):
        rows=[(name,['ID','Name']) for name in ['Employee','vwEmployee','tbl_employee_history','dimemployee','Pegawai','Payroll']]
        self.assertEqual({o['object_name'] for o in self.search(rows,'Karyawan')}, {'Employee','vwEmployee','tbl_employee_history','dimemployee','Pegawai'})

    def test_existing_area_and_dictionary_examples_survive(self):
        cases=[('Daerah',[('ScopeOne',['Area']),('Other',['UnicornSpeed'])],{'ScopeOne'}),
               ('Masa Garansi',[('MasaGaransiLegacy',['LegacyText']),('ScopeTwo',['WarrantyPeriod'])],{'MasaGaransiLegacy','ScopeTwo'}),
               ('Kucing',[('CatArchive',['ID']),('Other',['InvoiceDate'])],{'CatArchive'})]
        for q,rows,expected in cases:
            with self.subTest(query=q): self.assertEqual({o['object_name'] for o in self.search(rows,q)},expected)

    def test_id_and_bilingual_field_lookup_still_agree(self):
        data=fixture([('Target',['POID','ContractValue','TowerName'])]);idx=self.explorer.make_index(data)
        for q,col in [('ID PO','POID'),('Nilai Kontrak','ContractValue'),('Nama Tower','TowerName')]:
            self.assertTrue(self.explorer.search_objects(data,idx,q),q)
            self.assertTrue(any(r['Column']==col for r in self.explorer.field_candidates(data,idx,q)),q)

    def test_search_columns_off_still_searches_bilingual_object_names(self):
        rows=[('Employee',['ID']),('Payroll',['EmployeeName'])]
        self.assertEqual({o['object_name'] for o in self.search(rows,'Karyawan',search_columns=False)},{'Employee'})

    def test_filters_and_same_named_object_identity_are_preserved(self):
        rows=[('Records',['EmployeeName'],'DGA','U'),('Records',['UnicornSpeed'],'IT1','U'),('Records',['EmployeeName'],'IT2','V')]
        found=self.search(rows,'Karyawan')
        self.assertEqual({o['logical_server'] for o in found},{'DGA','IT2'})
        self.assertEqual([o['logical_server'] for o in self.search(rows,'Karyawan',logical_server='DGA')],['DGA'])
        self.assertEqual([o['logical_server'] for o in self.search(rows,'Karyawan',object_type='V')],['IT2'])
        self.assertEqual(self.search(rows,'Karyawan',database='NotInScope'),[])

    def test_no_internal_hundred_row_cutoff_for_lexical_results(self):
        rows=[(f'Records{i:03d}',['EmployeeName']) for i in range(130)]
        self.assertEqual(len(self.search(rows,'Karyawan')),130)

    def test_explicit_structural_conflicts_remain_rejected(self):
        rows=[('Other',['WarehouseDestinationID','DistanceM','ContractDate'])]
        for q in ['Warehouse Origin ID','Distance KM','Nilai Kontrak']:
            with self.subTest(query=q): self.assertEqual(self.search(rows,q),[])

    def test_ambiguity_display_cannot_bypass_semantic_retrieval_gate(self):
        data=fixture([('Records',['Alpha','Beta'])]);idx=self.explorer.make_index(data)
        result={'status':'AMBIGUOUS_MATCH_REVIEW','actual':None,'suggestions':[
            {'actual':c,'status':'SEMANTIC_REVIEW','rank_score':s,'evidence':'synthetic semantic'} for c,s in [('Alpha',.82),('Beta',.81)]]}
        with patch('ojt2_adaptive_core._field_evidence',return_value=result):
            self.assertTrue(self.explorer.field_candidates(data,idx,'UnknownConcept'))
            self.assertEqual(self.explorer.field_candidates(data,idx,'UnknownConcept',search_eligible_only=True),[])

    def test_empty_query_lists_all_and_results_are_deterministic(self):
        rows=[('RecordsB',['EmployeeName']),('RecordsA',['EmployeeID'])]
        self.assertEqual([o['object_name'] for o in self.search(rows,'')],['RecordsA','RecordsB'])
        self.assertEqual([o['object_key'] for o in self.search(rows,'Karyawan')],
                         [o['object_key'] for o in self.search(list(reversed(rows)),'Karyawan')])

    def test_streamlit_search_input_keeps_literal_bilingual_and_server_filter(self):
        from streamlit.testing.v1 import AppTest
        import ojt2_adaptive_core
        ui_path=Path(ojt2_adaptive_core.__file__).with_name('15_adaptive_workflow_streamlit.py')
        data=fixture([('KaryawanLegacy',['LegacyText'],'DGA'),('Payroll',['EmployeeName'],'IT1'),('Employee',['ID','Name'],'DGA')])
        code=f'''
import importlib.util
from pathlib import Path
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
ui=load('search_ui',{str(ui_path)!r})
explorer=load('search_explorer',{str(ROOT/'11_metadata_explorer_streamlit.py')!r})
data={data!r}
ui.page_metadata(data,explorer.make_index(data),explorer,True)
'''
        app=AppTest.from_string(code).run(timeout=30)
        self.assertFalse(app.exception)
        next(w for w in app.text_input if w.label=='Search metadata').set_value('Karyawan').run()
        self.assertFalse(app.exception)
        frame=next(w.value for w in app.dataframe if 'Source' in w.value.columns)
        self.assertEqual(len(frame),3)
        next(w for w in app.selectbox if w.label=='Logical Server').set_value('IT1').run()
        self.assertFalse(app.exception)
        frame=next(w.value for w in app.dataframe if 'Source' in w.value.columns)
        self.assertEqual(len(frame),1)
        self.assertTrue(frame['Source'].iloc[0].endswith('dbo.Payroll'))


if __name__=='__main__':
    with TemporaryDirectory() as folder:
        os.environ['OJT2_APP_DATA_DIR']=str(Path(folder)/'app')
        os.environ['OJT2_SEMANTIC_MODEL_PATH']=str(Path(folder)/'no_model')
        unittest.main(verbosity=2)
