"""Local launcher for registered DGA / IT1 / IT2 metadata only."""
from __future__ import annotations
import argparse
import os
from pathlib import Path
from ojt2_multi_server import load_config, inspect_sources


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--config',type=Path,default=Path(os.environ.get('OJT2_SERVER_CONFIG',Path(__file__).with_name('sql_servers.local.json'))))
    mode=cli.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true',help='Read metadata and report visibility; no SQLite writes')
    mode.add_argument('--list-databases',action='store_true',help='List visible online databases only')
    mode.add_argument('--sync',action='store_true',help='Replace configured metadata snapshot only after every configured database succeeds')
    cli.add_argument('--server',help='Optional DGA/IT1/IT2 selector for check/list only')
    args=cli.parse_args()
    try:
        config=load_config(args.config)
        inspect_sources(config,mode='sync' if args.sync else 'list' if args.list_databases else 'check',selected=args.server)
    except (ValueError,RuntimeError,FileNotFoundError) as exc:
        raise SystemExit(str(exc)) from None


if __name__=='__main__': main()
