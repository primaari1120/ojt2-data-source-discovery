# OJT2 — DGA, IT1, IT2 dengan app tetap di localhost

Versi engine: `0.6.2-multi-server-catalog`. Field matching dan rumus ranking tetap menggunakan logic sebelumnya; update ini menambahkan koneksi metadata multi-server, registrasi snapshot, serta scope dan label yang membedakan server fisik.

## 1. Persiapan dan pemasangan

1. Hentikan Streamlit dengan Ctrl+C.
2. Backup folder source yang sedang dipakai dan folder data aplikasi (`%USERPROFILE%\OJT2_Discovery_Data`, atau lokasi `OJT2_APP_DATA_DIR` yang sudah dikonfigurasi). Jangan hapus history, model, atau katalog lama.
3. Ekstrak ZIP ke folder aplikasi yang sudah berisi engine terakhir. Replace hanya file yang ada dalam paket ini. File lain, logo, vocabulary, model, dan venv tetap digunakan. Paket ini bukan full installer.
4. Pastikan laptop dapat mengakses server lewat jaringan kantor/VPN yang sesuai, serta Microsoft ODBC Driver 18 atau 17 for SQL Server tersedia.

Perintah PowerShell dari folder aplikasi, dengan venv lama:

```powershell
.\.venv\Scripts\python.exe -m pip install pyodbc
.\.venv\Scripts\python.exe -c "import pyodbc; print(pyodbc.drivers())"
Copy-Item .\sql_servers.example.json .\sql_servers.local.json
notepad .\sql_servers.local.json
```

`pip install pyodbc` tidak memasang Microsoft ODBC Driver. Bila driver tidak tampil pada perintah kedua, pasang driver Microsoft pada Windows terlebih dahulu melalui installer yang digunakan perusahaan.

## 2. Isi konfigurasi lokal

Template menyiapkan ketiga server dengan SQL Server Authentication dan `databases: "all_accessible"` sesuai kebutuhan user. Isi `server` dan `username` masing-masing. Tidak ada kolom password di JSON.

Contoh bentuk endpoint (contoh saja, bukan alamat perusahaan):

- Host + port: `sql-dga.example.internal,1433`.
- Named instance: `SQL-DGA\\REPORTING` di JSON, yang dibaca menjadi `SQL-DGA\REPORTING`.

Contoh satu entri:

```json
{
  "id": "DGA",
  "server": "sql-dga.example.internal,1433",
  "authentication": "sql",
  "username": "dga_reader",
  "password_env": "OJT2_DGA_PASSWORD",
  "databases": "all_accessible",
  "trust_server_certificate": false
}
```

Biarkan `password_env` belum terisi di environment bila ingin password diminta melalui terminal dengan input tersembunyi. Scanner meminta password satu kali per server per proses. Password tidak ditulis ke JSON, log hasil, atau snapshot.

`all_accessible` mengambil database user dengan `database_id > 4`, ONLINE, `HAS_DBACCESS=1`, dan bukan database snapshot. Ini mencakup database yang dapat dilihat akun; bukan bukti akun mempunyai akses ke setiap database atau setiap tabel di perusahaan. Database sistem dikecualikan. Database kosong/tidak mempunyai objek terlihat diberi warning. Permission SQL tetap menentukan metadata yang terlihat.

Untuk membatasi scope pengambilan metadata, ganti nilai tersebut dengan daftar eksplisit:

```json
"databases": ["Reporting", "MasterData"]
```

TLS memakai `Encrypt=yes` dan validasi sertifikat aktif (`trust_server_certificate: false`). Jika ada error TLS, cocokkan nama host, certificate chain, serta konfigurasi driver dengan IT. `trust_server_certificate: true` tersedia untuk konfigurasi yang memang membutuhkannya, tetapi menonaktifkan validasi identitas sertifikat; jangan menjadikannya perbaikan otomatis untuk semua error.

Opsional: setelah melihat hasil `@@SERVERNAME`, isi `expected_server` agar scanner berhenti jika instance yang tersambung berbeda dari yang diharapkan. `discovery_database` default `master`; dapat diisi database yang diketahui dapat diakses jika akun tidak bisa membuka `master` untuk proses discovery. Timeout koneksi default 15 detik dan query 60 detik, dapat diatur per server dengan `connection_timeout` / `query_timeout`.

## 3. Cek koneksi dahulu, tanpa mengganti katalog

```powershell
.\.venv\Scripts\python.exe .\41_sync_metadata_servers.py --check --server DGA
.\.venv\Scripts\python.exe .\41_sync_metadata_servers.py --check --server IT1
.\.venv\Scripts\python.exe .\41_sync_metadata_servers.py --check --server IT2
```

Password akan diminta di terminal. Hasil mencantumkan server fisik dari `@@SERVERNAME`, jumlah objek/kolom/dependency, dan jumlah definition yang tidak tersedia. `--check` membaca metadata dan tidak membuat/mengganti snapshot SQLite. Definition kosong dapat berarti izin tidak tersedia atau modul terenkripsi; bukan alasan membuat definition palsu.

Untuk hanya melihat daftar database user yang dapat diakses:

```powershell
.\.venv\Scripts\python.exe .\41_sync_metadata_servers.py --list-databases --server DGA
```

Jika terjadi error, bagikan ringkasan SQLSTATE dan tahap/server yang gagal. Jangan mengirim password, connection string berisi password, atau dump definition perusahaan. Scanner menyembunyikan raw diagnostic ODBC karena dapat memuat detail koneksi.

## 4. Buat snapshot perusahaan, bangun lineage, lalu buka app

Setelah ketiga pengecekan berhasil, hentikan app lama jika port 8501 sedang dipakai, lalu:

```powershell
.\.venv\Scripts\python.exe .\43_start_company_local.py --refresh
```

Launcher melakukan:

1. Scan metadata dari seluruh server/database sesuai config.
2. Simpan satu snapshot konsisten hanya setelah semua query yang dijalankan berhasil. Bila koneksi/query salah satu database gagal, snapshot sebelumnya tidak diganti. Database yang tidak terlihat oleh akun tidak ikut discovery.
3. Bangun static lineage pada snapshot perusahaan.
4. Jalankan Streamlit pada `127.0.0.1:8501` dengan `OJT2_CATALOG_PATH` diarahkan ke snapshot perusahaan.

Default lokasi file perusahaan adalah:

```text
%USERPROFILE%\OJT2_Discovery_Data\company_metadata_catalog.sqlite
```

Katalog demo `metadata_catalog.sqlite` tidak diganti pada konfigurasi default. Database history dan feedback tetap memakai lokasi aplikasi yang lama. Tidak ada reset history atau migrasi schema history.

Jika proses lineage gagal setelah metadata tersimpan, metadata baru tetap ada dan lineage bisa stale/belum tersedia. Launcher berhenti sebelum membuka app. Perbaiki penyebabnya, lalu jalankan 09 dengan `--catalog` ke file perusahaan. Atomicity berlaku untuk refresh metadata; proses metadata + lineage bukan satu transaksi bersama.

Sync metadata dapat memakan waktu tergantung jumlah database/objek dan jaringan. Ini terpisah dari waktu Analyze requirement.

## 5. Membuka app berikutnya tanpa mengakses ulang SQL

```powershell
.\.venv\Scripts\python.exe .\43_start_company_local.py
```

Tanpa `--refresh`, launcher memakai snapshot yang sudah ada dan tidak meminta password SQL. Gunakan `--refresh` lagi saat memang ingin memperbarui metadata. Port alternatif:

```powershell
.\.venv\Scripts\python.exe .\43_start_company_local.py --port 8502
```

Jika perlu menjalankan langkah secara terpisah:

```powershell
.\.venv\Scripts\python.exe .\41_sync_metadata_servers.py --sync
$env:OJT2_CATALOG_PATH = Join-Path $env:USERPROFILE 'OJT2_Discovery_Data\company_metadata_catalog.sqlite'
.\.venv\Scripts\python.exe .\09_build_lineage_edges.py --catalog $env:OJT2_CATALOG_PATH
.\.venv\Scripts\python.exe -m streamlit run .\15_adaptive_workflow_streamlit.py --server.address 127.0.0.1
```

Apabila `catalog_path` di config diubah, gunakan path tersebut pada perintah manual. Launcher 43 membaca path otomatis. Launcher tidak mengganti environment/history yang sudah dipakai; jalankan dari terminal dengan konfigurasi aplikasi yang biasa digunakan.

## 6. Perilaku engine yang perlu diperhatikan

- Search Scope menampilkan label logical server, nama database, dan physical instance. Dua database bernama sama pada instance berbeda tetap menjadi pilihan berbeda. Scope kosong tidak otomatis berubah menjadi semua database.
- Source detail/Explorer dan history baru menyertakan identitas server untuk objek non-DEMO. History lama tetap dapat dibaca.
- Scope lama berupa nama database masih didukung bila nama itu hanya ada pada satu instance; jika ambigu, caller harus menggunakan key scope server+database.
- Reader dan builder lineage menerima katalog perusahaan yang terdaftar oleh scanner ini. Guard demo tidak sekadar dihapus tanpa pengganti. Registrasi snapshot bukan sistem autentikasi atau pembatasan hak akun SQL.
- Metadata SELECT dilakukan pada system catalog; scanner tidak melakukan SELECT isi tabel bisnis, menjalankan SP, membuat/merubah objek SQL, JOIN data, atau replikasi. `ApplicationIntent=ReadOnly` adalah hint koneksi, bukan pengganti akun dengan izin sesuai kebutuhan.
- Terlihat pada metadata belum berarti akun dapat SELECT isi objek tersebut. Kesesuaian akses data produksi tetap perlu diperiksa oleh PIC/IT.
- Source utama tetap Table/View; SP digunakan sebagai evidence lineage.
- Cross-server/linked-server alias yang belum dipetakan tetap dapat unresolved. Tidak menebak konektivitas atau menyatakan JOIN lintas server sudah valid.
- Logic tokenisasi, bilingual, semantic opsional, guardrail, evidence fusion, dan bobot ranking dipertahankan.
- Prioritas berurutan DGA -> IT1 -> IT2 belum diaktifkan oleh update koneksi ini. Semua sumber terpilih diranking berdasarkan evidence seperti sebelumnya.
- Banyaknya objek pada scope dapat menambah waktu Analyze; untuk diagnosis real case gunakan scope yang sesuai, lalu bandingkan hasil lintas server.
- Script 07 tetap extractor demo lama. Untuk server perusahaan gunakan 41/43; jangan hanya mengganti host pada script demo.

## 7. Pengujian

Tidak memerlukan server perusahaan untuk regression berikut:

```powershell
.\.venv\Scripts\python.exe .\42_validate_multi_server_catalog.py
.\.venv\Scripts\python.exe .\34_validate_generalized_matching.py
.\.venv\Scripts\python.exe .\36_validate_ranking_performance.py
.\.venv\Scripts\python.exe .\38_validate_field_facet_guards.py
.\.venv\Scripts\python.exe .\40_validate_analysis_runtime.py --ui
```

Validator 42 memakai fake ODBC, metadata sintetis tiga instance dengan nama database sama, serta SQLite temporary. Memeriksa discovery all-accessible, TLS/escaping, tanpa write pada check/list, pembatasan scope, supporting source, atomic failure/rollback, penutupan koneksi, reader/lineage, history label, Streamlit selection, dan launcher localhost. Tidak membuktikan koneksi Windows/VPN/TLS perusahaan sudah berhasil. Koneksi riil harus diperiksa pada laptop user.

Setelah koneksi riil berhasil, pilih beberapa requirement dengan ground truth PIC. Periksa parsing, kelengkapan snapshot, kandidat field, status ambiguity/guardrail, dan ranking secara terpisah sebelum mengubah matcher.

## 8. File dan rollback

Source lama yang berubah: `09_build_lineage_edges.py`, `11_metadata_explorer_streamlit.py`, `15_adaptive_workflow_streamlit.py`, `ojt2_adaptive_core.py`, `ojt2_gap_engine.py`, `ojt2_discovery_core.py`.

Modul/launcher baru: `ojt2_catalog_scope.py`, `ojt2_multi_server.py`, `41_sync_metadata_servers.py`, `42_validate_multi_server_catalog.py`, `43_start_company_local.py`. Paket juga menyertakan script 07 yang digunakan sebagai sumber schema/SELECT extractor, contoh konfigurasi, petunjuk ignore, README, dan manifest hash file.

`sql_servers.local.json` adalah file lokal berisi endpoint/login; jangan commit atau masukkan ke paket publik. Tambahkan baris dari `.gitignore.multi_server.example` ke `.gitignore` yang sudah ada, jangan overwrite seluruh aturan ignore lama.

Rollback: hentikan app, pulihkan file source dari backup, dan jalankan app dengan path katalog demo/lama. Launcher hanya mengatur path snapshot pada child process. Di terminal yang pernah mengatur `OJT2_CATALOG_PATH` manual, hapus/ubah variabel itu sesuai katalog yang ingin dipakai. Snapshot perusahaan tidak perlu dihapus; history lama tetap dipertahankan.
