"""OJT 2 - Smart Data Source Discovery: Local metadata extractor (Stage 1).

Read-only SQL Server scans for five synthetic DEMO databases.
Stores a transactional metadata snapshot in a persistent SQLite file outside the app source directory.

This stage inventories references; it DOES NOT infer verified READS_FROM or WRITES_TO lineage.
Tested by syntax validation; actual SQL execution must be checked on the user's local instance.
"""
from __future__ import annotations

import getpass
import re
import sqlite3
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

try:
    import pyodbc
except ImportError as exc:
    raise SystemExit("pyodbc belum tersedia. Install: .\\.venv\\Scripts\\python.exe -m pip install pyodbc") from exc

# IMPORTANT: Synthetic demo only. These are logical labels, NOT three physical SQL servers.
REGISTERED_DATABASES = {
    "DEMO_DGA_Reporting": "DGA",
    "DEMO_DGA_Master": "DGA",
    "DEMO_IT_Operations": "IT",
    "DEMO_IT_DataTemp": "IT",
    "DEMO_HR_Reference": "HR",
}
SQL_SERVER = r"lpc:.\SQLEXPRESS"  # Shared Memory on the SAME Windows computer
CATALOG_PATH = Path.home() / "OJT2_Discovery_Data" / "metadata_catalog.sqlite"

OBJECT_SQL = """
SELECT o.object_id, s.name AS schema_name, o.name AS object_name,
       o.type, o.type_desc, o.create_date, o.modify_date, m.definition
FROM sys.objects AS o
INNER JOIN sys.schemas AS s ON s.schema_id = o.schema_id
LEFT JOIN sys.sql_modules AS m ON m.object_id = o.object_id
WHERE o.is_ms_shipped = 0
  AND o.type IN ('U','V','P','FN','IF','TF')
ORDER BY s.name, o.name;
"""

COLUMN_SQL = """
SELECT c.object_id, c.column_id, c.name AS column_name,
       t.name AS sql_type, c.max_length, c.precision, c.scale,
       c.is_nullable, c.is_identity
FROM sys.columns AS c
INNER JOIN sys.types AS t ON t.user_type_id = c.user_type_id
INNER JOIN sys.objects AS o ON o.object_id = c.object_id
WHERE o.is_ms_shipped = 0 AND o.type IN ('U','V','IF','TF')
ORDER BY c.object_id, c.column_id;
"""

DEPENDENCY_SQL = """
SELECT DISTINCT d.referencing_id, d.referenced_server_name,
       d.referenced_database_name, d.referenced_schema_name,
       d.referenced_entity_name, d.referenced_id,
       d.is_ambiguous, d.is_caller_dependent
FROM sys.sql_expression_dependencies AS d
INNER JOIN sys.objects AS o ON o.object_id = d.referencing_id
WHERE o.is_ms_shipped = 0
  AND o.type IN ('V','P','FN','IF','TF')
ORDER BY d.referencing_id, d.referenced_database_name,
         d.referenced_schema_name, d.referenced_entity_name;
"""

DDL = """
CREATE TABLE IF NOT EXISTS catalog_objects (
    object_key TEXT PRIMARY KEY,
    logical_server TEXT NOT NULL,
    physical_server TEXT NOT NULL,
    database_name TEXT NOT NULL,
    schema_name TEXT NOT NULL,
    object_name TEXT NOT NULL,
    object_type TEXT NOT NULL,
    object_type_desc TEXT NOT NULL,
    definition_status TEXT NOT NULL,
    sql_definition TEXT,
    created_at TEXT,
    modified_at TEXT,
    indexed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS catalog_columns (
    object_key TEXT NOT NULL,
    column_id INTEGER NOT NULL,
    column_name TEXT NOT NULL,
    sql_type TEXT NOT NULL,
    max_length INTEGER,
    numeric_precision INTEGER,
    numeric_scale INTEGER,
    is_nullable INTEGER,
    is_identity INTEGER,
    PRIMARY KEY (object_key, column_id),
    FOREIGN KEY (object_key) REFERENCES catalog_objects(object_key)
);
CREATE TABLE IF NOT EXISTS catalog_dependencies (
    dependency_id INTEGER PRIMARY KEY AUTOINCREMENT,
    referencing_key TEXT NOT NULL,
    referenced_server TEXT,
    referenced_database TEXT,
    referenced_schema TEXT,
    referenced_object TEXT,
    referenced_object_id INTEGER,
    is_ambiguous INTEGER,
    is_caller_dependent INTEGER,
    relation_status TEXT NOT NULL DEFAULT 'REFERENCE_ONLY',
    FOREIGN KEY (referencing_key) REFERENCES catalog_objects(object_key)
);
CREATE TABLE IF NOT EXISTS catalog_runs (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    indexed_at TEXT NOT NULL,
    physical_server TEXT NOT NULL,
    database_count INTEGER NOT NULL,
    object_count INTEGER NOT NULL,
    column_count INTEGER NOT NULL,
    dependency_count INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_object_name ON catalog_objects(object_name);
CREATE INDEX IF NOT EXISTS idx_object_database ON catalog_objects(database_name, schema_name);
CREATE INDEX IF NOT EXISTS idx_column_name ON catalog_columns(column_name);
CREATE INDEX IF NOT EXISTS idx_dep_referencing ON catalog_dependencies(referencing_key);
CREATE INDEX IF NOT EXISTS idx_dep_target ON catalog_dependencies(referenced_database, referenced_object);
"""


def choose_driver() -> str:
    options = [d for d in pyodbc.drivers() if re.fullmatch(r"ODBC Driver \d+ for SQL Server", d)]
    if not options:
        raise RuntimeError("Microsoft ODBC Driver SQL Server tidak ditemukan. Cek pyodbc.drivers().")
    return max(options, key=lambda d: int(re.search(r"\d+", d).group()))


def connection_string(driver: str, password: str, database: str) -> str:
    # Password is requested interactively. It is never printed or saved to the catalog.
    # ODBC braces safely allow passwords containing semicolons.
    safe_password = password.replace("}", "}}")
    return (f"DRIVER={{{driver}}};SERVER={SQL_SERVER};DATABASE={database};"
            f"UID=sa;PWD={{{safe_password}}};Encrypt=yes;TrustServerCertificate=yes;")


def key_for(server: str, database: str, schema: str, name: str, obj_type: str) -> str:
    # Object identity is FULLY qualified to avoid collisions between databases.
    return "|".join([server, database, schema, name, obj_type])


def extract_database(driver: str, password: str, database: str,
                     logical_server: str, physical_server: str, timestamp: str):
    """Read metadata only; nothing is executed/modified in the source database."""
    with pyodbc.connect(connection_string(driver, password, database), timeout=15) as cn:
        cn.timeout = 45
        cur = cn.cursor()
        cur.execute("SELECT DB_NAME()")
        if cur.fetchone()[0] != database:
            raise RuntimeError(f"Database context berbeda dari yang diharapkan: {database}")
        raw_objects = cur.execute(OBJECT_SQL).fetchall()
        raw_columns = cur.execute(COLUMN_SQL).fetchall()
        raw_dependencies = cur.execute(DEPENDENCY_SQL).fetchall()

    object_keys = {}
    obj_rows, col_rows, dep_rows = [], [], []
    for obj in raw_objects:
        oid, schema, name, kind, kind_desc, created, modified, definition = obj
        key = key_for(physical_server, database, schema, name, kind)
        object_keys[oid] = key
        definition_status = ("NOT_APPLICABLE_TABLE" if kind == "U" else
                             "AVAILABLE" if definition is not None else "UNAVAILABLE_OR_NO_PERMISSION")
        obj_rows.append((key, logical_server, physical_server, database, schema,
                         name, kind, kind_desc, definition_status, definition,
                         str(created) if created else None, str(modified) if modified else None,
                         timestamp))
    for c in raw_columns:
        oid, column_id, name, typ, length, precision, scale, nullable, identity = c
        if oid in object_keys:
            col_rows.append((object_keys[oid], column_id, name, typ, length,
                             precision, scale, int(nullable), int(identity)))
    for d in raw_dependencies:
        (referencing_id, referenced_server, referenced_database, referenced_schema,
         referenced_entity, referenced_id, ambiguous, caller_dependent) = d
        if referencing_id in object_keys:
            # A null database name in this view indicates a local-DB reference.
            dep_rows.append((object_keys[referencing_id], referenced_server,
                             referenced_database or database, referenced_schema,
                             referenced_entity, referenced_id, int(ambiguous),
                             int(caller_dependent), "REFERENCE_ONLY"))
    return obj_rows, col_rows, dep_rows


def run():
    print("OJT 2 - Metadata Catalog Extractor | Hanya untuk SQL Server lokal SQLEXPRESS")
    driver = choose_driver()
    print("ODBC driver:", driver)
    password = getpass.getpass("Password SQL Server lokal (sa): ")
    if not password:
        raise RuntimeError("Password kosong.")

    # Guard against accidentally scanning production / a different instance.
    with pyodbc.connect(connection_string(driver, password, "master"), timeout=15) as cn:
        cur = cn.cursor()
        cur.execute("SELECT @@SERVERNAME, CONVERT(nvarchar(128), SERVERPROPERTY('InstanceName'))")
        physical_server, instance_name = cur.fetchone()
        if (instance_name or "").upper() != "SQLEXPRESS":
            raise RuntimeError("Safety stop: instance bukan SQLEXPRESS lokal.")
        existing = {row[0]: row[1] for row in cur.execute(
            "SELECT name, state_desc FROM sys.databases WHERE name LIKE N'DEMO[_]%'").fetchall()}
        missing = [db for db in REGISTERED_DATABASES if existing.get(db) != "ONLINE"]
        if missing:
            raise RuntimeError(f"Safety stop: database demo tidak ONLINE / tidak terlihat: {missing}")

    print("Connected to:", physical_server, "| Instance:", instance_name)
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    all_obj, all_cols, all_dep = [], [], []
    for db, logical_server in REGISTERED_DATABASES.items():
        print(f"Scanning {db} [{logical_server}] ...")
        obj, cols, deps = extract_database(driver, password, db, logical_server,
                                           physical_server, timestamp)
        all_obj.extend(obj)
        all_cols.extend(cols)
        all_dep.extend(deps)
        print(f"  {len(obj)} objects | {len(cols)} columns | {len(deps)} dependencies")

    # Persist only after ALL five database scans succeeded.
    # Previous snapshot remains intact if an extraction fails.
    CATALOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(CATALOG_PATH) as sq:
        sq.execute("PRAGMA foreign_keys=ON")
        sq.executescript(DDL)
        try:
            sq.execute("BEGIN IMMEDIATE")
            sq.execute("DELETE FROM catalog_dependencies")
            sq.execute("DELETE FROM catalog_columns")
            sq.execute("DELETE FROM catalog_objects")
            sq.executemany("""INSERT INTO catalog_objects VALUES
                (?,?,?,?,?,?,?,?,?,?,?,?,?)""", all_obj)
            sq.executemany("""INSERT INTO catalog_columns VALUES
                (?,?,?,?,?,?,?,?,?)""", all_cols)
            sq.executemany("""INSERT INTO catalog_dependencies
                (referencing_key,referenced_server,referenced_database,referenced_schema,
                 referenced_object,referenced_object_id,is_ambiguous,is_caller_dependent,
                 relation_status) VALUES (?,?,?,?,?,?,?,?,?)""", all_dep)
            sq.execute("""INSERT INTO catalog_runs
                (indexed_at, physical_server, database_count, object_count,
                 column_count, dependency_count) VALUES (?,?,?,?,?,?)""",
                (timestamp, physical_server, len(REGISTERED_DATABASES),
                 len(all_obj), len(all_cols), len(all_dep)))
            sq.commit()
        except Exception:
            sq.rollback()
            raise

    print("\n=== EXTRACTION SUCCESS ===")
    print("SQLite catalog:", CATALOG_PATH)
    print("Database count:", len(REGISTERED_DATABASES))
    print("Object types:", dict(Counter(row[6] for row in all_obj)))
    print("Objects:", len(all_obj), "| Columns:", len(all_cols),
          "| References:", len(all_dep))
    print("NOTE: REFERENCE_ONLY belum membuktikan READS_FROM / WRITES_TO / GENERATED_BY.")
    print("NOTE: SQLite berisi source SQL definition, jadi simpan sebagai data internal demo.")


if __name__ == "__main__":
    try:
        run()
    except Exception as exc:
        print("\nEXTRACTION FAILED:", exc)
        raise SystemExit(1)
