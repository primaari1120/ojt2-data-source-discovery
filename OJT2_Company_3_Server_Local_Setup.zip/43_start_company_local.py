"""Run Streamlit on localhost with the configured company catalog.

--refresh scans all configured SQL sources, builds static lineage, then starts UI.
No --refresh reuses the existing company snapshot without any SQL connection.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import subprocess
import sys
from ojt2_multi_server import load_config


def main():
    root=Path(__file__).resolve().parent
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--config',type=Path,default=Path(os.environ.get('OJT2_SERVER_CONFIG',root/'sql_servers.local.json')))
    cli.add_argument('--refresh',action='store_true')
    cli.add_argument('--port',type=int,default=8501)
    args=cli.parse_args()
    if not 1<=args.port<=65535: raise SystemExit('Port harus antara 1 dan 65535.')
    try: config=load_config(args.config)
    except (ValueError,FileNotFoundError) as exc: raise SystemExit(str(exc)) from None
    env=dict(os.environ,OJT2_CATALOG_PATH=str(config['catalog_path']))
    if args.refresh:
        steps=[['41_sync_metadata_servers.py','--config',str(args.config.resolve()),'--sync'],
               ['09_build_lineage_edges.py','--catalog',str(config['catalog_path'])]]
        for command in steps:
            result=subprocess.run([sys.executable,str(root/command[0]),*command[1:]],cwd=root,env=env)
            if result.returncode: raise SystemExit(result.returncode)
    if not config['catalog_path'].is_file():
        raise SystemExit('Snapshot perusahaan belum ada. Jalankan launcher dengan --refresh setelah koneksi berhasil diperiksa.')
    print('Local app catalog:',config['catalog_path'])
    print('History tetap memakai OJT2_APP_DATA_DIR / lokasi aplikasi yang sudah digunakan.')
    raise SystemExit(subprocess.call([sys.executable,'-m','streamlit','run',str(root/'15_adaptive_workflow_streamlit.py'),
        '--server.address','127.0.0.1','--server.port',str(args.port)],cwd=root,env=env))


if __name__=='__main__': main()
