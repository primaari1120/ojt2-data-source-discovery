"""Universal, metadata-only candidate source-gap & JOIN-key evidence engine.

Does not connect to SQL Server, execute joins/SP, infer FK/uniqueness or certify
semantic equivalence. All evidence is unverified hypothesis for PIC review.
Uses the shared field-matching engine, and the existing graph metadata catalog.
"""
from __future__ import annotations
from ojt2_catalog_scope import database_scope_key, resolve_scope
from collections import defaultdict
from typing import Any
from ojt2_discovery_core import norm
from ojt2_field_matching import (
    BASE_TERMS, IDENTIFIER_TOKENS, field_suggestions, get_alias_decisions,
    get_term_rules, split_tokens,
)

ALIAS_STATUSES = {
    'NAME_MATCH','REGISTERED_ALIAS_REVIEW','CURATED_ALIAS_REVIEW',
    'BUSINESS_ALIAS_REVIEW','ABBREVIATION_ALIAS_REVIEW',
    'FUZZY_ALIAS_REVIEW','UNIT_ALIAS_REVIEW','BILINGUAL_CONCEPT_REVIEW','BILINGUAL_LEXICON_REVIEW',
}
UNRESOLVED = {'MISSING','UNRESOLVED_DERIVED','REFERENCE_KEY_REVIEW',
              'ATTRIBUTE_EXTENSION_REVIEW','MULTIPLE_ATTRIBUTE_OPTIONS_REVIEW',
              'OBJECT_CONTEXT_REVIEW','ACTOR_ATTRIBUTE_REVIEW','EVENT_SEMANTIC_REVIEW',
              'FORMULA_DEFINITION_REVIEW','ANNOTATION_CONTEXT_REVIEW',
              'MULTIPLE_CONTEXT_OPTIONS_REVIEW','SEMANTIC_REVIEW',
              'CROSS_DOMAIN_FEEDBACK_REVIEW','SAME_DOMAIN_FEEDBACK_REVIEW',
              'QUALIFIED_ATTRIBUTE_REVIEW','IDENTIFIER_GRAIN_REVIEW',
              'AMBIGUOUS_MATCH_REVIEW','POTENTIAL_MATCH_REVIEW'}
KEY_TOKENS = {'id', 'key', 'code', 'number'}


def _is_key(name: str, terms: dict[str,str]) -> bool:
    wordset = set(split_tokens(name, terms))
    return bool(wordset & KEY_TOKENS) or norm(name).endswith(('id','key','code','no','numb','number'))


def _type_family(name: str) -> str:
    n = (name or '').lower().strip()
    if n in {'tinyint','smallint','int','bigint'}: return 'integer'
    if n in {'char','varchar','nchar','nvarchar','text','ntext','sysname'}: return 'text'
    if n in {'decimal','numeric','money','smallmoney','float','real'}: return 'numeric'
    if n in {'date','datetime','datetime2','smalldatetime','datetimeoffset'}: return 'date'
    if n in {'uniqueidentifier'}: return 'guid'
    return n or 'unknown'


def _key_candidates(main_cols: list[dict], supp_cols: list[dict],
                    domain: str|None, terms: dict[str,str],
                    decisions: dict, source_key: str) -> list[dict]:
    options=[]
    for left in main_cols:
        left_name=left['column_name']
        if not _is_key(left_name,terms): continue
        proposals=field_suggestions(supp_cols,left_name,domain=domain,
                                    object_key=source_key,decisions=decisions,terms=terms,
                                    limit=15,include_semantic=False, include_shared_feedback=False)
        pairs = [(right,'EXACT_NAME',1.0) for right in supp_cols
                 if norm(right['column_name']) == norm(left_name)]
        pairs += [(right,s['status'],s['rank_score']) for s in proposals
                  for right in supp_cols if right['column_name']==s['actual']
                  and s['status'] not in {'REFERENCE_KEY_REVIEW','IDENTIFIER_GRAIN_REVIEW',
                  'QUALIFIED_ATTRIBUTE_REVIEW','ATTRIBUTE_EXTENSION_REVIEW'}]
        for right,reason,match_score in pairs:
            right_name=right['column_name']
            if not _is_key(right_name,terms):continue
            ltype, rtype=_type_family(left.get('sql_type','')),_type_family(right.get('sql_type',''))
            compatible=ltype==rtype and ltype!='unknown'
            if not compatible: continue  # Do not propose an unsafe implicit CAST
            tokens=set(split_tokens(left_name,terms))
            specificity=len(tokens-KEY_TOKENS)
            # A narrower identifier is preferable as a probe hypothesis, but
            # unique-ness must still be measured on the actual source data.
            specificity_bonus=min(.07,.025*max(0,specificity-1))
            type_bonus=.02 if left.get('sql_type','').lower()==right.get('sql_type','').lower() else 0
            key_grade= 0.88 if 'id' in tokens else 0.76 if 'code' in tokens else 0.69
            score=round(min(.99,.52*float(match_score)+.42*key_grade+specificity_bonus+type_bonus),3)
            options.append({
                'main_column':left_name,'support_column':right_name,
                'status':'PROPOSED_JOIN_KEY_NOT_VERIFIED',
                'match_type':reason,'ranking_signal':score,
                'main_sql_type':left.get('sql_type'), 'support_sql_type':right.get('sql_type'),
                'type_compatible':True,
                'evidence':f'{reason}; datatype family={ltype}; key-name similarity only.',
                'cardinality_status':'NOT_MEASURED','uniqueness_status':'NOT_MEASURED',
            })
    dedup={}
    for p in options:
        k=(p['main_column'],p['support_column'])
        if k not in dedup or dedup[k]['ranking_signal']<p['ranking_signal']:dedup[k]=p
    return sorted(dedup.values(),key=lambda x:(-x['ranking_signal'],x['main_column'],x['support_column']))


def _upstream(index:dict,object_key:str, depth:int=4)->set[str]:
    visited={object_key}
    frontier={object_key}
    for _ in range(depth):
        next_nodes=set()
        for node in frontier:
            for edge in index.get('forward',{}).get(node,[]):
                if edge.get('relation_type') in {'READS_FROM','GENERATED_BY'}:
                    dest=edge.get('target_key')
                    if dest in index['objects'] and dest not in visited:next_nodes.add(dest)
        if not next_nodes:break
        visited.update(next_nodes);frontier=next_nodes
    return visited


def _same_origin(index:dict,main_key:str,support_key:str)->tuple[bool,list[str]]:
    """View on output table is not an *independent* supporting source."""
    left=_upstream(index,main_key)
    right=_upstream(index,support_key)
    # Direct view -> physical output or vice versa; do not claim equality for
    # arbitrary shared input parents / dimension tables.
    directly_dependent=(support_key in left or main_key in right)
    overlap=(left-{main_key})&(right-{support_key})
    return directly_dependent, sorted(overlap)[:3]


def _backing_source_key(index:dict,source_key:str)->str:
    """Only collapse a View with a single directly read physical table."""
    obj=index['objects'].get(source_key,{})
    if obj.get('object_type','').strip()!='V':return source_key
    direct=[e.get('target_key') for e in index.get('forward',{}).get(source_key,[])
            if e.get('relation_type')=='READS_FROM' and e.get('target_key') in index['objects']]
    if len(direct)==1 and index['objects'][direct[0]]['object_type'].strip()=='U':
        return direct[0]
    return source_key


def generalized_supporting(data:dict,index:dict,candidate:dict,requirement:dict,
                           allowed_databases:list[str]|None=None,
                           limit_per_field:int=12)->list[dict]:
    """Propose all relevant alternative sources; flag missing join evidence.

    Never assumes DGA/IT physical separation or treats lineage as FK proof.
    Does not include out-of-scope sources. Generic for any tables/views/domains.
    """
    # Local import avoids circular dependency with ojt2_adaptive_core wrapper.
    from ojt2_adaptive_core import _field_evidence, plan_search
    domain=plan_search(requirement)['domain']
    terms=get_term_rules(domain)
    decisions=get_alias_decisions(domain)
    from ojt2_shared_learning import load_shared_feedback
    shared_feedback=load_shared_feedback()
    allow=resolve_scope(data['objects'], allowed_databases)
    main=candidate['object']
    main_key=main['object_key']
    main_cols=index['columns'].get(main_key,[])
    missing=[x['requested'] for x in candidate['field_map'] if x['status'] in UNRESOLVED]
    support=[]
    for required in missing:
        matches=[]
        for obj in data['objects']:
            sk=obj['object_key']
            if database_scope_key(obj) not in allow or sk==main_key or obj['object_type'].strip() not in {'U','V'}:continue
            cols=index['columns'].get(sk,[])
            result=_field_evidence(cols,required,domain,sk,decisions,terms,
                                   object_name=obj['object_name'],
                                   business_context=requirement.get('purpose',''),
                                   source_hint=requirement.get('source_hint',''),
                                   shared_feedback=shared_feedback)
            review_only={'ATTRIBUTE_EXTENSION_REVIEW','OBJECT_CONTEXT_REVIEW',
                        'ACTOR_ATTRIBUTE_REVIEW','EVENT_SEMANTIC_REVIEW',
                        'FORMULA_DEFINITION_REVIEW','ANNOTATION_CONTEXT_REVIEW',
                        'SEMANTIC_REVIEW','CROSS_DOMAIN_FEEDBACK_REVIEW',
                        'SAME_DOMAIN_FEEDBACK_REVIEW',
                        'QUALIFIED_ATTRIBUTE_REVIEW','IDENTIFIER_GRAIN_REVIEW'}
            if result['status'] not in ALIAS_STATUSES | review_only or not result.get('actual'):continue
            keys=_key_candidates(main_cols,cols,domain,terms,decisions,sk)
            same_origin,shared_ancestry=_same_origin(index,main_key,sk)
            # The physical identity can also be recovered from fully qualified object_key.
            # This fallback helps synthetic fixture tests which omit physical_server.
            main_physical=main.get('physical_server') or (main_key.split('|')[0] if main_key.count('|')>=4 else None)
            support_physical=obj.get('physical_server') or (sk.split('|')[0] if sk.count('|')>=4 else None)
            same_physical=bool(main_physical and support_physical and main_physical==support_physical)
            if same_origin:
                status='SAME_LINEAGE_NOT_INDEPENDENT'
            elif not keys:
                status='NO_JOIN_KEY_EVIDENCE'
            elif not same_physical:
                status='CROSS_SERVER_CONNECTIVITY_REVIEW'
            elif len(keys)>1 and keys[0]['ranking_signal']-keys[1]['ranking_signal']<0.06:
                status='MULTIPLE_JOIN_KEYS_REVIEW'
            else:
                status='JOIN_KEY_PROPOSED_UNVERIFIED'
            matched_key=keys[0] if keys else None
            potential=(bool(keys) and not same_origin and same_physical
                       and result['status'] not in review_only)
            quality={'NAME_MATCH':1,'REGISTERED_ALIAS_REVIEW':.88,'BUSINESS_ALIAS_REVIEW':.75,
                     'ABBREVIATION_ALIAS_REVIEW':.7,'CURATED_ALIAS_REVIEW':.7,
                     'UNIT_ALIAS_REVIEW':.58,'FUZZY_ALIAS_REVIEW':.48,
                     'ATTRIBUTE_EXTENSION_REVIEW':.22,'OBJECT_CONTEXT_REVIEW':.22,
                     'ACTOR_ATTRIBUTE_REVIEW':.22,'EVENT_SEMANTIC_REVIEW':.1,
                     'FORMULA_DEFINITION_REVIEW':.15,'ANNOTATION_CONTEXT_REVIEW':.15,
                     'SEMANTIC_REVIEW':.14,
                     'CROSS_DOMAIN_FEEDBACK_REVIEW':.19,
                     'SAME_DOMAIN_FEEDBACK_REVIEW':.21}.get(result['status'],.4)
            ranking=round(100*(.45*quality+.38*(matched_key['ranking_signal'] if matched_key else 0)
                     +.12*int(same_physical)+.05*int(bool(shared_ancestry))
                     -.22*int(same_origin)),1)
            matches.append({
                'source_family':_backing_source_key(index,sk),
                'missing_field':required,'source':obj,'actual_field':result['actual'],
                'match_status':result['status'],'match_evidence':result['evidence'],
                'join_candidates':keys[:8],'join_status':status,
                'shared_id_candidates':[p['main_column'] for p in keys],
                'suggested_key':matched_key,'same_lineage_source':same_origin,
                'shared_ancestry':shared_ancestry,
                'same_physical_server':same_physical,
                'same_logical_server':obj.get('logical_server')==main.get('logical_server'),
                'potentially_joinable':potential,'needs_join_validation':True,
                'priority':ranking,'cardinality_status':'NOT_MEASURED',
                'data_access_status':'METADATA_ONLY',
                'warnings':[
                    'Join keys inferred from names; not proven foreign keys or business links.',
                    'Check base grain, duplicate keys, null keys and filter predicates before approval.',
                    *(['Business attribute qualifier differs from request; PIC must clarify the intended field.']
                      if result['status'] in review_only else []),
                    *(['Same lineage may duplicate an existing source.'] if same_origin else []),
                    *(['Cross-server access/replication may be needed; do not assume linked servers.'] if not same_physical else []),
                ]})
        # Group different Views and physical tables representing the same backing
        # output source; present both as alternatives, not independent coverage.
        families=defaultdict(list)
        for m in matches:families[m['source_family']].append(m)
        for family,members in families.items():
            for m in members:
                m['alternative_from_same_source']=len(members)>1
                if len(members)>1:
                    m['warnings'].append('Another suggested View/Table reads this same underlying source.')
        support.extend(sorted(matches,key=lambda m:(-int(m['potentially_joinable']),-m['priority'],m['source']['object_name']))[:limit_per_field])
    return support


def summarize(candidate:dict,support:list[dict])->dict:
    proposed={s['missing_field'] for s in support if s['potentially_joinable']}
    unresolved=[r['requested'] for r in candidate['field_map'] if r['status'] in UNRESOLVED and r['requested'] not in proposed]
    return {
        'direct':candidate['matched'],'alias_proposed':candidate['alias_proposed'],
        'proposal_direct':candidate['mapped_proposed'],'total':candidate['total'],
        'reference_key_suggestions':sum(m['status']=='REFERENCE_KEY_REVIEW' for m in candidate['field_map']),
        'potential':min(candidate['total'],candidate['mapped_proposed']+len(proposed)),
        'unresolved':unresolved,'status':'NEEDS_JOIN_AND_BUSINESS_VALIDATION' if proposed else 'PARTIAL_OR_UNRESOLVED',
        'supported_fields_unverified':len(proposed),'runtime_validated_fields':0,
    }
