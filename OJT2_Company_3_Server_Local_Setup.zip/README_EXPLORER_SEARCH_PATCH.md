# Patch konsistensi pencarian objek Metadata Explorer

Basis: update multi-server lokal `0.6.2-multi-server-catalog`.

## Penyebab yang direproduksi

Matcher sudah mengenali vocabulary `Karyawan`, `Pegawai`, dan `Employee`. Masalah berada di jalur retrieval Search objek:

1. Pencarian bilingual sebelumnya dilewati bila satu hasil literal sudah ditemukan. Contoh: KaryawanLegacy ditemukan, lalu Payroll yang mempunyai EmployeeName tidak ikut dicari.
2. Threshold umum 0,76 menyembunyikan hubungan sumber yang valid tetapi bukan alias field langsung. ATTRIBUTE_EXTENSION_REVIEW mendapat sinyal 0,73; REFERENCE_KEY_REVIEW dapat mendapat 0,70. Hubungan tersebut layak menunjukkan sumber terkait, tetapi tetap tidak memenuhi field secara otomatis.
3. Fallback sebelumnya menilai kolom saja. Nama objek Employee dengan kolom ID/Name generik belum mendapat pencarian bilingual pada nama objeknya.

## Perubahan

- Hasil literal dan hasil lexical/bilingual digabung, termasuk saat hasil literal sudah tersedia.
- Nama objek dan span tokennya ditelusuri menggunakan tokenizer, vocabulary, kamus offline, serta field matcher yang sudah ada. Prefiks teknis SQL membantu segmentasi identifier. Tidak menambah pasangan vocabulary atau aturan khusus Karyawan/Employee/Daerah.
- Kolom memakai matcher bersama. Proposal key/attribute/unit/grain dapat menjadi evidence untuk menemukan sumber, tanpa dinaikkan menjadi approved mapping atau coverage.
- Deduplikasi dan retrieval memakai ObjectKey, menjaga pemisahan objek bernama sama pada server berbeda.
- Filter server, database, tipe objek, dan opsi include-column tetap berlaku. Tidak ada batas internal 100 hasil untuk jalur lexical yang membuang sumber lain.
- Semantic fallback tetap konservatif dan hanya dipakai bila tidak ada hasil literal/lexical; pencarian lexical yang berhasil tidak memanggil embedding. Status tampilan ambiguity tidak dapat melewati gate semantic proposal aslinya.
- Field Finder tetap menggunakan `_field_evidence`, seperti Analyze dan Gap. Matcher, dictionary, bobot ranking, database, serta koneksi SQL tidak diubah oleh patch ini.

Contoh fixture offline:

| Query | Sumber yang bisa ditemukan |
|---|---|
| Karyawan / Pegawai / Employee | Tabel Employee; tabel lain dengan Employee, EmployeeName, EmployeeID, PegawaiID; nama objek seperti vwEmployee atau tbl_employee_history |
| Daerah | Sumber dengan kolom Area |
| Masa Garansi | Sumber dengan WarrantyPeriod, termasuk ketika ada sumber bernama MasaGaransiLegacy |
| ID PO / Nilai Kontrak / Nama Tower | Sumber dengan POID / ContractValue / TowerName |

Hasil bergantung pada metadata snapshot, filter aktif, term rules/PIC, dan vocabulary yang tersedia. Pencarian tidak menjamin setiap hubungan bisnis dapat diketahui dari nama metadata saja. EmployeeID sebagai petunjuk sumber tidak berarti nilai employee/name sudah tersedia.

## Pemasangan

1. Hentikan Streamlit dengan Ctrl+C.
2. Backup `11_metadata_explorer_streamlit.py` yang sedang dipakai.
3. Replace **hanya** `11_metadata_explorer_streamlit.py` dengan file dari ZIP ini.
4. `44_validate_explorer_search_consistency.py` adalah validator baru yang opsional untuk dijalankan, bukan bagian launcher app.
5. Jalankan ulang aplikasi dengan launcher yang biasa digunakan. Untuk katalog perusahaan:

```powershell
.\.venv\Scripts\python.exe .\43_start_company_local.py
```

Tidak perlu `--refresh`, membangun ulang metadata, menghapus history, atau mengunduh ulang model untuk patch pencarian ini. Restart proses diperlukan agar helper Explorer yang di-cache dibaca ulang.

Untuk instalasi yang belum menggunakan update multi-server terakhir, pasang update multi-server tersebut dahulu karena file Explorer mengimpor helper scope dari update itu.

## Regression

```powershell
.\.venv\Scripts\python.exe .\44_validate_explorer_search_consistency.py
.\.venv\Scripts\python.exe .\34_validate_generalized_matching.py
.\.venv\Scripts\python.exe .\42_validate_multi_server_catalog.py
```

Validator 44 memakai fixture lintas istilah, kamus offline, metadata sintetis, dan Streamlit AppTest; tanpa SQL Server dan tanpa model embedding. Memeriksa union literal+bilingual, hubungan key/attribute tanpa coverage, nama objek/prefiks, Area, terjemahan dari kamus luas, field ID/bilingual, filter multi-server dengan nama objek sama, >100 hasil, konflik unit/direction/type, semantic ambiguity gate, urutan deterministik, dan input Search metadata pada UI.

Tidak ada credential, data produksi, file SQLite, venv, atau model embedding di ZIP ini.
