"""Server-qualified catalog selection and explicit snapshot registration.

These are catalog boundaries, not a replacement for SQL Server authorization.
Legacy DEMO snapshots remain readable; real snapshots need scanner registration.
"""
from __future__ import annotations

import json


def database_scope_key(obj: dict) -> str:
    server = obj.get('physical_server') or obj.get('logical_server') or ''
    return json.dumps([server, obj['database_name']], ensure_ascii=False, separators=(',', ':'))


def scope_options(objects: list[dict]) -> dict[str, str]:
    return dict(sorted({database_scope_key(o):
        f"{o.get('logical_server', '')} · {o['database_name']} · {o.get('physical_server', '')}"
        for o in objects}.items(), key=lambda pair: pair[1].casefold()))


def resolve_scope(objects: list[dict], selection: list[str] | None) -> set[str]:
    options = scope_options(objects)
    if selection is None:
        return set(options)
    result = set()
    for value in selection:
        if value in options:
            result.add(value)
            continue
        # Preserve old callers only when the database name is unambiguous.
        matching = {database_scope_key(o) for o in objects if o['database_name'] == value}
        if len(matching) != 1:
            raise ValueError(f'Scope database tidak ditemukan/ambigu: {value}. Pilih server + database.')
        result.update(matching)
    return result


def validate_catalog_scope(cn, objects: list[dict]) -> None:
    if not objects:
        raise RuntimeError('Katalog tidak mempunyai objek yang terlihat oleh akun SQL.')
    exists = cn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='catalog_source_scopes'").fetchone()
    if not exists:
        if all(o['database_name'].startswith('DEMO_') for o in objects):
            return
        raise RuntimeError('Katalog non-DEMO belum terdaftar. Bangun dengan 41_sync_metadata_servers.py.')
    latest = cn.execute('SELECT MAX(run_id) FROM catalog_runs').fetchone()[0]
    rows = cn.execute('SELECT logical_server,physical_server,database_name FROM catalog_source_scopes WHERE source_run_id=?', (latest,)).fetchall()
    allowed = {tuple(str(v).casefold() for v in r) for r in rows}
    for o in objects:
        identity = tuple(str(o[k]).casefold() for k in ('logical_server','physical_server','database_name'))
        if identity not in allowed:
            raise RuntimeError('Objek katalog berada di luar registrasi snapshot terbaru.')


def display_object(obj: dict) -> str:
    fqn = f"{obj['database_name']}.{obj['schema_name']}.{obj['object_name']}"
    if obj['database_name'].startswith('DEMO_'):
        return fqn
    return f"{obj.get('logical_server', '')} · {obj.get('physical_server', '')} · {fqn}"
