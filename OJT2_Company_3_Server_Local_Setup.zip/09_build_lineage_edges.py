"""OJT2 Stage 2 — static T-SQL lineage classification from the existing SQLite snapshot.

No SQL Server connection, no stored procedure execution, no change to source databases.
This is a conservative DEMO parser, NOT a production-grade T-SQL parser.
It recognizes named FROM/JOIN and INSERT/DELETE/UPDATE/MERGE targets in conventional SQL.
All conclusions are STATIC_INFERRED (even if cross-checked against sys dependencies).
Dynamic SQL, CTEs, temp tables, aliases used as DML targets, and nested SQL may be unresolved.

Run:  .\\.venv\\Scripts\\python.exe .\\09_build_lineage_edges.py
"""
from __future__ import annotations

import argparse
import os
from ojt2_catalog_scope import validate_catalog_scope
import re
import sqlite3
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_CATALOG = Path.home() / "OJT2_Discovery_Data" / "metadata_catalog.sqlite"

# Identifiers supported by the conservative static parser. Bracketed names are supported.
_PART = r"(?:\[[^\]\r\n]+\]|[A-Za-z_#][\w$#]*)"
_IDENT = rf"{_PART}(?:\s*\.\s*{_PART}){{0,3}}"
_RX = {
    "INSERT": re.compile(rf"\bINSERT\s+INTO\s+(?P<name>{_IDENT})", re.I),
    "DELETE": re.compile(rf"\bDELETE\s+FROM\s+(?P<name>{_IDENT})", re.I),
    "TRUNCATE": re.compile(rf"\bTRUNCATE\s+TABLE\s+(?P<name>{_IDENT})", re.I),
    "MERGE": re.compile(rf"\bMERGE\s+(?:INTO\s+)?(?P<name>{_IDENT})", re.I),
    "UPDATE": re.compile(rf"\bUPDATE\s+(?P<name>{_IDENT})", re.I),
    "FROM": re.compile(rf"\bFROM\s+(?P<name>{_IDENT})", re.I),
    "JOIN": re.compile(rf"\bJOIN\s+(?P<name>{_IDENT})", re.I),
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS lineage_edges (
    lineage_id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_run_id INTEGER NOT NULL,
    source_key TEXT NOT NULL,
    target_key TEXT,
    target_display TEXT NOT NULL,
    relation_type TEXT NOT NULL,
    operations TEXT NOT NULL,
    evidence_status TEXT NOT NULL,
    evidence_detail TEXT NOT NULL,
    review_status TEXT NOT NULL DEFAULT 'NOT_REVIEWED',
    derived_from TEXT NOT NULL DEFAULT 'STATIC_SQL',
    indexed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lineage_source ON lineage_edges(source_key, relation_type);
CREATE INDEX IF NOT EXISTS idx_lineage_target ON lineage_edges(target_key, relation_type);
CREATE TABLE IF NOT EXISTS lineage_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_run_id INTEGER NOT NULL,
    generated_at TEXT NOT NULL,
    edge_count INTEGER NOT NULL,
    unresolved_count INTEGER NOT NULL
);
"""


def strip_comments_and_strings(sql: str) -> tuple[str, bool]:
    """Mask comments/string literals with spaces, preserving positions; track dynamic SQL suspicion."""
    out = list(sql)
    i, n = 0, len(sql)
    has_dynamic = bool(re.search(r"\b(?:sp_executesql|EXEC\s*\(|EXECUTE\s*\()\b", sql, re.I))
    while i < n:
        if sql.startswith("--", i):
            end = sql.find("\n", i)
            if end == -1:
                end = n
            for k in range(i, end):
                out[k] = " "
            i = end
        elif sql.startswith("/*", i):
            depth = 1
            j = i + 2
            while j < n and depth:
                if sql.startswith("/*", j):
                    depth += 1
                    j += 2
                elif sql.startswith("*/", j):
                    depth -= 1
                    j += 2
                else:
                    j += 1
            for k in range(i, j):
                if sql[k] != "\n":
                    out[k] = " "
            i = j
        elif sql[i] == "'" or (sql[i] in "Nn" and i + 1 < n and sql[i + 1] == "'"
                               and (i == 0 or not (sql[i - 1].isalnum() or sql[i - 1] == "_"))):
            j = i + (2 if sql[i] in "Nn" and sql[i + 1:i + 2] == "'" else 1)
            while j < n:
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            for k in range(i, j):
                if sql[k] != "\n":
                    out[k] = " "
            i = j
        else:
            i += 1
    return "".join(out), has_dynamic


def ident_parts(identifier: str) -> list[str]:
    raw = re.findall(_PART, identifier)
    return [part[1:-1].replace("]]", "]") if part.startswith("[") else part for part in raw]


def ref_parts(identifier: str, current: dict) -> tuple[str | None, str, str, str]:
    p = ident_parts(identifier)
    if len(p) == 1:
        return None, current["database_name"], "dbo", p[0]
    if len(p) == 2:
        return None, current["database_name"], p[0], p[1]
    if len(p) == 3:
        return None, p[0], p[1], p[2]
    if len(p) == 4:
        return p[0], p[1], p[2], p[3]
    raise ValueError(f"Unsupported identifier: {identifier!r}")


def build_parser_records(obj: dict, sql: str):
    masked, has_dynamic = strip_comments_and_strings(sql)
    writes, reads = defaultdict(set), defaultdict(set)
    consumed_delete_from = set()
    for operation in ("INSERT", "DELETE", "TRUNCATE", "MERGE", "UPDATE"):
        for m in _RX[operation].finditer(masked):
            name = m.group("name")
            # UPDATE alias, e.g. UPDATE t SET ... FROM table t, is NOT resolved by this simple parser.
            if operation == "UPDATE" and len(ident_parts(name)) == 1 and re.search(r"\bFROM\b", masked[m.end():]):
                # Could be a table name or alias: mark as candidate only.
                pass
            writes[ref_parts(name, obj)].add(operation)
            if operation == "DELETE":
                consumed_delete_from.add(m.start("name"))
    for operation in ("FROM", "JOIN"):
        for m in _RX[operation].finditer(masked):
            if operation == "FROM" and m.start("name") in consumed_delete_from:
                continue
            name = m.group("name")
            parsed = ref_parts(name, obj)
            if parsed[-1].upper() in ("SELECT", "OPENQUERY", "OPENROWSET") or parsed[-1].startswith("#"):
                continue
            reads[parsed].add(operation)
    # Don't assume presence of a dependency equals read/write classification.
    return writes, reads, has_dynamic


def main():
    cli = argparse.ArgumentParser()
    cli.add_argument("--catalog", type=Path, default=Path(os.getenv("OJT2_CATALOG_PATH",str(DEFAULT_CATALOG))))
    args = cli.parse_args()
    path = args.catalog.expanduser()
    if not path.exists():
        raise SystemExit(f"Metadata Catalog belum ada: {path}. Jalankan 07 dahulu.")
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with sqlite3.connect(path) as cx:
        cx.row_factory = sqlite3.Row
        required = {"catalog_objects", "catalog_dependencies", "catalog_runs"}
        present = {r[0] for r in cx.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not required.issubset(present):
            raise RuntimeError("Metadata catalog schema tidak cocok dengan script 07.")
        last = cx.execute("SELECT run_id FROM catalog_runs ORDER BY run_id DESC LIMIT 1").fetchone()
        if not last:
            raise RuntimeError("Katalog belum punya snapshot run.")
        run_id = int(last[0])
        objects = [dict(r) for r in cx.execute("SELECT * FROM catalog_objects")]
        validate_catalog_scope(cx, objects)
        by_key = {o["object_key"]: o for o in objects}
        by_fqn = defaultdict(list)
        for o in objects:
            by_fqn[(o["physical_server"].lower(), o["database_name"].lower(),
                    o["schema_name"].lower(), o["object_name"].lower())].append(o)
        deps = defaultdict(set)
        for d in cx.execute("SELECT * FROM catalog_dependencies"):
            parent = by_key.get(d["referencing_key"])
            if parent:
                deps[d["referencing_key"]].add((str(d["referenced_database"] or parent["database_name"]).lower(),
                                                  str(d["referenced_schema"] or "dbo").lower(),
                                                  str(d["referenced_object"] or "").lower()))
        combined = {}
        problem_defs = []
        for o in objects:
            if o["object_type"].strip() not in {"V", "P"}:
                continue
            if o["definition_status"] != "AVAILABLE" or not o["sql_definition"]:
                problem_defs.append(o["object_key"])
                continue
            writes, reads, dynamic = build_parser_records(o, o["sql_definition"])
            for relation, items in (("WRITES_TO", writes), ("READS_FROM", reads)):
                for target, operations in items.items():
                    remote, database, schema, name = target
                    # Resolve only the current physical instance. Unmapped linked-server aliases stay unresolved.
                    if remote and remote.lower() != o["physical_server"].lower():
                        match = []
                    else:
                        match = by_fqn.get((o["physical_server"].lower(), database.lower(),
                                            schema.lower(), name.lower()), [])
                    resolved = match[0] if len(match) == 1 else None
                    evidence = (database.lower(), schema.lower(), name.lower()) in deps[o["object_key"]]
                    status = ("STATIC_MATCH_CORROBORATED" if resolved and evidence else
                              "STATIC_MATCH_UNCORROBORATED" if resolved else "UNRESOLVED")
                    detail = "Static SQL text + sys.sql_expression_dependencies" if evidence else "Static SQL text only"
                    if dynamic:
                        detail += "; dynamic SQL detected, review required"
                    display = f"{remote + '.' if remote else ''}{database}.{schema}.{name}"
                    key = (o["object_key"], resolved["object_key"] if resolved else None,
                           display.lower(), relation)
                    combined[key] = (o["object_key"], resolved["object_key"] if resolved else None,
                                     display, relation, ",".join(sorted(operations)), status, detail,
                                     "NOT_REVIEWED", "STATIC_SQL", now)
                    if relation == "WRITES_TO" and resolved:
                        reverse_key = (resolved["object_key"], o["object_key"],
                                       f'{o["database_name"]}.{o["schema_name"]}.{o["object_name"]}'.lower(),
                                       "GENERATED_BY")
                        combined[reverse_key] = (resolved["object_key"], o["object_key"],
                                                 f'{o["database_name"]}.{o["schema_name"]}.{o["object_name"]}',
                                                 "GENERATED_BY", ",".join(sorted(operations)), status,
                                                 "Derived inverse of a WRITES_TO static inference",
                                                 "NOT_REVIEWED", "DERIVED_INVERSE", now)
        rows = [(run_id,) + value for value in combined.values()]
        cx.executescript(SCHEMA)
        with cx:
            cx.execute("DELETE FROM lineage_edges")
            cx.executemany("""INSERT INTO lineage_edges
                (source_run_id, source_key, target_key, target_display, relation_type,
                 operations, evidence_status, evidence_detail, review_status, derived_from, indexed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", rows)
            unresolved = sum(r[6] == "UNRESOLVED" for r in rows)
            cx.execute("""INSERT INTO lineage_runs
                (source_run_id, generated_at, edge_count, unresolved_count)
                VALUES (?, ?, ?, ?)""", (run_id, now, len(rows), unresolved))
        counts = dict(Counter(r[4] for r in rows))
        statuses = dict(Counter(r[6] for r in rows))
        print("=== STATIC LINEAGE BUILD SUCCESS ===")
        print("Metadata run:", run_id)
        print("SQLite catalog:", path)
        print("Edges:", len(rows), "by relation:", counts)
        print("Evidence status:", statuses)
        print("Definitions missing:", len(problem_defs))
        print("NOTE: Semua edge adalah hasil INFERENSI STATIS, belum verified runtime.")
        print("NOTE: Rerun script 09 setelah setiap refresh metadata dengan script 07.")

if __name__ == "__main__":
    main()
