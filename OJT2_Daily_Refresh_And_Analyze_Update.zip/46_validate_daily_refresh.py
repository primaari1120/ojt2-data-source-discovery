"""Offline regression for vault integration, daily generations and exact caches.

Windows native Credential Manager / Task Scheduler still need a laptop smoke test.
"""
from __future__ import annotations
from contextlib import closing
from datetime import datetime,timezone,timedelta
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from ojt2_credentials import credential_target,resolve_password
from ojt2_catalog_publication import (refresh_catalog,resolve_catalog,pointer_path,status_path,
    publication_lock,refresh_status)

ROOT=Path(__file__).resolve().parent


def module(name):
    spec=importlib.util.spec_from_file_location('daily_'+name.split('.')[0],ROOT/name)
    loaded=importlib.util.module_from_spec(spec);spec.loader.exec_module(loaded);return loaded


class Vault:
    def __init__(self,password=None): self.password=password
    def get(self,source): return self.password


class DailyRefresh(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        from ojt2_precomputed import close_reader
        self.addCleanup(close_reader)
        self.folder=Path(self.temp.name)
        self.fake=module('42_validate_multi_server_catalog.py').FakeODBC()
        self.patch=patch.dict(sys.modules,pyodbc=self.fake);self.patch.start();self.addCleanup(self.patch.stop)
        self.env=patch.dict(os.environ,OJT2_TEST_PASSWORD='synthetic-only-password',OJT2_SEMANTIC_MODEL_PATH=str(self.folder/'no-model'))
        self.env.start();self.addCleanup(self.env.stop)
        self.config={'catalog_path':self.folder/'catalog.sqlite','servers':[
            {'id':s,'server':s,'authentication':'sql','username':'reader','password_env':'OJT2_TEST_PASSWORD','databases':'all_accessible'}
            for s in ('DGA','IT1','IT2')]}

    def publish(self,**kw): return refresh_catalog(self.config,emit=lambda _:None,**kw)

    def test_credential_identity_and_noninteractive_behavior(self):
        s=self.config['servers'][0]
        self.assertEqual(credential_target(s),credential_target(dict(s,id='RENAMED')))
        self.assertNotEqual(credential_target(s),credential_target(dict(s,username='other')))
        self.assertNotEqual(credential_target(s),credential_target(dict(s,server='elsewhere')))
        with patch('getpass.getpass',side_effect=AssertionError('Must never prompt')):
            self.assertEqual(resolve_password(s,non_interactive=True,store=Vault('vault-secret')),'vault-secret')
            self.assertEqual(resolve_password(s,non_interactive=True,store=Vault()),'synthetic-only-password')
            with patch.dict(os.environ,OJT2_TEST_PASSWORD=''):
                with self.assertRaises(RuntimeError):resolve_password(s,non_interactive=True,store=Vault())

    def test_mutable_vocabulary_signatures_and_dictionary_cache_stay_correct(self):
        from ojt2_term_rules import TermRules
        from ojt2_field_matching import split_tokens,ordered_field_tokens
        rules=TermRules({'stn':'station'})
        self.assertEqual(split_tokens('StnName',rules),('name','station'))
        before=rules.signature
        rules['stn']='location'
        self.assertNotEqual(before,rules.signature)
        self.assertEqual(split_tokens('StnName',rules),('location','name'))
        self.assertEqual(ordered_field_tokens('StnName',term_rules=rules),('location','name'))
        rules.update(stn='site')
        self.assertEqual(split_tokens('StnName',rules),('name','site'))
        del rules['stn'];self.assertNotIn('stn',dict(rules.signature))

    def test_atomic_publication_and_failure_preserve_old_catalog(self):
        first=self.publish();base=self.config['catalog_path']
        digest=hashlib.sha256(first.read_bytes()).hexdigest()
        pointer=pointer_path(base).read_bytes()
        for phase in ('collector','lineage','prepare'):
            def fail(*a,**kw):
                self.assertEqual(resolve_catalog(base),first)
                raise RuntimeError('DO-NOT-LOG-SENSITIVE-DETAIL')
            with self.assertRaises(RuntimeError):self.publish(**{phase:fail})
            self.assertEqual(resolve_catalog(base),first)
            self.assertEqual(pointer_path(base).read_bytes(),pointer)
            self.assertEqual(hashlib.sha256(first.read_bytes()).hexdigest(),digest)
            status=json.loads(status_path(base).read_text())
            self.assertEqual(status['state'],'failed')
            self.assertNotIn('SENSITIVE',status_path(base).read_text())
        second=self.publish()
        self.assertNotEqual(first,second)
        self.assertTrue(first.is_file())
        reader=module('11_metadata_explorer_streamlit.py')
        old=reader.read_catalog(first);new=reader.read_catalog(base)
        self.assertGreater(new['metadata_run']['run_id'],old['metadata_run']['run_id'])
        self.assertEqual(new['metadata_run']['run_id'],new['lineage_run']['source_run_id'])
        self.assertEqual(resolve_catalog(base),second)
        with closing(sqlite3.connect(second)) as cn:
            self.assertGreater(cn.execute('SELECT count(*) FROM precomputed_tokens').fetchone()[0],0)

    def test_lock_and_freshness_and_pointer_boundaries(self):
        self.publish();base=self.config['catalog_path']
        with publication_lock(base):
            with self.assertRaises(RuntimeError):self.publish()
        self.assertFalse(refresh_status(base)['stale'])
        self.assertTrue(refresh_status(base,now=datetime.now(timezone.utc)+timedelta(hours=25))['stale'])
        pointer_path(base).write_text(json.dumps({'version':1,'generation':'../elsewhere.sqlite'}))
        with self.assertRaises(RuntimeError):resolve_catalog(base)

    def test_retention_only_removes_managed_old_generations(self):
        first=self.publish();base=self.config['catalog_path']
        base.write_bytes(first.read_bytes());legacy=hashlib.sha256(base.read_bytes()).hexdigest()
        manual=first.parent/'manual_backup.sqlite';manual.write_bytes(b'keep-this-unmanaged-file')
        for _ in range(3):self.publish()
        managed=[p for p in first.parent.glob('*.sqlite') if len(p.stem)==32]
        self.assertEqual(len(managed),3)
        self.assertTrue(resolve_catalog(base).is_file())
        self.assertTrue(manual.is_file())
        self.assertEqual(hashlib.sha256(base.read_bytes()).hexdigest(),legacy)

    def test_invalid_extraction_counts_never_publish(self):
        from ojt2_multi_server import inspect_sources
        first=self.publish()
        def incomplete(config,**kwargs):
            inspect_sources(config,**kwargs)
            with closing(sqlite3.connect(config['catalog_path'])) as cn:
                cn.execute('UPDATE catalog_runs SET column_count=column_count+1');cn.commit()
        with self.assertRaises(RuntimeError):self.publish(collector=incomplete)
        self.assertEqual(resolve_catalog(self.config['catalog_path']),first)

    def test_crashed_job_status_does_not_leave_refresh_button_permanently_disabled(self):
        self.publish();base=self.config['catalog_path']
        path=status_path(base);state=json.loads(path.read_text());state.update(state='running',pid=0)
        path.write_text(json.dumps(state))
        self.assertEqual(refresh_status(base)['job']['state'],'interrupted')

    def test_precomputed_tokens_equal_fallback_and_new_rules_miss(self):
        from ojt2_field_matching import split_tokens,BASE_TERMS,_split_tokens_cached
        from ojt2_precomputed import cached_tokens
        published=self.publish()
        names=['ProjectID','TowerName','City']
        with patch.dict(os.environ,OJT2_PRECOMPUTED_PATH=''):
            _split_tokens_cached.cache_clear();expected={n:split_tokens(n) for n in names}
        with patch.dict(os.environ,OJT2_PRECOMPUTED_PATH=str(published)):
            _split_tokens_cached.cache_clear()
            self.assertEqual({n:split_tokens(n) for n in names},expected)
            from ojt2_precomputed import close_reader
            close_reader()
            with closing(sqlite3.connect(published)) as cn:
                cn.execute('UPDATE precomputed_tokens SET tokens=? WHERE text=?',('["wrong-but-valid-json"]','City'));cn.commit()
            _split_tokens_cached.cache_clear()
            self.assertEqual(split_tokens('City'),expected['City'])
            changed=dict(BASE_TERMS,city='municipality')
            self.assertIsNone(cached_tokens('City',tuple(sorted(changed.items()))))
            self.assertEqual(split_tokens('City',changed),('municipality',))
            self.assertEqual(split_tokens('FutureColumnThatWasNotIndexed'),split_tokens('FutureColumnThatWasNotIndexed'))

    def test_precomputed_vectors_same_semantic_results_and_model_invalidation(self):
        import numpy as np
        import ojt2_semantic_engine as engine
        from ojt2_precomputed import SCHEMA,put_vectors,model_key
        path=self.folder/'vectors.sqlite';model=self.folder/'model';model.mkdir();(model/'modules.json').write_text('[]')
        class Encoder:
            def __init__(self):self.texts=[]
            def encode(self,texts,**kw):
                self.texts.extend(texts)
                return np.asarray([[.6,.8] for _ in texts],dtype=np.float32)
        fake=Encoder();columns=[{'column_name':'EmployeeName','sql_type':'nvarchar'},{'column_name':'EmployeeTitle','sql_type':'nvarchar'}]
        ready={'ready':True,'path':str(model),'reason':'LOCAL_MODEL_AVAILABLE'}
        with patch.object(engine,'semantic_status',return_value=ready),patch.object(engine,'_load_model',return_value=fake):
            with patch.dict(os.environ,OJT2_PRECOMPUTED_PATH=''):
                engine._EMBED_CACHE.clear();baseline=engine.semantic_candidates(columns,'Worker Name',object_name='Staff')
            _,labels,contexts=engine._semantic_inputs(columns,'Worker Name','Staff','','')
            stable=list(dict.fromkeys(labels[1:]+contexts[1:]))
            with closing(sqlite3.connect(path)) as cn:
                cn.executescript(SCHEMA);put_vectors(cn,model_key(model),stable,fake.encode(stable));cn.commit()
            fake.texts.clear();engine._EMBED_CACHE.clear()
            with patch.dict(os.environ,OJT2_PRECOMPUTED_PATH=str(path)):
                actual=engine.semantic_candidates(columns,'Worker Name',object_name='Staff')
                self.assertEqual(actual,baseline)
                self.assertTrue(fake.texts)
                self.assertFalse(set(fake.texts)&set(stable),'Static metadata was encoded again')
                # Corrupt row must cause recomputation, preserving the answer.
                with closing(sqlite3.connect(path)) as cn:
                    cn.execute('UPDATE precomputed_vectors SET vector=?',(b'bad',));cn.commit()
                engine._EMBED_CACHE.clear();fake.texts.clear()
                self.assertEqual(engine.semantic_candidates(columns,'Worker Name',object_name='Staff'),baseline)
                self.assertTrue(set(fake.texts)&set(stable))
                old_key=model_key(model);(model/'modules.json').write_text('[{"changed":true}]')
                self.assertNotEqual(old_key,model_key(model))

    def test_analyze_cache_copies_and_invalidates_all_context_components(self):
        ui=module('15_adaptive_workflow_streamlit.py');ui._cached_discovery.clear()
        data={};index={};args=[('generation1',),'{}',('scope1',),12,(1,1),('engine1','model1')]
        with patch.object(ui,'discover',return_value=[{'score':12,'field_map':[]}]) as discover:
            first=ui._cached_discovery(*args,data,index);first[0]['score']=99
            self.assertEqual(ui._cached_discovery(*args,data,index)[0]['score'],12)
            self.assertEqual(discover.call_count,1)
            for i,value in enumerate([('generation2',),'{"purpose":"changed"}',('scope2',),20,(2,1),('engine1','model2')]):
                changed=list(args);changed[i]=value;ui._cached_discovery(*changed,data,index)
            self.assertEqual(discover.call_count,7)

    def test_app_uses_new_generation_and_invalidates_previous_results(self):
        from streamlit.testing.v1 import AppTest
        base=self.config['catalog_path'];first=self.publish()
        cfg=self.folder/'config.json';cfg.write_text('{}')
        with patch.dict(os.environ,OJT2_CATALOG_PATH=str(base),OJT2_SERVER_CONFIG=str(cfg)):
            app=AppTest.from_file(str(ROOT/'15_adaptive_workflow_streamlit.py')).run(timeout=30)
            self.assertFalse(app.exception,[e.message for e in app.exception])
            old=app.session_state['_active_catalog_generation']
            app.session_state['discovery_results']=[{'old':True}]
            second=self.publish();app.run()
            self.assertFalse(app.exception,[e.message for e in app.exception])
            self.assertNotEqual(old,app.session_state['_active_catalog_generation'])
            self.assertNotIn('discovery_results',app.session_state)
            self.assertEqual(resolve_catalog(base),second)

    def test_refresh_button_launches_background_noninteractive_job(self):
        from streamlit.testing.v1 import AppTest
        self.publish();base=self.config['catalog_path']
        cfg=self.folder/'config.json';cfg.write_text('{}')
        with patch.dict(os.environ,OJT2_CATALOG_PATH=str(base),OJT2_SERVER_CONFIG=str(cfg)):
            app=AppTest.from_file(str(ROOT/'15_adaptive_workflow_streamlit.py')).run(timeout=30)
            self.assertFalse(app.exception)
            with patch('subprocess.Popen') as launch:
                next(b for b in app.button if b.label=='Refresh metadata').click().run()
                self.assertFalse(app.exception,[e.message for e in app.exception])
                command=launch.call_args.args[0]
                self.assertIn('--non-interactive',command)
                self.assertTrue(any(str(v).endswith('47_refresh_catalog.py') for v in command))
                self.assertFalse(any('synthetic-only-password' in str(v) for v in command))


if __name__=='__main__':
    with TemporaryDirectory() as folder:
        os.environ['OJT2_APP_DATA_DIR']=str(Path(folder)/'app')
        os.environ['OJT2_SEMANTIC_MODEL_PATH']=str(Path(folder)/'no_model')
        unittest.main(verbosity=2)
