"""Windows user-scoped Credential Manager; never a plaintext password file."""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import getpass
import hashlib
import json
import os


def credential_target(source):
    identity=json.dumps([source['server'].strip().casefold(),source['username']],ensure_ascii=False)
    return 'OJT2/SQL/'+hashlib.sha256(identity.encode()).hexdigest()


class WindowsCredentialStore:
    def __init__(self):
        if os.name!='nt':
            raise RuntimeError('Windows Credential Manager hanya tersedia di Windows.')
        class Credential(ctypes.Structure):
            _fields_=[('Flags',wintypes.DWORD),('Type',wintypes.DWORD),
                ('TargetName',wintypes.LPWSTR),('Comment',wintypes.LPWSTR),
                ('LastWritten',wintypes.FILETIME),('CredentialBlobSize',wintypes.DWORD),
                ('CredentialBlob',ctypes.POINTER(ctypes.c_ubyte)),('Persist',wintypes.DWORD),
                ('AttributeCount',wintypes.DWORD),('Attributes',ctypes.c_void_p),
                ('TargetAlias',wintypes.LPWSTR),('UserName',wintypes.LPWSTR)]
        self.Credential=Credential
        self.api=ctypes.WinDLL('Advapi32.dll',use_last_error=True)
        ptr=ctypes.POINTER(Credential)
        self.api.CredReadW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.POINTER(ptr)]
        self.api.CredReadW.restype=wintypes.BOOL
        self.api.CredWriteW.argtypes=[ptr,wintypes.DWORD];self.api.CredWriteW.restype=wintypes.BOOL
        self.api.CredDeleteW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD]
        self.api.CredDeleteW.restype=wintypes.BOOL
        self.api.CredFree.argtypes=[ctypes.c_void_p];self.api.CredFree.restype=None

    def get(self,source):
        pointer=ctypes.POINTER(self.Credential)()
        if not self.api.CredReadW(credential_target(source),1,0,ctypes.byref(pointer)):
            code=ctypes.get_last_error()
            if code==1168: return None
            raise RuntimeError(f'Credential Manager read gagal (Windows error {code}).')
        try:
            record=pointer.contents
            if record.UserName!=source['username']:
                raise RuntimeError('Username credential berbeda dari konfigurasi.')
            return ctypes.string_at(record.CredentialBlob,record.CredentialBlobSize).decode('utf-16-le')
        finally:
            self.api.CredFree(pointer)

    def save(self,source,password):
        if not password: raise ValueError('Password kosong.')
        data=password.encode('utf-16-le')
        if len(data)>2560: raise ValueError('Password melebihi batas Credential Manager.')
        blob=(ctypes.c_ubyte*len(data)).from_buffer_copy(data)
        record=self.Credential()
        record.Type=1;record.TargetName=credential_target(source)
        record.UserName=source['username'];record.Comment='OJT2 SQL metadata collector'
        record.CredentialBlobSize=len(data);record.CredentialBlob=blob
        record.Persist=2  # local-machine persistence, still scoped to current user
        try:
            if not self.api.CredWriteW(ctypes.byref(record),0):
                raise RuntimeError(f'Credential Manager write gagal (Windows error {ctypes.get_last_error()}).')
        finally:
            ctypes.memset(blob,0,len(data))

    def delete(self,source):
        if not self.api.CredDeleteW(credential_target(source),1,0):
            code=ctypes.get_last_error()
            if code!=1168: raise RuntimeError(f'Credential delete gagal (Windows error {code}).')


def resolve_password(source, *, non_interactive=False, store=None):
    if source['authentication']=='windows': return None
    if store is None and os.name=='nt': store=WindowsCredentialStore()
    password=store.get(source) if store is not None else None
    if not password: password=os.environ.get(source.get('password_env',''))
    if password: return password
    if non_interactive:
        raise RuntimeError(f'{source["id"]}: credential belum tersedia untuk akun Windows job. Jalankan 45_manage_credentials.py --save.')
    password=getpass.getpass(f'{source["id"]} SQL password (tidak disimpan): ')
    if not password: raise ValueError('Password kosong.')
    return password
