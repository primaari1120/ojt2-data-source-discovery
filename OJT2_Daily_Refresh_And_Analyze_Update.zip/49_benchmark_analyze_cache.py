"""Synthetic repeat-Analyze benchmark; reports identical output, no SQL required."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import statistics
from tempfile import TemporaryDirectory
from time import perf_counter


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--objects',type=int,default=150)
    cli.add_argument('--output',type=Path)
    args=cli.parse_args()
    if not 1<=args.objects<=5000:raise SystemExit('--objects must be 1..5000')
    with TemporaryDirectory() as folder:
        os.environ['OJT2_APP_DATA_DIR']=str(Path(folder)/'app')
        os.environ['OJT2_SEMANTIC_MODEL_PATH']=str(Path(folder)/'no_model')
        root=Path(__file__).resolve().parent
        def load(name):
            spec=importlib.util.spec_from_file_location('bench_'+name.split('.')[0],root/name)
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
        explorer=load('11_metadata_explorer_streamlit.py');ui=load('15_adaptive_workflow_streamlit.py')
        from ojt2_catalog_scope import scope_options
        from ojt2_adaptive_core import discover
        columns=['POID','ContractValue','TowerName','WarehouseCity','CreatedDate','EmployeeName','ProjectID','Status']
        objects=[];all_columns=[]
        for i in range(args.objects):
            server=('DGA','IT1','IT2')[i%3];key=f'{server}|SharedDB|dbo|Source{i:04}|V'
            objects.append({'object_key':key,'physical_server':server,'logical_server':server,
                'database_name':'SharedDB','schema_name':'dbo','object_name':f'Source{i:04}',
                'object_type':'V','object_type_desc':'VIEW'})
            all_columns.extend({'object_key':key,'column_name':c,'sql_type':'int' if c.endswith('ID') else 'nvarchar'} for c in columns)
        data={'objects':objects,'columns':all_columns,'edges':[]};index=explorer.make_index(data)
        req={'purpose':'Monitoring contract and tower','source_hint':'','required_fields':['ID PO','Nilai Kontrak','Nama Tower','City','Feedback Date']}
        scope=list(scope_options(objects))
        started=perf_counter();baseline=discover(data,index,req,scope,limit=12);baseline_time=perf_counter()-started
        ui._cached_discovery.clear()
        cache_args=(('synthetic-generation',),json.dumps(req,sort_keys=True),tuple(sorted(scope)),12,(0,0),ui._matching_revision())
        started=perf_counter();first=ui._cached_discovery(*cache_args,data,index);first_time=perf_counter()-started
        assert first==baseline
        times=[]
        for _ in range(5):
            started=perf_counter();actual=ui._cached_discovery(*cache_args,data,index);times.append(perf_counter()-started)
            assert actual==baseline
        warm=statistics.median(times)
        result={'synthetic_only':True,'semantic_model':'disabled for this lexical benchmark','objects':args.objects,
            'columns':len(all_columns),'fields':len(req['required_fields']),
            'reference_discovery_seconds':round(baseline_time,6),'cache_fill_seconds':round(first_time,6),
            'repeat_cache_median_seconds':round(warm,6),'repeat_speedup_vs_fill':round(first_time/max(warm,1e-9),2),
            'identical_rank_mapping_status_evidence':True,
            'limits':'Repeat-Analyze cache only; not corporate catalog latency or first-model initialization. Changed context invalidates cache.'}
        print(json.dumps(result,indent=2))
        if args.output:args.output.write_text(json.dumps(result,indent=2))


if __name__=='__main__':main()
