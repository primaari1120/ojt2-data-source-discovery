[CmdletBinding()]
param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'sql_servers.local.json'),
    [ValidatePattern('^([01][0-9]|2[0-3]):[0-5][0-9]$')][string]$At = '06:00',
    [string]$TaskName = 'OJT2-Daily-Metadata-Refresh',
    [switch]$RunWhenLoggedOff,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
$taskPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$taskScript = Join-Path $PSScriptRoot '47_refresh_catalog.py'
foreach ($requiredPath in @($taskPython, $taskScript, $ConfigPath)) {
    if (!(Test-Path -LiteralPath $requiredPath)) { throw "File tidak ditemukan: $requiredPath" }
}
$resolvedConfig = (Resolve-Path -LiteralPath $ConfigPath).Path
if ($resolvedConfig.Contains('"')) { throw 'Path config mengandung karakter quote yang tidak didukung.' }
$taskArguments = '"' + $taskScript + '" --config "' + $resolvedConfig + '" --non-interactive'
$taskUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
if ($DryRun) {
    [pscustomobject]@{ TaskName=$TaskName; DailyAt=$At; WindowsUser=$taskUser; Python=$taskPython; Arguments=$taskArguments; RunWhenLoggedOff=[bool]$RunWhenLoggedOff }
    return
}
$existingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existingTask) { throw 'Task sudah ada. Gunakan nama baru atau periksa/hapus task lama secara eksplisit di Task Scheduler.' }
$taskAction = New-ScheduledTaskAction -Execute $taskPython -Argument $taskArguments -WorkingDirectory $PSScriptRoot
$taskTrigger = New-ScheduledTaskTrigger -Daily -At $At
$taskSettings = New-ScheduledTaskSettingsSet -StartWhenAvailable -WakeToRun -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 30) -ExecutionTimeLimit (New-TimeSpan -Hours 8)
if ($RunWhenLoggedOff) {
    # Windows stores this logon credential for Task Scheduler. Never SQL passwords in task args.
    $taskCredential = Get-Credential -UserName $taskUser -Message 'Akun Windows yang SAMA dengan penyimpanan SQL Credential Manager'
    if ($null -eq $taskCredential) { throw 'Credential Windows tidak diberikan.' }
    if ($taskCredential.UserName -ine $taskUser) { throw 'Gunakan akun Windows yang sama agar vault SQL dapat diakses.' }
    $taskPrincipal = New-ScheduledTaskPrincipal -UserId $taskUser -LogonType Password -RunLevel Limited
    $taskDefinition = New-ScheduledTask -Action $taskAction -Trigger $taskTrigger -Settings $taskSettings -Principal $taskPrincipal
    Register-ScheduledTask -TaskName $TaskName -InputObject $taskDefinition -User $taskUser -Password ($taskCredential.GetNetworkCredential().Password) | Out-Null
    $taskCredential = $null
} else {
    $taskPrincipal = New-ScheduledTaskPrincipal -UserId $taskUser -LogonType Interactive -RunLevel Limited
    Register-ScheduledTask -TaskName $TaskName -Action $taskAction -Trigger $taskTrigger -Settings $taskSettings -Principal $taskPrincipal | Out-Null
}
Write-Output "Task '$TaskName' terpasang setiap $At waktu lokal Windows; retry 3 kali tiap 30 menit."
Write-Output 'Default membutuhkan user login; gunakan -RunWhenLoggedOff untuk logon tersimpan. Laptop/VPN tetap harus tersedia.'
