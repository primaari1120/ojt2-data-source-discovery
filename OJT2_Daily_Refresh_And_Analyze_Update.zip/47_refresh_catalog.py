"""One complete refresh job: credentials -> metadata -> lineage -> indexes -> publish."""
import argparse
import os
from datetime import datetime,timezone
import re
from pathlib import Path
from ojt2_catalog_publication import refresh_catalog
from ojt2_multi_server import load_config,runtime_environment


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--config',type=Path,default=Path(os.environ.get('OJT2_SERVER_CONFIG',Path(__file__).with_name('sql_servers.local.json'))))
    mode=cli.add_mutually_exclusive_group()
    mode.add_argument('--non-interactive',action='store_true',help='Explicit scheduled mode (default)')
    mode.add_argument('--interactive',action='store_true',help='Allow password prompt if vault/environment unavailable')
    args=cli.parse_args()
    try:
        config=load_config(args.config)
        os.environ.update(runtime_environment(config))
        log=Path(str(config['catalog_path'])+'.refresh.log')
        log.parent.mkdir(parents=True,exist_ok=True)
        def emit(message):
            stamp=datetime.now(timezone.utc).isoformat(timespec='seconds')
            with log.open('a',encoding='utf-8') as output: output.write(stamp+' '+str(message)+'\n')
            print(message,flush=True)
        emit('REFRESH START')
        try:
            refresh_catalog(config,non_interactive=not args.interactive,emit=emit)
        except Exception as exc:
            state=re.search(r'SQLSTATE=([A-Z0-9]{5})',str(exc))
            emit('REFRESH FAILED: '+type(exc).__name__+((' SQLSTATE='+state.group(1)) if state else ''))
            raise
    except (RuntimeError,ValueError,FileNotFoundError) as exc: raise SystemExit(str(exc)) from None


if __name__=='__main__': main()
