"""Local, optional multilingual embedding retrieval for unverified field suggestions.

No network calls, SQL reads, hidden vocabulary expansion or model fine-tuning.
A model must be explicitly provisioned into the local path by an administrator.
Similarity is a *retrieval signal*, not calibrated likelihood or business equivalence.
"""
from __future__ import annotations
from functools import lru_cache
from collections import OrderedDict
from pathlib import Path
from threading import RLock
import os
import re
from typing import Any

MODEL_HOME = Path.home() / 'OJT2_Discovery_Data' / 'models' / 'multilingual_field_embeddings'
MODEL_PATH = Path(os.environ.get('OJT2_SEMANTIC_MODEL_PATH', str(MODEL_HOME))).expanduser()
MIN_COSINE = 0.43  # Candidate retrieval, not auto-match threshold
_EMBED_CACHE: OrderedDict[str, Any] = OrderedDict()
_CACHE_LOCK = RLock()
_MAX_EMBED_CACHE = 12000
_LAST_ERROR = ''
_MODEL_FINGERPRINTS = {}


def semantic_status() -> dict[str, str | bool]:
    """Public status without downloading or loading a model."""
    model = Path(os.environ.get('OJT2_SEMANTIC_MODEL_PATH', str(MODEL_HOME))).expanduser()
    if not (model.is_dir() and (model / 'modules.json').is_file()):
        return {'ready': False, 'reason': 'MODEL_NOT_PROVISIONED', 'path': str(model)}
    try:
        import importlib.util
        if importlib.util.find_spec('sentence_transformers') is None:
            return {'ready': False, 'reason': 'DEPENDENCY_NOT_INSTALLED', 'path': str(model)}
    except (ImportError, ValueError):
        return {'ready': False, 'reason': 'DEPENDENCY_NOT_INSTALLED', 'path': str(model)}
    if _LAST_ERROR:
        return {'ready': False, 'reason': f'MODEL_LOAD_ERROR: {_LAST_ERROR}', 'path': str(model)}
    return {'ready': True, 'reason': 'LOCAL_MODEL_AVAILABLE', 'path': str(model)}


@lru_cache(maxsize=2)
def _load_model(path: str):
    global _LAST_ERROR
    try:
        # Local filesystem path and OFFLINE flag prohibit accidental requests to a hub.
        os.environ['HF_HUB_OFFLINE'] = '1'
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
        import torch
        configured=os.environ.get('OJT2_SEMANTIC_THREADS') or os.environ.get('OMP_NUM_THREADS')
        threads=int(configured.split(',')[0]) if configured else min(4,os.cpu_count() or 1)
        if threads<1:
            raise ValueError('Semantic CPU thread count must be positive')
        torch.set_num_threads(threads)
        from sentence_transformers import SentenceTransformer
        result = SentenceTransformer(path, device='cpu', local_files_only=True,
                                     trust_remote_code=False)
        _LAST_ERROR = ''
        return result
    except Exception as exc:
        _LAST_ERROR = f'{type(exc).__name__}: {str(exc)[:180]}'
        raise


def _encode(texts: list[str]) -> list[Any] | None:
    """Cache model embeddings across Streamlit reruns; batch new texts."""
    if not semantic_status()['ready']:
        return None
    model_path = semantic_status()['path']
    from ojt2_precomputed import model_key, cached_vectors
    fingerprint=model_key(model_path)
    keys = [model_path + '\0' + fingerprint + '\0' + t for t in texts]
    with _CACHE_LOCK:
        previous=_MODEL_FINGERPRINTS.get(model_path)
        if previous is not None and previous!=fingerprint:
            _EMBED_CACHE.clear()
            if hasattr(_load_model,'cache_clear'): _load_model.cache_clear()
        _MODEL_FINGERPRINTS[model_path]=fingerprint
        missing = list(dict.fromkeys(k for k in keys if k not in _EMBED_CACHE))
        if missing:
            stored=cached_vectors(fingerprint,[k.split('\0',2)[2] for k in missing])
            for k in missing:
                text=k.split('\0',2)[2]
                if text in stored: _EMBED_CACHE[k]=stored[text]
            missing=[k for k in missing if k not in _EMBED_CACHE]
        if missing:
            try:
                model = _load_model(model_path)
                fresh = model.encode([k.split('\0', 2)[2] for k in missing],
                    batch_size=32, show_progress_bar=False, normalize_embeddings=True,
                    convert_to_numpy=True)
            except Exception:
                return None
            for k, v in zip(missing, fresh):
                _EMBED_CACHE[k] = v
        for k in keys:
            _EMBED_CACHE.move_to_end(k)
        result=[_EMBED_CACHE[k] for k in keys]
        while len(_EMBED_CACHE)>_MAX_EMBED_CACHE:
            _EMBED_CACHE.popitem(last=False)
        return result


def _words(value: str) -> str:
    s = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1 \2', str(value or ''))
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', s)
    return re.sub(r'[_\-]+', ' ', s).strip()


def _safe_context(value: str, n: int = 240) -> str:
    # Description metadata only; never introspect SQL values, secrets or rows.
    return re.sub(r'\s+', ' ', str(value or '')).strip()[:n]


def _dot(a: Any, b: Any) -> float:
    # Works with numpy vectors and Python lists; no dependency at import time.
    return float(sum(float(x) * float(y) for x, y in zip(a, b)))


def _semantic_inputs(columns, requested, object_name, purpose, source_hint):
    from ojt2_requirement_semantics import decompose_requirement
    req = decompose_requirement(requested)
    query = ('Requested data field: ' + _words(req.label) + '. '
             + ('Requirement notes: ' + _safe_context(req.note, 150) + '. ' if req.note else '')
             + ('Business purpose: ' + _safe_context(purpose) + '. ' if purpose else '')
             + ('Application or source hint: ' + _safe_context(source_hint, 160) + '. ' if source_hint else ''))
    candidates = [
        'Database output field: ' + _words(c['column_name']) + '. '
        + 'Source object: ' + _words(object_name) + '. '
        + ('Column description: ' + _safe_context(c.get('description') or c.get('column_description')) + '. '
           if c.get('description') or c.get('column_description') else '')
        for c in columns
    ]
    # Label-only multilingual evidence prevents shared table/purpose boilerplate
    # from making every column look similar. Context still provides a secondary
    # signal. Legacy deterministic encoders exercise the original context path.
    from ojt2_field_language import identifier_tokens, attribute_conflicts
    from ojt2_field_matching import BASE_TERMS, GENERAL_ENDINGS
    label_texts = [' '.join(identifier_tokens(req.label, BASE_TERMS, GENERAL_ENDINGS))]
    label_texts += [' '.join(identifier_tokens(c['column_name'], BASE_TERMS, GENERAL_ENDINGS)) for c in columns]
    return req, label_texts, [query,*candidates]


def warm_semantic_cache(entries, fields, purpose="", source_hint=""):
    """Batch only authorized catalog texts; same embeddings and scores as lazy retrieval."""
    if not semantic_status()["ready"]:
        return
    texts={}
    for object_name,columns in entries:
        for requested in fields:
            _,labels,context=_semantic_inputs(columns,requested,object_name,purpose,source_hint)
            texts.update(dict.fromkeys(labels+context))
            if len(texts)>_MAX_EMBED_CACHE:
                return  # large catalogs keep bounded lazy batches rather than thrash cache
    if texts:
        _encode(list(texts))


def semantic_candidates(columns: list[dict], requested: str, *,
                        object_name: str = '', purpose: str = '', source_hint: str = '',
                        limit: int = 6, min_cosine: float = MIN_COSINE,
                        encoder=None) -> list[dict]:
    """Return provisional top-N semantic candidates, even with no lexical overlap.

    `encoder` is for *deterministic tests only* and must accept a list of strings
    and return normalized embedding vectors. Normal execution uses local model.
    """
    from ojt2_semantic_rerank import rerank_semantic_field
    from ojt2_field_matching import _identifier_conflict, split_tokens, MEASUREMENT_UNITS
    from ojt2_field_language import attribute_conflicts
    if not columns or not str(requested).strip():
        return []
    req,label_texts,context_texts=_semantic_inputs(columns,requested,object_name,purpose,source_hint)
    size = len(columns)+1
    encoded = encoder(context_texts) if encoder else _encode(label_texts+context_texts)
    if encoded is None or len(encoded) != (size if encoder else 2*size):
        return []
    label_vectors = None if encoder else encoded[:size]
    vectors = encoded if encoder else encoded[size:]
    qvec = vectors[0]
    result = []
    req_units = set(split_tokens(req.label)) & set(MEASUREMENT_UNITS)
    for col_index, (col, vec) in enumerate(zip(columns, vectors[1:])):
        actual = col['column_name']
        if _identifier_conflict(req.label, actual):
            continue
        col_units = set(split_tokens(actual)) & set(MEASUREMENT_UNITS)
        if req_units and col_units and req_units != col_units:
            continue
        conflicts=attribute_conflicts(set(split_tokens(req.label)), set(split_tokens(actual)))
        context_sim = _dot(qvec, vec)
        label_sim = _dot(label_vectors[0], label_vectors[col_index+1]) if label_vectors is not None else None
        sim = .85*label_sim+.15*context_sim if label_sim is not None else context_sim
        if sim < min_cosine:
            continue
        # Cosine is an uncalibrated retrieval score. A domain-agnostic second
        # pass checks role, temporal direction and attribute shape, without
        # changing any PIC approval, mapped coverage or JOIN decision.
        review = rerank_semantic_field(req.label, actual, sim,
                    object_name=object_name, sql_type=col.get('sql_type',''),
                    requirement_note=req.note)
        adjustments = '; '.join(review.adjustments) or 'no extra structural evidence'
        evidence = (f'Raw multilingual cosine={sim:.3f}; adjusted ranking signal={review.score:.3f}; '
                    f'generic reranking: {adjustments}; '
                    f'object context={object_name or "unspecified"}; '
                    'relation remains a hypothesis, not proof of role, event, unit, formula or grain. PIC review required.')
        if req.formula:
            evidence += ' Required formula must be compared against SQL definition.'
        result.append({'actual': actual, 'status': 'SEMANTIC_REVIEW',
                       'rank_score': review.score,
                       'semantic_similarity': round(sim, 3),
                       'field_similarity': round(label_sim,3) if label_sim is not None else None,
                       'context_similarity': round(context_sim,3),
                       'semantic_rerank_score': review.score,
                       'semantic_risk_flags': list(dict.fromkeys((*review.flags,*conflicts))),
                       'evidence': evidence, 'factor': 0.0})
    result.sort(key=lambda x: (-x['rank_score'], x['actual'].casefold()))
    return result[:max(1,limit)]
