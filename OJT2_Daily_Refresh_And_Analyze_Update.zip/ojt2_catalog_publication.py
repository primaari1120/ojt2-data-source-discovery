"""Publish immutable metadata + lineage + index generations through one pointer.

Readers pin one generation per run. File replacement never overwrites an open
SQLite file on Windows. Previous generations are retained for rollback.
"""
from __future__ import annotations

from contextlib import contextmanager,closing
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile
import time
from uuid import uuid4

ROOT=Path(__file__).resolve().parent


def pointer_path(base): return Path(str(Path(base))+'.current.json')
def status_path(base): return Path(str(Path(base))+'.refresh.json')


def _pid_alive(pid):
    if type(pid) is not int or pid<=0:return False
    if os.name=='nt':
        import ctypes
        from ctypes import wintypes
        api=ctypes.WinDLL('kernel32',use_last_error=True)
        api.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];api.OpenProcess.restype=wintypes.HANDLE
        api.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];api.GetExitCodeProcess.restype=wintypes.BOOL
        api.CloseHandle.argtypes=[wintypes.HANDLE];api.CloseHandle.restype=wintypes.BOOL
        handle=api.OpenProcess(0x1000,False,pid)
        if not handle:return ctypes.get_last_error()==5
        try:
            code=wintypes.DWORD()
            return bool(api.GetExitCodeProcess(handle,ctypes.byref(code)) and code.value==259)
        finally:api.CloseHandle(handle)
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False
    except PermissionError:return True


def prune_generations(base,keep):
    if keep==0:return
    current=resolve_catalog(base)
    folder=current.parent
    files=sorted((p for p in folder.glob('*.sqlite') if re.fullmatch('[a-f0-9]{32}\\.sqlite',p.name)),key=lambda p:p.stat().st_mtime_ns,reverse=True)
    retained={current,*[p for p in files if p!=current][:keep-1]}
    for path in files:
        if path not in retained:
            try:path.unlink()
            except OSError:pass  # Windows reader can still hold an older generation; retry next refresh.


def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            json.dump(value,stream,ensure_ascii=False,allow_nan=False);stream.flush();os.fsync(stream.fileno())
        for attempt in range(10):
            try:
                os.replace(name,path);break
            except PermissionError:
                if attempt==9:raise
                time.sleep(.05)  # short Windows reader/antivirus sharing conflict
    finally:
        Path(name).unlink(missing_ok=True)


def resolve_catalog(base):
    base=Path(base).expanduser().resolve()
    pointer=pointer_path(base)
    if not pointer.is_file(): return base
    value=json.loads(pointer.read_text(encoding='utf-8'))
    name=value.get('generation','')
    if value.get('version')!=1 or not isinstance(name,str) or Path(name).name!=name or not name.endswith('.sqlite'):
        raise RuntimeError('Pointer katalog tidak valid.')
    folder=base.parent/(base.name+'.versions')
    target=(folder/name).resolve()
    if target.parent!=folder.resolve() or not target.is_file():
        raise RuntimeError('Generation katalog tidak ditemukan atau di luar folder publikasi.')
    return target


def refresh_status(base, *, now=None):
    result={}
    try:
        path=resolve_catalog(base)
        with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)) as cn:
            row=cn.execute('SELECT indexed_at FROM catalog_runs ORDER BY run_id DESC LIMIT 1').fetchone()
        stamp=datetime.fromisoformat(row[0].replace('Z','+00:00')) if row else None
        if stamp is not None and stamp.tzinfo is None: stamp=stamp.replace(tzinfo=timezone.utc)
        age=max(0,((now or datetime.now(timezone.utc))-stamp).total_seconds()) if stamp else None
        result={'indexed_at':stamp.isoformat() if stamp else None,'age_hours':age/3600 if age is not None else None,
                'stale':age is None or age>86400,'catalog':str(path)}
    except (OSError,ValueError,sqlite3.Error,RuntimeError):result={'stale':True,'age_hours':None}
    try: result['job']=json.loads(status_path(base).read_text(encoding='utf-8'))
    except (OSError,ValueError):result['job']={}
    if result['job'].get('state')=='running' and not _pid_alive(result['job'].get('pid')):
        result['job']['state']='interrupted'
    return result


@contextmanager
def publication_lock(base):
    path=Path(str(base)+'.refresh.lock');path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as stream:
        stream.seek(0,2)
        if stream.tell()==0: stream.write(b'0');stream.flush()
        stream.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError: raise RuntimeError('Refresh lain masih berjalan; publikasi paralel dibatalkan.') from None
        try: yield
        finally:
            stream.seek(0)
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(),fcntl.LOCK_UN)


def validate_generation(path):
    from ojt2_catalog_scope import validate_catalog_scope
    with closing(sqlite3.connect(Path(path).as_uri()+'?mode=ro',uri=True)) as cn:
        cn.row_factory=sqlite3.Row
        if cn.execute('PRAGMA quick_check').fetchone()[0]!='ok': raise RuntimeError('SQLite quick_check gagal.')
        objects=[dict(r) for r in cn.execute('SELECT * FROM catalog_objects')]
        validate_catalog_scope(cn,objects)
        latest=cn.execute('SELECT MAX(run_id) FROM catalog_runs').fetchone()[0]
        counts=cn.execute('SELECT object_count,column_count,dependency_count FROM catalog_runs WHERE run_id=?',(latest,)).fetchone()
        actual=tuple(cn.execute('SELECT COUNT(*) FROM '+table).fetchone()[0] for table in ('catalog_objects','catalog_columns','catalog_dependencies'))
        if tuple(counts)!=actual:raise RuntimeError('Jumlah metadata tidak sesuai manifest extraction run.')
        line=cn.execute('SELECT source_run_id FROM lineage_runs ORDER BY id DESC LIMIT 1').fetchone()
        if not line or line[0]!=latest: raise RuntimeError('Lineage belum sesuai metadata terbaru.')
        bad=cn.execute('''SELECT COUNT(*) FROM catalog_columns c LEFT JOIN catalog_objects o ON o.object_key=c.object_key
            WHERE o.object_key IS NULL''').fetchone()[0]
        if bad: raise RuntimeError('Kolom katalog tanpa objek induk.')
        if not cn.execute("SELECT 1 FROM precomputed_info WHERE key='build'").fetchone():
            raise RuntimeError('Artifact pencarian belum selesai.')
        return {'run_id':latest,'objects':len(objects)}


def _lineage(path):
    result=subprocess.run([sys.executable,str(ROOT/'09_build_lineage_edges.py'),'--catalog',str(path)],
        cwd=ROOT,capture_output=True,text=True)
    if result.returncode: raise RuntimeError('Pembangunan lineage gagal. Generation sebelumnya tetap aktif.')


def refresh_catalog(config, *, non_interactive=True, collector=None, lineage=None, prepare=None, emit=print):
    from ojt2_multi_server import inspect_sources
    from ojt2_precomputed import prepare_catalog
    collector=collector or inspect_sources;lineage=lineage or _lineage;prepare=prepare or prepare_catalog
    base=Path(config['catalog_path']).resolve()
    with publication_lock(base):
        generation=uuid4().hex+'.sqlite'
        folder=base.parent/(base.name+'.versions');folder.mkdir(parents=True,exist_ok=True)
        stage=folder/generation
        started=datetime.now(timezone.utc).isoformat(timespec='seconds')
        status={'version':1,'state':'running','started_at':started,'phase':'collect','pid':os.getpid()}
        atomic_json(status_path(base),status)
        published=False
        try:
            previous=resolve_catalog(base)
            if previous.is_file():
                with closing(sqlite3.connect(previous.as_uri()+'?mode=ro',uri=True)) as source,closing(sqlite3.connect(stage)) as target:
                    source.backup(target)
            scoped=dict(config,catalog_path=stage)
            collector(scoped,mode='sync',non_interactive=non_interactive,emit=emit)
            status['phase']='lineage';atomic_json(status_path(base),status)
            lineage(stage)
            status['phase']='prepare';atomic_json(status_path(base),status)
            artifacts=prepare(stage,emit=emit)
            validated=validate_generation(stage)
            # No active file is touched until every stage above has completed.
            pointer={'version':1,'generation':generation,'published_at':datetime.now(timezone.utc).isoformat(timespec='seconds'),
                     'metadata_run':validated['run_id']}
            atomic_json(pointer_path(base),pointer);published=True
            status.update(state='success',phase='complete',finished_at=pointer['published_at'],metadata_run=validated['run_id'],artifacts=artifacts)
            atomic_json(status_path(base),status)
            try:prune_generations(base,config.get('keep_generations',3))
            except OSError:pass
            emit('CATALOG PUBLISHED: '+str(stage))
            return stage
        except BaseException as exc:
            # Never put arbitrary exception text (possibly a credential) in status/log.
            if not published:
                status.update(state='failed',finished_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),error_type=type(exc).__name__)
                atomic_json(status_path(base),status)
                stage.unlink(missing_ok=True)
            raise
