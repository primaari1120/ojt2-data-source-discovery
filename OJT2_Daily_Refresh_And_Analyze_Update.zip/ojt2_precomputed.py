"""Optional, exact-value token/vector artifacts in an immutable catalog generation.

Cache miss, version mismatch or damaged row always falls back to normal matching.
Only metadata strings and numeric vectors are stored; no pickle/code loading.
"""
from __future__ import annotations
from array import array
from contextlib import closing
from functools import lru_cache
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import sqlite3
import sys
from threading import RLock

_LOCK=RLock()
_READER=None
_READER_KEY=None
SCHEMA='''
CREATE TABLE IF NOT EXISTS precomputed_tokens (
 rules_key TEXT NOT NULL, text TEXT NOT NULL, tokens TEXT NOT NULL, checksum TEXT NOT NULL,
 PRIMARY KEY(rules_key,text));
CREATE TABLE IF NOT EXISTS precomputed_vectors (
 model_key TEXT NOT NULL, text TEXT NOT NULL, dtype TEXT NOT NULL,
 dimension INTEGER NOT NULL, vector BLOB NOT NULL, checksum TEXT NOT NULL, PRIMARY KEY(model_key,text));
CREATE TABLE IF NOT EXISTS precomputed_info (key TEXT PRIMARY KEY,value TEXT NOT NULL);
'''


def _checksum(*values):
    digest=hashlib.sha256()
    for value in values:
        blob=value if isinstance(value,bytes) else str(value).encode('utf-8')
        digest.update(str(len(blob)).encode()+b':'+blob)
    return digest.hexdigest()


@lru_cache(maxsize=4)
def _code_revision(signature):
    digest=hashlib.sha256()
    for name,_,_ in signature: digest.update(Path(name).read_bytes())
    return digest.hexdigest()


@lru_cache(maxsize=64)
def _rules_key(signature,revision):
    return hashlib.sha256(json.dumps([signature,revision],ensure_ascii=False).encode()).hexdigest()


def rules_key(signature):
    root=Path(__file__).resolve().parent
    paths=[root/n for n in ('ojt2_field_matching.py','ojt2_field_language.py','ojt2_term_rules.py','ojt2_precomputed.py')]
    revision=_code_revision(tuple((str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in paths))
    return _rules_key(signature,revision)


def engine_revision():
    root=Path(__file__).resolve().parent
    names=('ojt2_term_rules.py','ojt2_precomputed.py','ojt2_adaptive_core.py','ojt2_gap_engine.py','ojt2_field_matching.py',
           'ojt2_field_language.py','ojt2_semantic_engine.py','ojt2_semantic_rerank.py',
           'ojt2_requirement_semantics.py','ojt2_candidate_ranking.py',
           'ojt2_shared_learning.py','ojt2_bilingual_lexicon.py','ojt2_bilingual_lexicon.json.gz')
    return _code_revision(tuple((str(root/n),(root/n).stat().st_mtime_ns,(root/n).stat().st_size) for n in names))


@lru_cache(maxsize=4)
def _model_key(signature):
    digest=hashlib.sha256()
    for name,_,_ in signature:
        p=Path(name);digest.update(p.name.encode())
        with p.open('rb') as stream:
            for chunk in iter(lambda:stream.read(1024*1024),b''): digest.update(chunk)
    return digest.hexdigest()


@lru_cache(maxsize=1)
def _backend_versions():
    result=[]
    for name in ('sentence-transformers','transformers','tokenizers','torch','numpy'):
        try:value=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:value='not-installed'
        result.append((name,value))
    return tuple(result)


def model_key(path):
    path=Path(path).resolve()
    if not path.is_dir(): return str(path)
    files=sorted(p for p in path.rglob('*') if p.is_file() and not any(part.startswith('.') for part in p.relative_to(path).parts))
    weights=_model_key(tuple((str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in files))
    return hashlib.sha256(json.dumps([weights,_backend_versions()]).encode()).hexdigest()


def _reader():
    global _READER,_READER_KEY
    raw=os.environ.get('OJT2_PRECOMPUTED_PATH')
    if not raw: return None
    path=Path(raw).expanduser().resolve()
    try: key=(str(path),path.stat().st_mtime_ns,path.stat().st_size)
    except OSError: return None
    if key!=_READER_KEY:
        if _READER is not None: _READER.close()
        _READER=None;_READER_KEY=key
        cn=None
        try:
            cn=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,check_same_thread=False)
            tables={r[0] for r in cn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not {'precomputed_tokens','precomputed_vectors'}.issubset(tables): cn.close();return None
            _READER=cn
        except sqlite3.Error:
            if cn is not None:cn.close()
            return None
    return _READER


def close_reader():
    global _READER,_READER_KEY
    with _LOCK:
        if _READER is not None: _READER.close()
        _READER=None;_READER_KEY=None


def _vector_value(key,text,dtype,dim,blob,checksum):
    if dtype not in {'f','d'} or not 1<=dim<=4096: return None
    if checksum!=_checksum(key,text,dtype,dim,blob): return None
    values=array(dtype)
    try: values.frombytes(blob)
    except (ValueError,TypeError): return None
    if sys.byteorder!='little':values.byteswap()
    return values if len(values)==dim and all(math.isfinite(v) for v in values) else None


def cached_tokens(text,signature):
    with _LOCK:
        cn=_reader()
        if cn is None: return None
        try:
            key=rules_key(signature)
            row=cn.execute('SELECT tokens,checksum FROM precomputed_tokens WHERE rules_key=? AND text=?',(key,text)).fetchone()
            if row and row[1]!=_checksum(key,text,row[0]): return None
            value=json.loads(row[0]) if row else None
            return tuple(value) if isinstance(value,list) and all(isinstance(t,str) for t in value) else None
        except (sqlite3.Error,ValueError,TypeError): return None


def cached_vectors(key,texts):
    result={}
    with _LOCK:
        cn=_reader()
        if cn is None: return result
        try:
            for offset in range(0,len(texts),400):
                batch=texts[offset:offset+400]
                sql='SELECT text,dtype,dimension,vector,checksum FROM precomputed_vectors WHERE model_key=? AND text IN ('+','.join('?' for _ in batch)+')'
                for text,dtype,dim,blob,checksum in cn.execute(sql,[key,*batch]):
                    values=_vector_value(key,text,dtype,dim,blob,checksum)
                    if values is not None:result[text]=values
        except sqlite3.Error: return {}
    return result


def put_vectors(cn,key,texts,vectors):
    rows=[]
    for text,vector in zip(texts,vectors):
        dtype='f' if str(getattr(vector,'dtype',''))=='float32' else 'd'
        values=array(dtype,(float(v) for v in vector))
        if not values or not all(math.isfinite(v) for v in values): raise ValueError('Embedding cache mempunyai nilai tidak valid.')
        if sys.byteorder!='little': values.byteswap()
        blob=values.tobytes()
        rows.append((key,text,dtype,len(values),blob,_checksum(key,text,dtype,len(values),blob)))
    cn.executemany('INSERT OR REPLACE INTO precomputed_vectors VALUES (?,?,?,?,?,?)',rows)


def prepare_catalog(path, *, emit=print):
    """Build reusable artifacts; no change to retrieval thresholds or field scoring."""
    from ojt2_field_matching import BASE_TERMS, get_term_rules, split_tokens
    from ojt2_adaptive_core import DOMAIN_RULES
    from ojt2_semantic_engine import semantic_status,_load_model,_semantic_inputs
    old=os.environ.pop('OJT2_PRECOMPUTED_PATH',None)
    try:
        with closing(sqlite3.connect(path)) as cn:
            cn.executescript(SCHEMA)
            cn.execute('DELETE FROM precomputed_tokens')
            # Include every name. No pruning of objects/columns for Analyze.
            names=[r[0] for r in cn.execute('SELECT DISTINCT column_name FROM catalog_columns UNION SELECT object_name FROM catalog_objects')]
            signatures={tuple(sorted(BASE_TERMS.items()))}
            signatures.update(tuple(sorted(get_term_rules(d).items())) for d in [None,*DOMAIN_RULES])
            for signature in signatures:
                terms=dict(signature);key=rules_key(signature)
                def token_rows():
                    for text in names:
                        tokens=json.dumps(split_tokens(text,terms))
                        yield (key,text,tokens,_checksum(key,text,tokens))
                cn.executemany('INSERT INTO precomputed_tokens VALUES (?,?,?,?)',token_rows())
            semantic=semantic_status();vector_count=0
            if semantic['ready']:
                model=_load_model(semantic['path']);key=model_key(semantic['path'])
                # Keep matching vectors already built for this exact model; drop obsolete versions.
                cn.execute('DELETE FROM precomputed_vectors WHERE model_key<>?',(key,))
                seen=set()
                batch=[]
                def flush():
                    nonlocal vector_count
                    if not batch: return
                    fresh=[]
                    for text in batch:
                        row=cn.execute('SELECT dtype,dimension,vector,checksum FROM precomputed_vectors WHERE model_key=? AND text=?',(key,text)).fetchone()
                        if row is None or _vector_value(key,text,*row) is None:fresh.append(text)
                    if fresh:
                        vectors=model.encode(fresh,batch_size=32,show_progress_bar=False,normalize_embeddings=True,convert_to_numpy=True)
                        put_vectors(cn,key,fresh,vectors)
                    vector_count+=len(batch);batch.clear()
                for name,column in cn.execute('''SELECT DISTINCT o.object_name,c.column_name FROM catalog_objects o
                    JOIN catalog_columns c ON c.object_key=o.object_key WHERE trim(o.object_type) IN ('U','V')'''):
                    _,labels,contexts=_semantic_inputs([{'column_name':column}], '', name, '', '')
                    for text in (labels[1],contexts[1]):
                        if text not in seen:
                            seen.add(text);batch.append(text)
                            if len(batch)>=256: flush()
                flush()
                # Remove vectors for metadata no longer in the authorized catalog.
                cn.execute('CREATE TEMP TABLE active_vector_texts(text TEXT PRIMARY KEY)')
                cn.executemany('INSERT INTO active_vector_texts VALUES (?)',((text,) for text in seen))
                cn.execute('DELETE FROM precomputed_vectors WHERE text NOT IN (SELECT text FROM active_vector_texts)')
            else:
                cn.execute('DELETE FROM precomputed_vectors')
            info={'token_names':len(names),'term_signatures':len(signatures),
                  'vector_texts':vector_count,'semantic':semantic['reason']}
            cn.execute('INSERT OR REPLACE INTO precomputed_info VALUES (?,?)',('build',json.dumps(info)))
            cn.commit();emit('PRECOMPUTE: '+json.dumps(info))
            return info
    finally:
        if old is not None: os.environ['OJT2_PRECOMPUTED_PATH']=old
