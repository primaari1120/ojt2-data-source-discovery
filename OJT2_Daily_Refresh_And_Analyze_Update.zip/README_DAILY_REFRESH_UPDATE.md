# OJT2 — credential otomatis, refresh harian, dan cache Analyze

Versi `0.6.3-daily-catalog-cache`, untuk dipasang di atas update multi-server + perbaikan Search Explorer terakhir. Paket ini tidak membawa konfigurasi lokal, credential, metadata perusahaan, history, venv, atau model embedding.

## Yang berubah

- Credential SQL dapat disimpan satu kali di Windows Credential Manager untuk akun Windows saat ini. Collector tidak lagi meminta password bila credential tersedia.
- Job refresh dapat berjalan tanpa interaksi, membangun metadata, lineage, token index, dan embedding metadata yang stabil, lalu memublikasikan satu generation yang lengkap.
- App memakai generation yang sudah siap. Hasil Analyze/cache lama dibuang saat generation berganti.
- UI menunjukkan umur metadata, status refresh, serta tombol Refresh metadata di background untuk app yang dibuka melalui launcher perusahaan.
- Pengurutan vocabulary, segmentasi kata, dan pasangan terjemahan yang sama dapat digunakan kembali. Perubahan term rules mengganti signature cache.
- Katalog dan indeks di RAM digunakan bersama sebagai resource yang dibaca saja. Hasil Analyze berulang di-cache dengan key lengkap: generation, requirement, scope, limit, perubahan history/PIC, kode engine/kamus, dan model.
- Vektor metadata dapat dipersiapkan pada refresh; requirement baru tetap dihitung saat Analyze. Format cache numerik memakai checksum dan fingerprint model; miss/kerusakan memakai perhitungan normal.
- Tidak ada pengurangan scope, hardcode pasangan field baru, pemangkasan Top-K sumber baru, perubahan threshold semantic, atau perubahan bobot ranking.

## A. Pasang update

1. Hentikan Streamlit. Backup source dan folder data aplikasi yang selama ini digunakan.
2. Ekstrak ZIP ke folder aplikasi lama. Replace hanya file yang disertakan.
3. Pertahankan `sql_servers.local.json`, query timeout yang sudah disesuaikan, konfigurasi TLS yang sedang dipakai, logo, venv, vocabulary, model, dan history.

Tidak ada dependency Python baru untuk Credential Manager; API Windows dipanggil melalui standard library `ctypes`. Task Scheduler memakai modul Windows PowerShell ScheduledTasks. Dependency Streamlit/model yang sudah ada tetap digunakan.

## B. Simpan credential satu kali (Windows)

Dari terminal PowerShell VS Code pada folder aplikasi:

```powershell
.\.venv\Scripts\python.exe .\45_manage_credentials.py --save
.\.venv\Scripts\python.exe .\45_manage_credentials.py --status
```

Password tiap sumber SQL diminta dan diulang saat enrollment. Sesudahnya status setiap sumber harus AVAILABLE. Windows Authentication tidak memerlukan password SQL tersimpan. Jangan masukkan password SQL ke JSON, source, perintah Task Scheduler, atau file .env baru.

Credential terikat ke endpoint dan username, sehingga rename label `id` tidak meminta enrollment ulang. Perubahan endpoint/username memerlukan penyimpanan credential untuk identitas baru. Saat password SQL berubah, jalankan `--save` lagi. Untuk satu sumber:

```powershell
.\.venv\Scripts\python.exe .\45_manage_credentials.py --save --server LABEL_DARI_CONFIG
```

Urutan lookup: Credential Manager, environment `password_env` yang sudah didukung, lalu prompt hanya pada mode interactive. Mode non-interactive gagal dengan jelas jika tidak ada credential, tanpa menunggu input. Tidak ada perubahan privilege SQL.

Windows vault adalah milik akun Windows, bukan milik folder source. Job harus memakai akun Windows yang sama. Saat pindah mesin/akun, lakukan enrollment di lingkungan tersebut. Menyalin folder aplikasi tidak memindahkan credential.

## C. Jalankan satu refresh lengkap

```powershell
.\.venv\Scripts\python.exe .\47_refresh_catalog.py --non-interactive
```

Job membaca config lokal yang sudah ada, termasuk jumlah sumber yang didaftarkan (tidak dibatasi tiga), cakupan database, timeout, dan TLS. Job tidak meminta password jika tahap B selesai pada akun Windows yang sama.

Urutan: kumpulkan metadata -> bangun lineage -> precompute -> validasi -> publikasikan pointer. Saat model lokal tersedia, precompute pertama dapat lebih lama karena embedding metadata disiapkan. Tidak ada unduhan model otomatis.

Hasil akhir yang dicari adalah `CATALOG PUBLISHED`. Jika ada kegagalan sebelum publikasi, pointer tidak berubah dan katalog sebelumnya tetap aktif. Job menyimpan status dan log lokal; kesalahan koneksi dicatat dengan SQLSTATE, bukan raw credential/diagnostic.

## D. Buka aplikasi

```powershell
.\.venv\Scripts\python.exe .\43_start_company_local.py
```

Launcher mengikuti pointer terbaru dan membuka app di 127.0.0.1. Search/Analyze tidak melakukan login SQL. Model lokal dapat disiapkan saat app dibuka agar waktu load model tidak baru dibayar ketika Analyze pertama.

`43 --refresh` masih didukung, tetapi sekarang memakai job lengkap 47 terlebih dahulu. Untuk manual refresh yang boleh meminta password jika vault belum tersedia, gunakan `43 --refresh --interactive` atau `47 --interactive`. Scheduler dan tombol UI selalu non-interactive.

`41 --check` dan `41 --list-databases` tetap tersedia dan sekarang dapat memakai vault. `41 --sync` diarahkan ke pipeline lengkap agar metadata tidak terpisah dari lineage/index. Jangan memakai pasangan refresh lama 41 lalu 09 untuk publikasi harian. Script 09 tetap dipakai internal oleh pipeline dan untuk demo/legacy sesuai kebutuhannya.

Tombol Refresh metadata memulai job background. Status UI dibaca lagi saat halaman berinteraksi/rerun; tampilan lama yang dibiarkan diam tidak dipaksa polling terus-menerus. Analyze memakai generation yang dipilih pada awal run. Saat generation baru dibaca, hasil sebelumnya diminta di-Analyze ulang.

## E. Pasang jadwal harian

Lihat rencana tanpa memasang task:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\48_install_daily_refresh.ps1 -At "06:00" -DryRun
```

Jadwal menggunakan waktu lokal Windows. Pastikan zona waktu mesin sesuai jadwal yang diinginkan.

Pemasangan sederhana, berjalan saat akun Windows masih login (layar terkunci tetap termasuk login):

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\48_install_daily_refresh.ps1 -At "06:00"
```

Untuk tetap dapat berjalan saat user logout, gunakan pilihan ini SEBAGAI PENGGANTI pemasangan sederhana:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\48_install_daily_refresh.ps1 -At "06:00" -RunWhenLoggedOff
```

Pilihan tersebut meminta credential Windows akun yang sama, bukan password SQL dan bukan Windows Hello PIN. Windows Task Scheduler menyimpan logon credential melalui mekanismenya sendiri; credential tidak ditulis ke source/action argument. Hak logon batch dan kebijakan mesin tetap berlaku. Penggunaan ExecutionPolicy Bypass di atas terbatas pada proses tersebut; tidak mengganti policy global.

Installer menolak menimpa task bernama sama. Periksa task lama di Task Scheduler bila sebelumnya sudah memasang, atau tentukan `-TaskName` lain secara sengaja. Jangan memasang kedua mode sebagai dua job untuk kebutuhan yang sama.

Task mempunyai StartWhenAvailable, permintaan wake, retry 3 kali tiap 30 menit, batas 8 jam, dan IgnoreNew untuk instance task yang sama. Collector juga mempunyai lock lintas proses, termasuk ketika Refresh manual dan job harian bersamaan.

Mesin tetap harus menyala dan jaringan/VPN tersedia. Scheduler tidak dapat memastikan pembaruan harian ketika mesin mati atau konektivitas tidak tersedia. Untuk operasi harian yang andal, tempatkan collector pada mesin perusahaan yang tersedia sepanjang waktu. Katalog lebih dari 24 jam ditandai stale; app tidak menyatakan data lama sebagai refresh sukses.

Uji task setelah pemasangan:

```powershell
Start-ScheduledTask -TaskName "OJT2-Daily-Metadata-Refresh"
Get-ScheduledTaskInfo -TaskName "OJT2-Daily-Metadata-Refresh"
```

Periksa LastTaskResult setelah proses selesai dan status refresh pada app. `0` berarti job selesai normal; `267009`/0x41301 berarti task masih berjalan. Native Credential Manager dan Task Scheduler perlu diverifikasi di Windows pengguna; environment pengujian cloud ini Linux.

## F. Lokasi dan retensi

Untuk `catalog_path` yang sudah ada, misalnya `company_metadata_catalog.sqlite`, pipeline menambahkan:

```text
company_metadata_catalog.sqlite.current.json       pointer generation aktif
company_metadata_catalog.sqlite.refresh.json       status job
company_metadata_catalog.sqlite.refresh.log        progress/SQLSTATE
company_metadata_catalog.sqlite.refresh.launcher.log  error startup job dari UI
company_metadata_catalog.sqlite.refresh.lock       lock proses; keberadaan file bukan bukti job masih berjalan
company_metadata_catalog.sqlite.versions/          katalog lengkap beserta indeks
```

File katalog lama tetap tersedia dan menjadi fallback sebelum pointer pertama dibuat. SQLite history/feedback terpisah tidak diganti atau dimigrasikan.

Default menyimpan tiga generation terbaru yang dikelola pipeline, termasuk generation aktif. File legacy, file manual, dan history tidak ikut dibersihkan. Generation lama yang masih terkunci oleh reader Windows dilewati dan dicoba lagi pada refresh berikutnya. Atur top-level `"keep_generations": 0` pada config untuk menyimpan semuanya; nilai 2..365 mengatur jumlah yang dipertahankan. Pilihan semua generation memerlukan pengelolaan ruang disk sendiri.

Rollback source: hentikan app dan pulihkan backup source. Snapshot legacy dan history tetap dipertahankan. Pertahankan folder generation/pointer untuk audit/pemulihan; jangan menghapusnya saat app/job aktif. Untuk menggunakan source lama yang belum mengerti pointer, arahkan katalog ke file legacy yang sesuai.

## G. Path runtime yang konsisten

Jika app sebelumnya memakai path history atau model khusus melalui environment terminal, nyatakan juga pada config agar job dan app memakai lokasi yang sama. Contoh top-level opsional:

```json
"runtime": {
  "app_data_dir": "D:/OJT2_Data",
  "semantic_model_path": "D:/OJT2_Models/multilingual_field_embeddings"
}
```

Gunakan lokasi milik instalasi Anda, jangan menyalin contoh path secara buta. Bila tidak diisi, lokasi default dan environment yang tersedia tetap digunakan. Pengaturan ini tidak memindahkan history atau model; hanya menentukan lokasi yang dibaca. Pastikan job Windows dapat membaca model, menulis katalog/status, serta memakai registry PIC yang benar.

## H. Pengujian dan batas benchmark

```powershell
.\.venv\Scripts\python.exe .\46_validate_daily_refresh.py
.\.venv\Scripts\python.exe .\34_validate_generalized_matching.py
.\.venv\Scripts\python.exe .\36_validate_ranking_performance.py
.\.venv\Scripts\python.exe .\38_validate_field_facet_guards.py
.\.venv\Scripts\python.exe .\40_validate_analysis_runtime.py --ui
.\.venv\Scripts\python.exe .\42_validate_multi_server_catalog.py
.\.venv\Scripts\python.exe .\44_validate_explorer_search_consistency.py
.\.venv\Scripts\python.exe .\49_benchmark_analyze_cache.py --objects 150
```

Validator 46 memakai fake SQL, SQLite temporary, fake credential store, dan Streamlit AppTest. Menguji non-interactive credential behavior, atomic failure, lock, generation/lineage consistency, stale status, token/model invalidation, checksum fallback, cache output copy, semua komponen invalidasi Analyze, serta UI refresh/generation. Validator model 35 dapat dijalankan pada instalasi dengan model lokal yang sudah tersedia.

Benchmark sintetis memisahkan first discovery dan cache hit. Hasilnya tidak menjanjikan durasi tertentu untuk metadata perusahaan, model cold start, rendering UI, atau requirement baru. Hasil perbandingan dicantumkan pada laporan paket, termasuk apakah urutan, status, mapping, dan evidence sama. Tidak ada estimasi akurasi produksi dari fixture kecil ini.
