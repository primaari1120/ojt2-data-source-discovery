"""Shared identifier segmentation and bilingual concept evidence.

The starter glossary is deliberately finite. Unseen language is retrieved by
the separately provisioned multilingual model, never silently 'translated' by
inventing SQL names. Everything here operates on metadata strings only.
"""
from __future__ import annotations

from functools import lru_cache
import re
import unicodedata

LANGUAGE_VERSION = '1.0.0'

# Reusable concepts, not requirement-to-column pairs or domain-specific tables.
# Ambiguous words such as nilai/value/amount are handled by contextual evidence
# below rather than equated globally. Existing operator glossary overrides win.
BUILTIN_TERMS = {
    'kontrak':'contract', 'perjanjian':'agreement', 'contract':'contract',
    'agreement':'agreement', 'menara':'tower', 'tower':'tower',
    'gudang':'warehouse', 'warehouse':'warehouse', 'alamat':'address',
    'address':'address', 'keterangan':'description', 'deskripsi':'description',
    'description':'description', 'catatan':'note', 'note':'note',
    'komentar':'comment', 'comment':'comment', 'alasan':'reason', 'reason':'reason',
    'pembayaran':'payment', 'payment':'payment', 'tagihan':'invoice',
    'anggaran':'budget', 'budget':'budget', 'pendapatan':'revenue',
    'revenue':'revenue', 'penjualan':'sales', 'sales':'sales',
    'pembelian':'purchase', 'purchase':'purchase', 'pengeluaran':'expense',
    'expense':'expense', 'saldo':'balance', 'balance':'balance',
    'pajak':'tax', 'tax':'tax', 'diskon':'discount', 'discount':'discount',
    'persentase':'percentage', 'percentage':'percentage',
    'mata':'mata', 'uang':'uang', 'currency':'currency',
    'produk':'product', 'product':'product', 'barang':'item', 'item':'item',
    'bahan':'material', 'material':'material', 'stok':'stock', 'stock':'stock',
    'persediaan':'inventory', 'inventory':'inventory',
    'pengiriman':'shipment', 'shipment':'shipment', 'delivery':'delivery',
    'kendaraan':'vehicle', 'vehicle':'vehicle', 'peralatan':'equipment',
    'equipment':'equipment', 'aset':'asset', 'asset':'asset',
    'pemeliharaan':'maintenance', 'perawatan':'maintenance',
    'maintenance':'maintenance', 'perbaikan':'repair', 'repair':'repair',
    'pemasangan':'installation', 'installation':'installation',
    'kapasitas':'capacity', 'capacity':'capacity', 'berat':'weight', 'weight':'weight',
    'lebar':'width', 'width':'width', 'kedalaman':'depth', 'depth':'depth',
    'kecepatan':'speed', 'speed':'speed', 'suhu':'temperature', 'temperature':'temperature',
    'tekanan':'pressure', 'pressure':'pressure', 'luas':'area',
    'perusahaan':'company', 'company':'company', 'cabang':'branch', 'branch':'branch',
    'divisi':'division', 'division':'division', 'jabatan':'position', 'position':'position',
    'pekerjaan':'job', 'job':'job', 'tim':'team', 'team':'team',
    'pengguna':'user', 'user':'user', 'pemilik':'owner', 'owner':'owner',
    'pemohon':'requester', 'pengaju':'requester', 'requester':'requester',
    'pengusul':'proposer', 'proposer':'proposer',
    'jadwal':'schedule', 'schedule':'schedule', 'durasi':'duration', 'duration':'duration',
    'batas':'limit', 'limit':'limit', 'target':'target',
    'rencana':'plan', 'plan':'plan', 'aktual':'actual', 'actual':'actual',
    'kedaluwarsa':'expiry', 'kadaluarsa':'expiry', 'expiry':'expiry',
    'penerimaan':'receipt', 'receipt':'receipt', 'penerima':'recipient', 'recipient':'recipient',
    'survei':'survey', 'survey':'survey', 'jaringan':'network', 'network':'network',
    'telepon':'phone', 'phone':'phone', 'email':'email',
    'lintang':'latitude', 'latitude':'latitude', 'bujur':'longitude', 'longitude':'longitude',
    'klasifikasi':'classification', 'classification':'classification',
    'prioritas':'priority', 'priority':'priority', 'referensi':'reference', 'reference':'reference',
    'lampiran':'attachment', 'attachment':'attachment', 'dokumen':'document', 'document':'document',
    'transaksi':'transaction', 'transaction':'transaction', 'klaim':'claim', 'claim':'claim',
    'sewa':'rental', 'rental':'rental', 'pelunasan':'settlement', 'settlement':'settlement',
    'keuntungan':'profit', 'profit':'profit', 'kerugian':'loss', 'loss':'loss',
    'skor':'score', 'score':'score', 'peringkat':'rating', 'rating':'rating',
    'nilai':'amount', 'value':'value', 'net':'net', 'gross':'gross',
    'bersih':'net', 'kotor':'gross', 'unit':'unit', 'count':'count',
    'sebelum':'before', 'sesudah':'after', 'setelah':'after',
    'before':'before', 'after':'after', 'berakhir':'end', 'end':'end',
}

# Whole words that must not be destructively split into a spurious ID/KEY.
# This is a lexical boundary guard; it is not a business alias list.
WHOLE_WORDS = frozenset({
    'grid','valid','invalid','liquid','solid','fluid','hybrid','paid','unpaid',
    'said','avoid','void','rapid','android','uuid','guid','rigid','acid',
    'monkey','donkey','turkey','hockey','jockey','whiskey','keyboard',
})
IDENTIFIER_AFFIXES = ('identifier', 'number', 'code', 'key', 'id')


@lru_cache(maxsize=8192)
def _segment(part: str, vocabulary: tuple[str, ...], endings: tuple[str, ...]) -> tuple[str, ...]:
    known = frozenset(vocabulary)
    if part in known or part in WHOLE_WORDS or len(part) < 4:
        return (part,)

    # Prefer a complete, unique dictionary segmentation. It also handles
    # all-lower/all-upper compounds (TOWERNAME, namatower, contractvalue).
    @lru_cache(maxsize=None)
    def paths(start: int):
        if start == len(part):
            return ((),)
        answers = []
        for end in range(start + 2, len(part) + 1):
            term = part[start:end]
            if term in known:
                for tail in paths(end):
                    answers.append((term, *tail))
                    if len(answers) >= 3:
                        return tuple(answers)
        return tuple(answers)

    options = paths(0) if len(part) <= 80 else ()
    if options:
        shortest = min(map(len, options))
        best = [p for p in options if len(p) == shortest]
        if len(best) == 1:
            return best[0]
    # Unknown business abbreviations still retain structural ID/key suffixes.
    # No minimum-five-character rule: POID / PRID are four-character examples.
    for suffix in sorted(set(endings) | set(IDENTIFIER_AFFIXES), key=lambda x: (-len(x), x)):
        if len(suffix) >= 2 and part.endswith(suffix) and len(part)-len(suffix) >= 2:
            prefix = part[:-len(suffix)]
            return (*_segment(prefix, vocabulary, endings), suffix)
    for prefix in IDENTIFIER_AFFIXES:
        if part.startswith(prefix) and len(part)-len(prefix) >= 2:
            return (prefix, *_segment(part[len(prefix):], vocabulary, endings))
    return (part,)


def identifier_tokens(value: str, terms: dict[str, str], endings=()) -> tuple[str, ...]:
    vocabulary=getattr(terms,'vocabulary',None)
    if vocabulary is None: vocabulary=tuple(sorted(set(terms.keys()) | set(terms.values())))
    return _identifier_tokens_cached(str(value or ''),vocabulary,tuple(endings))


@lru_cache(maxsize=16384)
def _identifier_tokens_cached(value: str, supplied: tuple[str,...], endings: tuple[str,...]) -> tuple[str,...]:
    """Ordered, case/separator-insensitive SQL identifier tokens; no translation."""
    text = unicodedata.normalize('NFKD', str(value or '').strip())
    text = ''.join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1 \2', text)
    text = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', text)
    vocabulary = tuple(sorted({t for t in (*supplied,
        *BUILTIN_TERMS.keys(), *BUILTIN_TERMS.values(), *endings, *IDENTIFIER_AFFIXES)
        if t.isalnum() and len(t) >= 2}))
    suffixes = tuple(sorted(set(endings)))
    return tuple(token for part in re.findall(r'[a-z0-9]+', text.casefold())
                 for token in _segment(part, vocabulary, suffixes))


MONEY_SUBJECTS = frozenset({'contract','agreement','payment','invoice','budget',
    'sales','revenue','expense','purchase','order','claim','transaction','rental',
    'settlement','profit','loss','tax','discount'})


def concept_alias(request_tokens: set[str], column_tokens: set[str], sql_type: str = '') -> str | None:
    """Contextual suggestion only: never equate amount/value for every subject."""
    money_words = {'amount', 'value'}
    if not (request_tokens & money_words and column_tokens & money_words):
        return None
    left, right = request_tokens-money_words, column_tokens-money_words
    if not left or left != right or not left & MONEY_SUBJECTS:
        return None
    dtype = str(sql_type or '').lower().split('(')[0]
    if dtype in {'date','datetime','datetime2','time','bit','uniqueidentifier'}:
        return None
    return ('Monetary amount/value vocabulary aligns within the same financial subject; '
            'currency, tax basis, formula and business definition still require PIC review.')


def attribute_conflicts(request_tokens: set[str], column_tokens: set[str]) -> tuple[str, ...]:
    """Contradictions shared by lexical/semantic retrieval, never fuzzy synonyms."""
    pairs = [({'origin','source'}, {'destination'}), ({'start','initial'}, {'end','finish','final'}),
             ({'net'}, {'gross'}), ({'before'}, {'after'})]
    flags = []
    for left, right in pairs:
        if (request_tokens & left and column_tokens & right and not request_tokens & right
                or request_tokens & right and column_tokens & left and not request_tokens & left):
            flags.append('OPPOSITE_QUALIFIER')
    # Distinct attribute kinds are not translations of one another.
    kinds = {'temporal': {'date','time'}, 'money': {'amount','value','price','cost'},
             'quantity': {'quantity','count'}, 'status': {'status'}, 'label': {'name'},
             'measurement': {'height','width','length','distance','weight','depth','temperature','pressure'},
             'location': {'location','address','latitude','longitude'},
             'classification': {'type','category','classification'},
             'organization': {'directorate','department','division','team'},
             'rate': {'rate','percentage','ratio'}}
    q = {kind for kind, words in kinds.items() if request_tokens & words}
    c = {kind for kind, words in kinds.items() if column_tokens & words}
    if q and c and not q & c:
        flags.append('ATTRIBUTE_KIND_CONFLICT')
    geography={'province','region','city','regency','district','subdistrict','village','country'}
    q_geo,c_geo=request_tokens & geography,column_tokens & geography
    if q_geo and c_geo and not q_geo & c_geo:
        flags.append('GEOGRAPHIC_LEVEL_CONFLICT')
    return tuple(flags)
