"""Configured metadata scanner. Source SQL is SELECT-only system metadata.

No business rows, stored procedure execution, or credential persistence.
SQL Server's Intent=ReadOnly is a hint; account privileges remain authoritative.
"""
from __future__ import annotations

from contextlib import closing
from ojt2_credentials import resolve_password
from datetime import datetime, timezone
import getpass
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3

HERE = Path(__file__).resolve().parent


def load_config(path: Path) -> dict:
    path = Path(path).expanduser().resolve()
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    if data.get('version') != 1 or not isinstance(data.get('servers'), list) or not data['servers']:
        raise ValueError('Config memerlukan version=1 dan daftar servers.')
    labels = set()
    keep=data.get('keep_generations',3)
    if type(keep) is not int or keep!=0 and not 2<=keep<=365:
        raise ValueError('keep_generations harus 0 (semua) atau 2..365.')
    for s in data['servers']:
        if set(s) - {'id','server','authentication','username','password_env','databases','trust_server_certificate','expected_server','driver','query_timeout','connection_timeout','discovery_database'}:
            raise ValueError('Field server tidak dikenali. Password harus dari env/prompt, bukan file JSON.')
        label = s.get('id','')
        if not isinstance(label,str) or not re.fullmatch(r'[A-Z][A-Z0-9_]{0,31}',label) or label in labels:
            raise ValueError('id server harus unik, misalnya DGA, IT1, IT2.')
        labels.add(label)
        for key in ('server','authentication'):
            if not isinstance(s.get(key),str) or not s[key].strip():
                raise ValueError(f'{label}: {key} wajib diisi.')
        if s['server'].startswith('REPLACE_'):
            raise ValueError(f'{label}: ganti placeholder server di config lokal.')
        if s['authentication'] not in {'windows','sql'}:
            raise ValueError(f'{label}: authentication harus windows atau sql.')
        databases=s.get('databases')
        if databases!='all_accessible':
            if not isinstance(databases,list) or any(not isinstance(d,str) or not d.strip() or d=='*' for d in databases):
                raise ValueError(f'{label}: databases harus daftar nama eksplisit atau all_accessible.')
            if len({d.casefold() for d in databases}) != len(databases):
                raise ValueError(f'{label}: database duplikat.')
        if not isinstance(s.get('discovery_database','master'),str) or not s.get('discovery_database','master').strip():
            raise ValueError(f'{label}: discovery_database tidak valid.')
        if type(s.get('trust_server_certificate',False)) is not bool:
            raise ValueError('trust_server_certificate harus boolean.')
        if s['authentication']=='sql' and (not isinstance(s.get('username'),str) or not s['username'].strip()):
            raise ValueError(f'{label}: username SQL Login wajib diisi.')
        if 'password_env' in s and (not isinstance(s['password_env'],str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',s['password_env'])):
            raise ValueError(f'{label}: nama password_env tidak valid.')
        for key, default, maximum in [('connection_timeout',15,120),('query_timeout',60,3600)]:
            value=s.get(key,default)
            if type(value) is not int or not 1<=value<=maximum:
                raise ValueError(f'{label}: {key} tidak valid.')
    runtime=data.get('runtime',{})
    if not isinstance(runtime,dict) or set(runtime)-{'app_data_dir','semantic_model_path'}:
        raise ValueError('runtime hanya mendukung app_data_dir dan semantic_model_path.')
    for key,value in list(runtime.items()):
        if not isinstance(value,str) or not value.strip(): raise ValueError('Path runtime tidak valid.')
        target_path=Path(os.path.expandvars(value)).expanduser()
        runtime[key]=str(target_path.resolve() if target_path.is_absolute() else (path.parent/target_path).resolve())
    data['runtime']=runtime
    raw=data.get('catalog_path', '~/OJT2_Discovery_Data/company_metadata_catalog.sqlite')
    target=Path(os.path.expandvars(raw)).expanduser()
    data['catalog_path']=target.resolve() if target.is_absolute() else (path.parent/target).resolve()
    return data


def runtime_environment(config, existing=None):
    env=dict(os.environ if existing is None else existing)
    names={'app_data_dir':'OJT2_APP_DATA_DIR','semantic_model_path':'OJT2_SEMANTIC_MODEL_PATH'}
    for key,value in config.get('runtime',{}).items(): env[names[key]]=value
    return env


def _odbc_value(value: str) -> str:
    if '\x00' in str(value):
        raise ValueError('ODBC value mengandung NUL.')
    return '{'+str(value).replace('}','}}')+'}'


def connection_string(source: dict, driver: str, database: str, password: str | None = None) -> str:
    parts=[f'DRIVER={_odbc_value(driver)}', f'SERVER={_odbc_value(source["server"])}',
           f'DATABASE={_odbc_value(database)}', 'Encrypt=yes',
           'TrustServerCertificate='+('yes' if source.get('trust_server_certificate',False) else 'no'),
           'APP=OJT2 Metadata Scanner','ApplicationIntent=ReadOnly']
    if source['authentication']=='windows':
        parts.append('Trusted_Connection=yes')
    else:
        if not source.get('username') or not password:
            raise ValueError(f'{source["id"]}: SQL username/password belum tersedia.')
        parts.extend([f'UID={_odbc_value(source["username"])}',f'PWD={_odbc_value(password)}'])
    return ';'.join(parts)+';'


def _driver(source, odbc):
    options=[d for d in odbc.drivers() if re.fullmatch(r'ODBC Driver \d+ for SQL Server',d)]
    requested=source.get('driver')
    if requested:
        if requested not in options:
            raise RuntimeError('ODBC driver yang dikonfigurasi tidak tersedia.')
        return requested
    if not options:
        raise RuntimeError('Install Microsoft ODBC Driver 18/17 for SQL Server di laptop.')
    return max(options,key=lambda d:int(re.search(r'\d+',d).group()))


def _legacy():
    # Reuse the established SELECT statements, row shape, keys and SQLite schema.
    spec=importlib.util.spec_from_file_location('_ojt2_metadata_schema', HERE/'07_build_metadata_catalog.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _open(source, driver, database, password, odbc):
    cn=odbc.connect(connection_string(source,driver,database,password), timeout=source.get('connection_timeout',15))
    try:
        cn.timeout=source.get('query_timeout',60)
    except Exception:
        cn.close()
        raise
    return cn


def _identity(cursor, source, database):
    row=cursor.execute('SELECT @@SERVERNAME, DB_NAME()').fetchone()
    physical,actual=row
    if not physical or str(actual).casefold()!=database.casefold():
        raise RuntimeError('Identitas server/database tidak sesuai context koneksi.')
    if source.get('expected_server') and str(physical).casefold()!=source['expected_server'].casefold():
        raise RuntimeError('@@SERVERNAME berbeda dari expected_server yang dikonfigurasi.')
    return str(physical)


def inspect_sources(config, *, mode='check', selected=None, odbc=None, emit=print, non_interactive=False, credential_store=None):
    if odbc is None:
        try: import pyodbc as odbc
        except ImportError as exc: raise RuntimeError('Install pyodbc pada venv lokal.') from exc
    if mode not in {'check','list','sync'}:
        raise ValueError('Mode tidak dikenal.')
    sources=[s for s in config['servers'] if selected is None or s['id']==selected]
    if not sources:
        raise ValueError('Server id tidak ditemukan di config.')
    if mode=='sync' and selected is not None:
        raise ValueError('Sync harus mencakup seluruh config agar snapshot tidak parsial.')
    if mode in {'sync','check'} and any(not s['databases'] for s in sources):
        raise ValueError('Isi allowlist databases dahulu. Gunakan --list-databases untuk melihat nama yang dapat diakses.')
    schema=_legacy() if mode!='list' else None
    timestamp=datetime.now(timezone.utc).isoformat(timespec='seconds')
    all_obj,all_cols,all_deps,registrations=[],[],[],[]
    seen=set()
    try:
        for source in sources:
            db=source.get('discovery_database','master')
            driver=_driver(source,odbc)
            password=resolve_password(source,non_interactive=non_interactive,store=credential_store)
            configured=source['databases']
            if configured=='all_accessible' or mode=='list':
                discovery=source.get('discovery_database','master')
                with closing(_open(source,driver,discovery,password,odbc)) as cn:
                    cursor=cn.cursor()
                    source_physical=_identity(cursor,source,discovery)
                    rows=cursor.execute("SELECT name FROM sys.databases WHERE database_id > 4 AND state_desc='ONLINE' AND HAS_DBACCESS(name)=1 AND source_database_id IS NULL ORDER BY name").fetchall()
                databases=[str(r[0]) for r in rows]
                emit(f'{source["id"]}: {len(databases)} database user online/terlihat/dapat diakses (database sistem/snapshot tidak disertakan).')
                if mode=='list':
                    for name in databases: emit('  '+name)
                    continue
                if not databases:
                    raise RuntimeError('Tidak ada database user dapat diakses; snapshot tidak diganti.')
            else:
                databases=configured
                source_physical=None
            for db in databases:
                emit(f'{source["id"]} · {db}: membaca metadata ...')
                with closing(_open(source,driver,db,password,odbc)) as cn:
                    cursor=cn.cursor()
                    physical=_identity(cursor,source,db)
                    if source_physical is not None and physical.casefold()!=source_physical.casefold():
                        raise RuntimeError('Physical instance berubah selama scan; snapshot tidak diganti.')
                    source_physical=physical
                    identity=(physical.casefold(),db.casefold())
                    if identity in seen:
                        raise ValueError('Physical server + database terdaftar dua kali. Periksa alias host/config.')
                    seen.add(identity)
                    objects=cursor.execute(schema.OBJECT_SQL).fetchall()
                    columns=cursor.execute(schema.COLUMN_SQL).fetchall()
                    deps=cursor.execute(schema.DEPENDENCY_SQL).fetchall()
                if not objects:
                    emit('  WARNING: tidak ada objek terlihat. Database bisa kosong atau metadata permission terbatas; tidak dianggap bukti tidak ada data.')
                keys={}
                for oid,ns,name,kind,desc,created,modified,definition in objects:
                    kind=kind.strip()
                    key=schema.key_for(physical,db,ns,name,kind); keys[oid]=key
                    status=('NOT_APPLICABLE_TABLE' if kind=='U' else 'AVAILABLE' if definition is not None else 'UNAVAILABLE_OR_NO_PERMISSION')
                    all_obj.append((key,source['id'],physical,db,ns,name,kind,desc,status,definition,
                                    str(created) if created else None,str(modified) if modified else None,timestamp))
                for oid,cid,name,typ,length,precision,scale,nullable,identity_flag in columns:
                    if oid in keys:
                        all_cols.append((keys[oid],cid,name,typ,length,precision,scale,int(nullable),int(identity_flag)))
                for oid,remote,refdb,ns,name,refid,ambiguous,caller in deps:
                    if oid in keys:
                        all_deps.append((keys[oid],remote,refdb or db,ns,name,refid,int(ambiguous),int(caller),'REFERENCE_ONLY'))
                registrations.append((source['id'],physical,db))
                missing=sum(1 for o in objects if o[3].strip()!='U' and o[-1] is None)
                emit(f'  @@SERVERNAME={physical} | objects={len(objects)} columns={len(columns)} dependencies={len(deps)} definitions_unavailable={missing}')
                if missing: emit('  NOTE: definition kosong bisa karena permission/encryption; lineage/matching berbasis metadata dapat terbatas.')
            password=None
    except (ValueError,RuntimeError):
        raise
    except Exception as exc:
        # ODBC diagnostics may contain connection details; do not echo raw errors.
        state=str(exc.args[0]) if exc.args and re.fullmatch('[A-Z0-9]{5}',str(exc.args[0])) else 'UNKNOWN'
        raise RuntimeError(f'Koneksi/metadata gagal [{source["id"]} / {db}], SQLSTATE={state}. Cek jaringan, TLS, login, dan izin metadata. Snapshot sebelumnya tidak diganti.') from None
    if mode=='sync':
        if not all_obj:
            raise RuntimeError('Tidak ada objek terlihat pada seluruh scope. Snapshot tidak diganti.')
        write_snapshot(config['catalog_path'],schema.DDL,timestamp,all_obj,all_cols,all_deps,registrations)
        emit(f'SNAPSHOT SAVED: {config["catalog_path"]}')
        emit('Selanjutnya bangun lineage dengan 09 --catalog pada file tersebut.')
    return {'objects':len(all_obj),'columns':len(all_cols),'dependencies':len(all_deps),'sources':registrations}


def write_snapshot(path, ddl, timestamp, objects, columns, dependencies, registrations):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with closing(sqlite3.connect(path,timeout=30)) as cn:
        cn.execute('PRAGMA foreign_keys=ON')
        cn.executescript(ddl)
        cn.execute('''CREATE TABLE IF NOT EXISTS catalog_source_scopes (
            logical_server TEXT NOT NULL, physical_server TEXT NOT NULL, database_name TEXT NOT NULL,
            source_run_id INTEGER NOT NULL, PRIMARY KEY(physical_server,database_name))''')
        with cn:
            cn.execute('BEGIN IMMEDIATE')
            cn.execute('DELETE FROM catalog_dependencies')
            cn.execute('DELETE FROM catalog_columns')
            cn.execute('DELETE FROM catalog_objects')
            cn.execute('DELETE FROM catalog_source_scopes')
            cn.executemany('INSERT INTO catalog_objects VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',objects)
            cn.executemany('INSERT INTO catalog_columns VALUES (?,?,?,?,?,?,?,?,?)',columns)
            cn.executemany('''INSERT INTO catalog_dependencies
                (referencing_key,referenced_server,referenced_database,referenced_schema,referenced_object,
                 referenced_object_id,is_ambiguous,is_caller_dependent,relation_status) VALUES (?,?,?,?,?,?,?,?,?)''',dependencies)
            run=cn.execute('''INSERT INTO catalog_runs (indexed_at,physical_server,database_count,object_count,column_count,dependency_count)
                VALUES (?,?,?,?,?,?)''',(timestamp,json.dumps(sorted({r[1] for r in registrations})),len(registrations),len(objects),len(columns),len(dependencies))).lastrowid
            cn.executemany('INSERT INTO catalog_source_scopes VALUES (?,?,?,?)',[(*r,run) for r in registrations])
