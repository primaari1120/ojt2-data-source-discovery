"""Dictionary-compatible vocabulary with mutation-aware cached signatures.

Avoid sorting hundreds of unchanged terms for every field/column comparison.
No changes to translations or matching rules.
"""
class Signature(tuple):
    def __new__(cls,values):
        value=super().__new__(cls,values)
        value._hash=tuple.__hash__(value)
        return value
    def __hash__(self):return self._hash
    def __reduce__(self):return (type(self),(tuple(self),))


class TermRules(dict):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self._signature=None;self._vocabulary=None
    def _invalidate(self):self._signature=None;self._vocabulary=None
    @property
    def signature(self):
        if self._signature is None:self._signature=Signature(sorted(self.items()))
        return self._signature
    @property
    def vocabulary(self):
        if self._vocabulary is None:self._vocabulary=Signature(sorted(set(self.keys())|set(self.values())))
        return self._vocabulary
    def __setitem__(self,key,value):super().__setitem__(key,value);self._invalidate()
    def __delitem__(self,key):super().__delitem__(key);self._invalidate()
    def update(self,*args,**kwargs):
        try: super().update(*args,**kwargs)
        finally: self._invalidate()
    def clear(self):super().clear();self._invalidate()
    def pop(self,*args):
        result=super().pop(*args);self._invalidate();return result
    def popitem(self):
        result=super().popitem();self._invalidate();return result
    def setdefault(self,key,default=None):
        if key not in self:self[key]=default
        return self[key]
    def __ior__(self,other):self.update(other);return self
    def copy(self):return TermRules(self)
