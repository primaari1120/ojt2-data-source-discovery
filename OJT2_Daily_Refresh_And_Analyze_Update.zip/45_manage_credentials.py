"""Enroll/read status/delete SQL credentials in the current user's Windows vault."""
import argparse
import getpass
from pathlib import Path
import os
from ojt2_credentials import WindowsCredentialStore
from ojt2_multi_server import load_config


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--config',type=Path,default=Path(os.environ.get('OJT2_SERVER_CONFIG',Path(__file__).with_name('sql_servers.local.json'))))
    group=cli.add_mutually_exclusive_group(required=True)
    group.add_argument('--save',action='store_true');group.add_argument('--status',action='store_true');group.add_argument('--delete',action='store_true')
    cli.add_argument('--server')
    args=cli.parse_args()
    sources=load_config(args.config)['servers']
    if args.server: sources=[s for s in sources if s['id']==args.server]
    if not sources: raise SystemExit('Server id tidak ditemukan.')
    if args.delete and not args.server: raise SystemExit('--delete memerlukan --server agar target eksplisit.')
    store=WindowsCredentialStore()
    for source in sources:
        if source['authentication']=='windows':
            print(source['id']+': Windows integrated authentication');continue
        if args.save:
            password=getpass.getpass(source['id']+' SQL password untuk disimpan: ')
            repeated=getpass.getpass('Ulangi password: ')
            if password!=repeated: raise SystemExit('Password tidak sama; credential tidak diubah.')
            store.save(source,password);password=repeated=None
            print(source['id']+': tersimpan di Windows Credential Manager.')
        elif args.delete:
            store.delete(source);print(source['id']+': credential dihapus.')
        else:
            print(source['id']+': '+('AVAILABLE' if store.get(source) else 'MISSING'))


if __name__=='__main__':
    try: main()
    except (ValueError,RuntimeError,FileNotFoundError) as exc: raise SystemExit(str(exc)) from None
