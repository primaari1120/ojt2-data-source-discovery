"""General ranking and batching/cache correctness; no SQL or real-model dependency."""
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from ojt2_candidate_ranking import rank_field_evidence
from ojt2_field_matching import split_tokens
import ojt2_semantic_engine as semantic


def fields(statuses):
    return [{'requested':str(i),'actual':None if s=='MISSING' else 'c'+str(i),
             'status':s,'suggestions':[]} for i,s in enumerate(statuses)]


class RankingPerformance(unittest.TestCase):
    def test_strong_fields_beat_hint_and_semantic_noise(self):
        weak=fields(['ABBREVIATION_ALIAS_REVIEW']*3+['MISSING']*2+
                    ['SEMANTIC_REVIEW']*2+['BUSINESS_ALIAS_REVIEW']*2+['IDENTIFIER_GRAIN_REVIEW'])
        strong=fields(['ABBREVIATION_ALIAS_REVIEW']*3+['NAME_MATCH']+
                      ['QUALIFIED_ATTRIBUTE_REVIEW','BUSINESS_ALIAS_REVIEW','QUALIFIED_ATTRIBUTE_REVIEW']+
                      ['BUSINESS_ALIAS_REVIEW']*2+['IDENTIFIER_GRAIN_REVIEW'])
        a=rank_field_evidence(weak,domain_match=1,explicit_match=1,hint_match=True)
        b=rank_field_evidence(strong,domain_match=1)
        self.assertGreater(b['score'],a['score'])
        self.assertEqual(a['missing_fields'],2)

    def test_complete_but_unrelated_semantics_do_not_beat_direct_fields(self):
        a=rank_field_evidence(fields(['SEMANTIC_REVIEW']*10),explicit_match=1,hint_match=True)
        b=rank_field_evidence(fields(['NAME_MATCH']*7+['MISSING']*3))
        self.assertGreater(b['score'],a['score'])

    def test_duplicate_signals_are_not_double_counted(self):
        data=fields(['BUSINESS_ALIAS_REVIEW'])
        before=rank_field_evidence(data)
        data[0]['suggestions']=[{'status':'SEMANTIC_REVIEW','rank_score':.95}]*20
        self.assertEqual(before,rank_field_evidence(data))

    def test_vocabulary_changes_invalidate_token_cache(self):
        self.assertNotEqual(split_tokens('StnName',{}),split_tokens('StnName',{'stn':'station'}))

    def test_cache_batch_larger_than_capacity_keeps_active_vectors(self):
        saved=semantic._EMBED_CACHE.copy()
        try:
            semantic._EMBED_CACHE.clear()
            calls=[]
            def encode(texts,**kwargs):
                calls.append(list(texts));return [[i] for i in range(len(texts))]
            with patch.object(semantic,'semantic_status',return_value={'ready':True,'path':'test'}), \
                 patch.object(semantic,'_load_model',return_value=SimpleNamespace(encode=encode)), \
                 patch.object(semantic,'_MAX_EMBED_CACHE',2):
                self.assertEqual(semantic._encode(['a','b','c']),[[0],[1],[2]])
                self.assertEqual(len(semantic._EMBED_CACHE),2)
                semantic._encode(['b','c'])
                self.assertEqual(len(calls),1)
        finally:
            semantic._EMBED_CACHE.clear();semantic._EMBED_CACHE.update(saved)

    def test_warmup_batches_fields_without_external_calls(self):
        with patch.object(semantic,'semantic_status',return_value={'ready':True}), \
             patch.object(semantic,'_encode',return_value=[]) as encode:
            semantic.warm_semantic_cache([('AnyDomain',[{'column_name':'ItemName'}])],['Nama Item','Item Name'])
            self.assertEqual(encode.call_count,1)
            texts=encode.call_args.args[0]
            self.assertEqual(len(texts),len(set(texts)))


if __name__=='__main__': unittest.main(verbosity=2)
