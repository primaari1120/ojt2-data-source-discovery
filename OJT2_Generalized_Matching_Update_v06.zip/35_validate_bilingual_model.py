"""Actual offline multilingual model evaluation, never mocked vectors.

Run after the model is provisioned: python 35_validate_bilingual_model.py
Optional: --report path.json (only writes to the explicitly supplied report path).
This small synthetic benchmark is not a production accuracy claim.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from unittest.mock import patch

from ojt2_adaptive_core import _field_evidence, discover
from ojt2_field_matching import BASE_TERMS
from ojt2_semantic_engine import semantic_status
from ojt2_bilingual_lexicon import lexicon_status

CASES = [
    ('ID PO','POID','int'),
    ('Nilai Kontrak','ContractValue','decimal'),
    ('Nama Tower','TowerName','nvarchar'),
    ('Biaya Sewa Bulanan','MonthlyRentalFee','decimal'),
    ('Kondisi Peralatan','EquipmentCondition','nvarchar'),
    ('Prakiraan Cuaca','WeatherForecast','nvarchar'),
    ('Uraian Pesanan Pembelian','PurchaseOrderDescription','nvarchar'),
    ('Tegangan Baterai','BatteryVoltage','decimal'),
    ('Premi Asuransi','InsurancePremium','decimal'),
    ('Kelembapan Udara','AirHumidity','decimal'),
    ('Konsumsi Bahan Bakar','FuelConsumption','decimal'),
    ('Tanggal Keberangkatan','DepartureDate','date'),
    ('Batas Kredit','CreditLimit','decimal'),
    ('Masa Garansi','WarrantyPeriod','nvarchar'),
    ('Pendapatan Tahunan','AnnualRevenue','decimal'),
]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    status=semantic_status()
    if not status['ready']:
        raise SystemExit('REAL MODEL TEST NOT RUN: '+status['reason']+
                         '. Provision a local model first; no download is performed by this validator.')
    cols=[{'column_name':actual,'sql_type':dtype} for _,actual,dtype in CASES]
    cols += [{'column_name':name,'sql_type':dtype} for name,dtype in [
        ('ContractDate','date'),('ContractStatus','nvarchar'),('TowerID','int'),
        ('TowerHeight','decimal'),('EmployeeName','nvarchar'),('MaintenanceEndDate','date')]]
    results=[]
    for requested,expected,_ in CASES:
        m=_field_evidence(cols,requested,None,'synthetic|demo|dbo|Operations|V',
                          object_name='vwOperations',shared_feedback={})
        suggestions=[s['actual'] for s in m.get('suggestions',[])]
        candidates=list(dict.fromkeys(([m['actual']] if m.get('actual') else [])+suggestions))
        row={'requested':requested,'expected':expected,'primary':m['actual'],'status':m['status'],
             'top_3':candidates[:3],'hit_at_3':expected in candidates[:3]}
        results.append(row)
        print(json.dumps(row,ensure_ascii=False),flush=True)
    # Isolate the real semantic channel. The bundled dictionary may ALSO know
    # these concepts; fused output must not be forced into one method's status.
    for wanted in ('Prakiraan Cuaca','Tegangan Baterai'):
        row=next(r for r in results if r['requested']==wanted)
        assert row['hit_at_3'],row
        with patch('ojt2_bilingual_lexicon.translation_evidence',return_value=None):
            isolated=_field_evidence(cols,wanted,None,'semantic-only',shared_feedback={})
        assert isolated['status']=='SEMANTIC_REVIEW' and isolated['actual']==row['expected'],isolated
    for wanted in ('ID PO','Nilai Kontrak','Nama Tower'):
        assert next(r for r in results if r['requested']==wanted)['hit_at_3']
    negatives=[]
    for requested,options in [
        ('Nama Kucing',cols),('Nomor Sepatu',cols),('Rasa Makanan',cols),
        ('Nama Tower',[{'column_name':'TowerHeight','sql_type':'decimal'}]),
        ('ID PO',[{'column_name':'PONumber','sql_type':'nvarchar'}]),
        ('Tanggal Kontrak',[{'column_name':'ContractValue','sql_type':'decimal'}]),
        ('StartMaintenanceDate',[{'column_name':'MaintenanceEndDate','sql_type':'date'}]),
    ]:
        m=_field_evidence(options,requested,None,'test',shared_feedback={})
        row={'requested':requested,'status':m['status'],'primary':m['actual']}
        negatives.append(row)
        assert m['status']=='MISSING' and m['actual'] is None,row
    # One-field semantic-only requirements must also survive source retrieval.
    key='s|DEMO_Test|dbo|Observations|V'
    obj={'object_key':key,'object_name':'Observations','database_name':'DEMO_Test',
         'schema_name':'dbo','object_type':'V','logical_server':'LOCAL_DEMO'}
    data={'objects':[obj]};index={'columns':{key:cols}}
    req={'purpose':'','source_hint':'','required_fields':['Prakiraan Cuaca']}
    with patch('ojt2_adaptive_core.get_alias_decisions',return_value={}), \
         patch('ojt2_adaptive_core.get_term_rules',return_value=BASE_TERMS), \
         patch('ojt2_adaptive_core.load_shared_feedback',return_value={}), \
         patch('ojt2_bilingual_lexicon.translation_evidence',return_value=None):
        ranked=discover(data,index,req)
    assert ranked and ranked[0]['field_map'][0]['actual']=='WeatherForecast'
    assert ranked[0]['coverage']==0,'Semantic suggestions are not verified coverage'
    report={'benchmark':'synthetic mixed-column bilingual retrieval; no training/feedback',
            'model':'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2',
            'lexicon':lexicon_status(),'cases':results,'negative_cases':negatives,
            'hit_at_3':sum(r['hit_at_3'] for r in results),'total':len(results),
            'negative_passed':len(negatives),'single_field_discovery':'PASS',
            'limitation':'Small synthetic set, not measured production accuracy or full vocabulary coverage.'}
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"REAL MODEL: hit@3 {report['hit_at_3']}/{report['total']}; negatives {len(negatives)}/{len(negatives)}; discovery PASS")


if __name__=='__main__':
    main()
