"""Stage 4.4.3: field-precision and one-primary UI regression (model-free).

Fixture derived from user-reported column names, plus adversarial new domains.
No production SQL, external AI, or destructive DB operations.
"""
from __future__ import annotations
from pathlib import Path
from unittest.mock import patch
from ojt2_adaptive_core import _field_evidence, OUTSTANDING_STATUSES
from ojt2_field_matching import field_suggestions


def columns(*names):
    return [{'column_name':x,'sql_type':'nvarchar'} for x in names]


def check_gdl():
    c=columns('GDLNo','SONumb','WarehouseOriginID','WHOrigin','WarehouseCity',
              'MaterialName','MaterialCategory','QtyGDL','GDLDate','GDLDetailID')
    checks={
        'Nomor GDL':('GDLNo','ABBREVIATION_ALIAS_REVIEW'),
        'Sonumber':('SONumb','ABBREVIATION_ALIAS_REVIEW'),
        'WHOriginID':('WarehouseOriginID','ABBREVIATION_ALIAS_REVIEW'),
        'WHOrigin':('WHOrigin','NAME_MATCH'),
        'City':('WarehouseCity','QUALIFIED_ATTRIBUTE_REVIEW'),
        'Nama Material':('MaterialName','BUSINESS_ALIAS_REVIEW'),
        'Kategori':('MaterialCategory','QUALIFIED_ATTRIBUTE_REVIEW'),
        'Quantity GDL':('QtyGDL','BUSINESS_ALIAS_REVIEW'),
        'Tanggal GDL':('GDLDate','BUSINESS_ALIAS_REVIEW'),
        'ID GDL':('GDLDetailID','IDENTIFIER_GRAIN_REVIEW'),
    }
    # Simulate the exact failure seen on the user's device: many unrelated
    # columns get relatively high cosine if semantic neighbors are unfiltered.
    def noisy_semantic(cols, req, **kw):
        return [{'actual':v['column_name'], 'status':'SEMANTIC_REVIEW',
                 'rank_score':.68, 'factor':0.0,'evidence':'mock semantic noise',
                 'semantic_risk_flags':[]} for v in cols]
    with patch('ojt2_semantic_engine.semantic_candidates', noisy_semantic):
        for q,(col,status) in checks.items():
            hit=_field_evidence(c,q,None,'srv|db|dbo|vwGDLTrace|V',
                                object_name='vwGDLTrace',shared_feedback={})
            assert (hit['actual'],hit['status'])==(col,status),(q,hit)
            assert not any(s['status']=='SEMANTIC_REVIEW'
                           for s in hit.get('suggestions',[])),(q,hit)
            if status in {'QUALIFIED_ATTRIBUTE_REVIEW','IDENTIFIER_GRAIN_REVIEW'}:
                assert hit['factor']==0.0 and status in OUTSTANDING_STATUSES,(q,hit)
    print('[PASS] All ten GDL fields: 3 formerly missing now review-candidates; unrelated semantic neighbors suppressed')


def check_generic():
    # No special GDL/table/domain rule is needed for either of these fields.
    for req, actual, expected in (
        ('City','BillingCity','QUALIFIED_ATTRIBUTE_REVIEW'),
        ('Category','ProductCategory','QUALIFIED_ATTRIBUTE_REVIEW'),
        ('ID Order','OrderLineID','IDENTIFIER_GRAIN_REVIEW'),
        ('Status','PaymentStatus','QUALIFIED_ATTRIBUTE_REVIEW'),
    ):
        m=_field_evidence(columns(actual),req,None,'s|d|dbo|Other|V',
                          object_name='vwUnrelated',shared_feedback={})
        assert (m['actual'],m['status']) == (actual,expected),(req,m)
        assert m['factor']==0.0
    for req, actual in [('Selection','SelectionID'), ('City','CityID')]:
        m=_field_evidence(columns(actual),req,None,'other',shared_feedback={})
        assert m['status']=='REFERENCE_KEY_REVIEW' and m['factor']==0.0,(req,m)
    m=_field_evidence(columns('WarehouseCity','CustomerCity'),'City',None,'other',
                      object_name='vwLocation',shared_feedback={})
    assert m['actual'] is None and m['status']=='MULTIPLE_CONTEXT_OPTIONS_REVIEW',m
    assert len(m['suggestions'])>=2  # no arbitrary approval among ambiguous qualifiers
    print('[PASS] Other domains, identifier/value safeguard, and genuinely ambiguous qualifiers')


def check_semantic_fallback():
    def semantic_results(cols,req,**kw):
        if req=='RequestorBy':
            return [
                {'actual':'EmployeeName','status':'SEMANTIC_REVIEW','rank_score':.74,
                 'semantic_risk_flags':['PERSON_NAME_NOT_ACTOR'],'evidence':'cosine only','factor':0.0},
                {'actual':'CreatedBy','status':'SEMANTIC_REVIEW','rank_score':.63,
                 'semantic_risk_flags':['ACTOR_EQUIVALENCE_NOT_PROVEN'],'evidence':'actor related','factor':0.0},
                {'actual':'ReviewedBy','status':'SEMANTIC_REVIEW','rank_score':.62,
                 'semantic_risk_flags':['ACTOR_ROLE_CONFLICT'],'evidence':'different actor','factor':0.0},
            ]
        if req=='StartMaintenanceDate':
            return [
                {'actual':'MaintenanceEndDate','status':'SEMANTIC_REVIEW','rank_score':.74,
                 'semantic_risk_flags':['START_END_CONTRADICTION'],'evidence':'opposite','factor':0.0},
                {'actual':'StartPeriod','status':'SEMANTIC_REVIEW','rank_score':.71,
                 'semantic_risk_flags':['DATE_VS_PERIOD_REVIEW'],'evidence':'same start','factor':0.0},
            ]
        return []
    with patch('ojt2_semantic_engine.semantic_candidates', semantic_results):
        first=_field_evidence(columns('EmployeeName','CreatedBy','ReviewedBy'),
                              'RequestorBy',None,'other',shared_feedback={})
        assert first['actual']=='CreatedBy' and first['status']=='SEMANTIC_REVIEW',first
        assert len(first['suggestions'])==1 and first['factor']==0.0,first
        second=_field_evidence(columns('MaintenanceEndDate','StartPeriod'),
                              'StartMaintenanceDate',None,'other',shared_feedback={})
        assert second['actual']=='StartPeriod' and second['status']=='SEMANTIC_REVIEW',second
        assert len(second['suggestions'])==1 and second['factor']==0.0,second
    print('[PASS] One credible semantic fallback, obvious role/time contradictions suppressed')


def check_integration():
    root=Path(__file__).parent
    ui=(root/'15_adaptive_workflow_streamlit.py').read_text(encoding='utf-8')
    meta=(root/'11_metadata_explorer_streamlit.py').read_text(encoding='utf-8')
    gap=(root/'ojt2_gap_engine.py').read_text(encoding='utf-8')
    # Version mismatch should be explicit. Do NOT make a stale UI pass by
    # loosening integration requirements or bypassing this check.
    required_ui = {
        "one-primary field suggestion panel": "Best suggestion per field — PIC review",
        "qualified attribute in PIC review statuses": "'QUALIFIED_ATTRIBUTE_REVIEW'",
        "identifier grain in PIC review statuses": "'IDENTIFIER_GRAIN_REVIEW'",
        "one-primary field suggestion table": "st.dataframe(alt_rows",
    }
    missing_ui = [description for description, marker in required_ui.items() if marker not in ui]
    if 'Top-N Field Suggestions (60 hypotheses)' in ui:
        missing_ui.append('old Top-N suggestions panel was not removed')
    if missing_ui:
        raise AssertionError(
            'Stage 4.4.3 UI is out of sync: ' + ', '.join(missing_ui) + '\n'
            'Replace ONLY 15_adaptive_workflow_streamlit.py with the file from '
            'Stage 4.4.3 UI Sync Fix, then rerun validator 33. '
            'Do NOT reset SQLite/PIC history or reinstall the semantic model.'
        )
    required_meta = {
        "shared resolution including ambiguity": 'resolution = _field_evidence(cols',
        "ambiguity alternatives preserved": 'elif ambiguous:',
    }
    missing_meta = [description for description, marker in required_meta.items() if marker not in meta]
    if missing_meta:
        raise AssertionError('Metadata Explorer file not yet updated to Stage 4.4.3: '
                             + ', '.join(missing_meta))
    required_gap = {
        "qualified/identifier-grain status recognition": 'IDENTIFIER_GRAIN_REVIEW',
        "qualified attribute status recognition": 'QUALIFIED_ATTRIBUTE_REVIEW',
        "grain-only JOIN restriction": "s['status'] not in {'REFERENCE_KEY_REVIEW','IDENTIFIER_GRAIN_REVIEW'",
    }
    missing_gap = [description for description, marker in required_gap.items() if marker not in gap]
    if missing_gap:
        raise AssertionError('Source Gap module not yet updated to Stage 4.4.3: '
                             + ', '.join(missing_gap))
    print('[PASS] UI shows one best per field, Metadata Explorer one top per object, JOIN rejects grain-only similarity')


if __name__=='__main__':
    check_gdl();check_generic();check_semantic_fallback();check_integration()
    print('=== STAGE 4.4.3 PRECISION-FIRST FIELD MATCHING: PASS ===')
