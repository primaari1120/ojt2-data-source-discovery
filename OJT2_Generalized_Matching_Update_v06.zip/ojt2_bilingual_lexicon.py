"""Bundled, offline Indonesian-English lexical evidence (no network or learning).

WordNet alternatives are hypotheses, not globally interchangeable business terms.
All requested/column tokens must be accounted for; substring overlap alone is
insufficient. Shared attribute/ID/unit gates remain the caller's responsibility.
"""
from __future__ import annotations
from collections import Counter
from functools import lru_cache
import gzip
import json
from pathlib import Path
import re

LEXICON_PATH = Path(__file__).with_name('ojt2_bilingual_lexicon.json.gz')


@lru_cache(maxsize=1)
def _load():
    try:
        with gzip.open(LEXICON_PATH,'rt',encoding='utf-8') as stream:
            data=json.load(stream)
        if data['metadata']['format_version']!=1 or not isinstance(data['id_to_en'],dict):
            raise ValueError('Unsupported bilingual lexicon format')
        return data, ''
    except (OSError,ValueError,KeyError,TypeError) as exc:
        return None,type(exc).__name__


def lexicon_status() -> dict:
    data,error=_load()
    return {'ready':data is not None,'reason':'BUNDLED_LEXICON_AVAILABLE' if data else error,
            'terms':data['metadata']['terms'] if data else 0,
            'translation_pairs':data['metadata']['translation_pairs'] if data else 0}


def translation_evidence(left: tuple[str,...], right: tuple[str,...], canonical) -> str | None:
    """Cover both token sequences with literal concepts or attested translations.

    Supports reordered field words and multiword lemmas (up to four words).
    Tries both directions for English requirements against Indonesian SQL names.
    """
    data,_=_load()
    if data is None or not left or not right or max(len(left),len(right))>12:
        return None
    glossary=data['id_to_en']
    # Dictionary lexemes are words, not corporate abbreviations. Expanding a
    # short lexeme through the SQL abbreviation map can change its meaning
    # (for example an ordinary word also used as a category abbreviation).
    normalize=lambda word: word if len(word)<=3 else canonical(word)

    def align(source,target):
        goal=tuple(sorted(normalize(w) for w in target))

        @lru_cache(maxsize=None)
        def options(span):
            phrase=' '.join(span)
            return tuple((english,tuple(normalize(w) for w in re.findall(r'[a-z0-9]+',english)))
                         for english in glossary.get(phrase,()))

        @lru_cache(maxsize=None)
        def cover(position,remaining,translated):
            if position==len(source):
                return () if not remaining and translated else None
            available=Counter(remaining)
            choices=[(1,'',(normalize(source[position]),))]
            for size in range(1,min(4,len(source)-position)+1):
                span=source[position:position+size]
                choices.extend((size,' '.join(span)+' → '+english,words)
                               for english,words in options(span))
            for size,evidence,words in choices:
                needed=Counter(words)
                if not words or any(available[w]<n for w,n in needed.items()):
                    continue
                rest=tuple(sorted((available-needed).elements()))
                tail=cover(position+size,rest,translated or bool(evidence))
                if tail is not None:
                    return ((evidence,) if evidence else ())+tail
            return None

        return cover(0,goal,False)

    proof=align(left,right)
    if proof is None:
        proof=align(right,left)
    if proof is None:
        return None
    return ('Bundled Wordnet Bahasa/Princeton WordNet translation evidence: '+
            '; '.join(dict.fromkeys(proof))+
            '. All label tokens accounted for; polysemy and business meaning require PIC review.')
