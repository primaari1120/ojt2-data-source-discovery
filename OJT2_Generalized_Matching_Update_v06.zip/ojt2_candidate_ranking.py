"""Source ranking by distinct field evidence; independent of source/domain names.

These weights order review candidates; they do not grant verified coverage.
Semantic corroboration of a lexical match is not counted as a second field.
"""
STRENGTH = {
    'NAME_MATCH':1.0,'REGISTERED_ALIAS_REVIEW':.95,
    'BUSINESS_ALIAS_REVIEW':.85,'ABBREVIATION_ALIAS_REVIEW':.85,
    'BILINGUAL_CONCEPT_REVIEW':.75,'BILINGUAL_LEXICON_REVIEW':.75,
    'CURATED_ALIAS_REVIEW':.70,'FUZZY_ALIAS_REVIEW':.45,'UNIT_ALIAS_REVIEW':.45,
    'QUALIFIED_ATTRIBUTE_REVIEW':.50,'ATTRIBUTE_EXTENSION_REVIEW':.35,
    'OBJECT_CONTEXT_REVIEW':.30,'ACTOR_ATTRIBUTE_REVIEW':.25,
    'ANNOTATION_CONTEXT_REVIEW':.30,'FORMULA_DEFINITION_REVIEW':.20,
    'EVENT_SEMANTIC_REVIEW':.15,'SEMANTIC_REVIEW':.20,
    'SAME_DOMAIN_FEEDBACK_REVIEW':.25,'CROSS_DOMAIN_FEEDBACK_REVIEW':.20,
    'IDENTIFIER_GRAIN_REVIEW':.10,'REFERENCE_KEY_REVIEW':.05,
    'POTENTIAL_MATCH_REVIEW':.10,
}


def rank_field_evidence(field_map, *, domain_match=0, explicit_match=0, registry_match=0, hint_match=False):
    total=len(field_map)
    strengths=[]
    for field in field_map:
        if field.get('actual'):
            strength=STRENGTH.get(field['status'],0)
        else:
            # Alternatives support source retrieval, but no resolved field yet.
            strength=.20*max((STRENGTH.get(s['status'],0) for s in field.get('suggestions',[])),default=0)
        strengths.append(strength)
    quality=sum(strengths)/total if total else 0
    context=8*bool(domain_match)+7*bool(explicit_match or registry_match)+5*bool(hint_match)
    return {'score':round(80*quality+context,1),
            'field_evidence_component':round(80*quality,2),'context_component':context,
            'strong_field_suggestions':sum(s>=.70 for s in strengths),
            'missing_fields':sum(f['status'] in {'MISSING','UNRESOLVED_DERIVED'} for f in field_map),
            'note':'Ranking evidence only; review/semantic/grain hypotheses are not verified coverage.'}
