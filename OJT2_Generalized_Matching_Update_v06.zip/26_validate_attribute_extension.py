"""Read-only/fixture validation for Stage 4.2.1 qualifier proposals.

Run with the project's .venv. No SQL Server connection or data writes
except a private temporary SQLite file for PIC decision testing.
"""
from pathlib import Path
import tempfile
from ojt2_field_matching import (field_suggestions, propose_field_match,
       record_alias_decision, get_alias_decisions)
from ojt2_adaptive_core import _field_evidence, OUTSTANDING_STATUSES
from ojt2_discovery_core import norm

def cols(*names): return [{'column_name': x, 'sql_type':'nvarchar'} for x in names]
def main():
    tests = [
       ('Resign', ['ResignStatus'], 'ResignStatus', 'ATTRIBUTE_EXTENSION_REVIEW'),
       ('Kontrak', ['ContractDate'], 'ContractDate', 'ATTRIBUTE_EXTENSION_REVIEW'), # known translation; date qualifier remains unverified
       ('Project', ['ProjectType'], 'ProjectType', 'ATTRIBUTE_EXTENSION_REVIEW'),
       ('Site', ['SiteName'], 'SiteName', 'ATTRIBUTE_EXTENSION_REVIEW'),
       ('Resign', ['ResignStatusID'], 'ResignStatusID', 'REFERENCE_KEY_REVIEW'),
    ]
    for req,names,expected,status in tests:
        suggestions=field_suggestions(cols(*names),req)
        got=next((x for x in suggestions if x['actual']==expected),None)
        if expected:
            assert got and got['status']==status, (req,suggestions)
        else:
            assert not suggestions, (req,suggestions)
    print('[PASS] Generic business qualifier vs identifier detected; no forced translation')
    got=_field_evidence(cols('ResignStatus'),'Resign',None,'srv|db|dbo|emp|U')
    assert got['status']=='ATTRIBUTE_EXTENSION_REVIEW' and got['factor']==0
    assert got['status'] in OUTSTANDING_STATUSES
    assert got['actual']=='ResignStatus'
    assert propose_field_match(cols('ResignStatus'),'Resign') is None
    print('[PASS] Resign -> ResignStatus visible as proposal but NOT counted as covered')
    ambiguous=_field_evidence(cols('ResignStatus','ResignDate'),'Resign',None,'srv|db|dbo|emp|U')
    assert ambiguous['status']=='MULTIPLE_ATTRIBUTE_OPTIONS_REVIEW'
    assert ambiguous['actual'] is None and len(ambiguous['suggestions'])==2
    print('[PASS] Ambiguous ResignStatus vs ResignDate requires PIC selection')
    exact=_field_evidence(cols('Resign'),'Resign',None,'x')
    assert exact['status']=='NAME_MATCH'
    reqmore=field_suggestions(cols('Resign'),'ResignStatus')
    assert not any(x['status']=='ATTRIBUTE_EXTENSION_REVIEW' for x in reqmore)
    print('[PASS] Exact and reverse-specificity safeguards retained')
    with tempfile.TemporaryDirectory(prefix='ojt2-attribute-check-') as folder:
        path=Path(folder)/'decisions.sqlite'
        object_key='srv|db|dbo|emp|U'
        record_alias_decision('HR',object_key,'Resign','ResignStatus','APPROVED','DemoPIC',
                              'Status of employee resignation confirmed',path=path)
        decisions=get_alias_decisions('HR',path=path)
        accepted=_field_evidence(cols('ResignStatus'),'Resign','HR',object_key,decisions=decisions)
        assert accepted['status']=='REGISTERED_ALIAS_REVIEW', accepted
        record_alias_decision('HR',object_key,'Resign','ResignStatus','REJECTED','DemoPIC',
                              'Changed after review',path=path)
        decisions=get_alias_decisions('HR',path=path)
        rejected=_field_evidence(cols('ResignStatus'),'Resign','HR',object_key,decisions=decisions)
        assert rejected['actual'] is None and rejected['status']=='MISSING', rejected
    print('[PASS] PIC feedback persisted and decisions scoped to source')
    # Source Gap also consumes the same matcher; display qualifier as a source
    # candidate without claiming that this fulfills the business field.
    from collections import defaultdict
    from ojt2_adaptive_core import find_supporting, evidence_summary
    primary={'object_key':'S1|HR_DEMO|dbo|rptStaff|U','physical_server':'S1',
             'logical_server':'HR','database_name':'HR_DEMO','schema_name':'dbo',
             'object_name':'rptStaff','object_type':'U'}
    supporting={'object_key':'S1|HR_DEMO|dbo|rptResignStatus|U','physical_server':'S1',
                'logical_server':'HR','database_name':'HR_DEMO','schema_name':'dbo',
                'object_name':'rptResignStatus','object_type':'U'}
    index={'objects':{o['object_key']:o for o in (primary,supporting)},
           'columns':defaultdict(list),'forward':defaultdict(list),'reverse':defaultdict(list)}
    for obj,names in [(primary,['EmployeeID','EmployeeName']),
                      (supporting,['EmployeeID','ResignStatus'])]:
        for name in names:
            index['columns'][obj['object_key']].append({
                'object_key':obj['object_key'],'column_name':name,'sql_type':'nvarchar'})
    req={'purpose':'pegawai resign','source_hint':'','filtering':'Tidak ada',
         'required_fields':['Resign']}
    main={'object':primary,
          'field_map':[_field_evidence(index['columns'][primary['object_key']],
                                     'Resign',None,primary['object_key'])],
          'matched':0,'alias_proposed':0,'mapped_proposed':0,'total':1}
    supports=find_supporting({'objects':[primary,supporting],'columns':[],'edges':[]},
                             index,main,req)
    assert len(supports)==1 and supports[0]['actual_field']=='ResignStatus',supports
    assert supports[0]['match_status']=='ATTRIBUTE_EXTENSION_REVIEW'
    assert supports[0]['join_candidates'] and not supports[0]['potentially_joinable']
    assert evidence_summary(main,supports)['potential']==0
    print('[PASS] Gap shows supporting candidate and JOIN evidence; coverage stays unverified')
    print('=== ATTRIBUTE EXTENSION VALIDATION SUCCESS ===')
if __name__=='__main__': main()
