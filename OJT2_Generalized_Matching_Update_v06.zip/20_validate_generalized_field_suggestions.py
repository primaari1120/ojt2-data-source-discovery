"""Stage 4.1.5 evidence-aware generalized alias candidate validation.

No network/SQL Server connections. Optional --live only loads existing SQLite
metadata catalog, NEVER writes it; feedback tests use isolated temporary SQLite.
"""
from __future__ import annotations
import argparse
from pathlib import Path
from tempfile import TemporaryDirectory
from importlib.util import spec_from_file_location, module_from_spec
from ojt2_adaptive_core import _field_evidence, discover
from ojt2_field_matching import field_suggestions, record_alias_decision, get_alias_decisions

HERE=Path(__file__).resolve().parent

def test():
    cases=[
        ('Nama Site',['SiteName'],'BUSINESS_ALIAS_REVIEW','SiteName'),
        ('Tipe Segmen',['SegmentType'],'BUSINESS_ALIAS_REVIEW','SegmentType'),
        ('SONumber',['SONumb'],'ABBREVIATION_ALIAS_REVIEW','SONumb'),
        ('Site Order Number',['SONumb'],'ABBREVIATION_ALIAS_REVIEW','SONumb'),
        ('Tanggal Approval',['ApprovalDate'],'BUSINESS_ALIAS_REVIEW','ApprovalDate'),
        ('Jarak',['DistanceKM'],'UNIT_ALIAS_REVIEW','DistanceKM'),
        ('Status Approval',['ApprovalStatus'],'BUSINESS_ALIAS_REVIEW','ApprovalStatus'),
        ('ID Site',['SiteID'],'BUSINESS_ALIAS_REVIEW','SiteID'),
        ('Site',['SiteID'],'REFERENCE_KEY_REVIEW','SiteID'),
        ('Seleksi',['SelectionID'],None,None),
    ]
    n=0
    for req,fields,status,name in cases:
        cols=[{'column_name':c} for c in fields]
        candidates=field_suggestions(cols,req,domain='STIP',object_key='demo')
        if status is not None:
            assert candidates and candidates[0]['status']==status and candidates[0]['actual']==name,(req,candidates)
        else:
            assert not [x for x in candidates if x['status'] not in ('REFERENCE_KEY_REVIEW',)],(req,candidates)
        n+=1
    print(f'[PASS] {n} generalized proposal cases: synonyms / word order / initials / units / ID mismatch')
    cols=[{'column_name': 'DistanceKM'}, {'column_name':'DistanceM'}]
    props=field_suggestions(cols,'Jarak')
    assert len(props)==2 and all(x['status']=='UNIT_ALIAS_REVIEW' for x in props),props
    ambiguous=_field_evidence(cols,'Jarak','STIP')
    assert ambiguous['status']=='AMBIGUOUS_MATCH_REVIEW' and ambiguous['actual'] is None and ambiguous['factor']==0, 'Do not silently choose unit'
    props=field_suggestions([{'column_name':'SONumb'},{'column_name':'SONum'}],'SO Number')
    assert len(props)==2, props
    assert _field_evidence([{'column_name':'SONumb'},{'column_name':'SONum'}],'SO Number','STIP')['status']=='AMBIGUOUS_MATCH_REVIEW'
    print('[PASS] Ambiguous alternatives shown but never treated as verified/mapped')
    p=_field_evidence([{'column_name':'SiteID'}],'Site','STIP')
    assert p['status']=='REFERENCE_KEY_REVIEW' and p['factor']==0.0, p
    p=_field_evidence([{'column_name':'SegmentTypeID'}],'Tipe Segmen','STIP')
    assert p['status']=='MISSING' and p['suggestions'][0]['status']=='REFERENCE_KEY_REVIEW',p
    assert field_suggestions([{'column_name':'DistanceKM'}],'Jarak Meter')==[], 'Explicit unit conflict'
    assert field_suggestions([{'column_name':'ApprovalDate'}],'ApprovalAmount')==[], 'Wrong business meaning'
    print('[PASS] ID/label and unit/meaning safety boundaries')

    with TemporaryDirectory(prefix='ojt2-stage415-') as tmp:
        db=Path(tmp)/'app.sqlite'
        obj='SERVER.DB.dbo.ViewA'
        record_alias_decision('STIP',obj,'Nama Site','SiteName','APPROVED','PIC_DEMO','Validated based on business definition',db)
        approved=get_alias_decisions('STIP',db)
        props=field_suggestions([{'column_name':'SiteName'}],'Nama Site',object_key=obj,decisions=approved)
        assert props[0]['status']=='REGISTERED_ALIAS_REVIEW',props
        other=field_suggestions([{'column_name':'SiteName'}],'Nama Site',object_key='SERVER.DB.dbo.Other',decisions=approved)
        assert other[0]['status']=='BUSINESS_ALIAS_REVIEW',other
        record_alias_decision('STIP',obj,'Nama Site','SiteName','REJECTED','PIC_DEMO','Reversed after review',db)
        rejected=get_alias_decisions('STIP',db)
        assert not field_suggestions([{'column_name':'SiteName'}],'Nama Site',object_key=obj,decisions=rejected)
        try:
            record_alias_decision('STIP',obj,'Site','SiteID','APPROVED','PIC_DEMO','Unsafe ID-value',db)
        except ValueError: pass
        else: raise AssertionError('Must not approve reference key as direct field alias')
    print('[PASS] PIC feedback persists, is object-scoped, reversible and guards key/value')


def validate_catalog(live):
    if not live:return
    spec=spec_from_file_location('stage41data', HERE/'16_validate_adaptive_docs.py')
    mod=module_from_spec(spec); assert spec and spec.loader;spec.loader.exec_module(mod)
    data,index=mod.load_live()
    obj=next(o for o in data['objects'] if o['object_name']=='vwSTIPApprovalDetail' and o['database_name']=='DEMO_IT_Operations')
    req={'purpose':'Permintaan STIP untuk evaluasi segmen dan lokasi site',
         'source_hint':'vwSTIPApprovalDetail','filtering':'Tidak ada',
         'required_fields':['Tipe Segmen','Jarak','Nama Site','Site','SONumber']}
    candidates=discover(data,index,req,limit=30)
    selected=next(r for r in candidates if r['object_key']==obj['object_key'])
    fields={m['requested']:m for m in selected['field_map']}
    assert fields['Tipe Segmen']['actual']=='SegmentType'
    assert fields['Jarak']['actual']=='DistanceKM'
    assert fields['Nama Site']['actual']=='SiteName'
    assert fields['SONumber']['actual']=='SONumb'
    assert fields['Site']['status'] in ('REFERENCE_KEY_REVIEW','MISSING') and fields['Site']['factor']==0
    print('[PASS] Real local SQLite catalog STIP: candidate generator works without re-sync')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--live',action='store_true');args=p.parse_args()
    test();validate_catalog(args.live)
    print('=== STAGE 4.1.5 GENERALIZED FIELD SUGGESTIONS VALIDATION SUCCESS ===')
