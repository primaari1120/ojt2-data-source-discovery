"""Stage 4.1.6 regression: multilingual spelling, order, names, ID/key safety.

Usage: python 21_validate_multilingual_similarity.py [--live]
No SQL Server writes or runtime Stored Procedure execution.
"""
from __future__ import annotations
import argparse
from pathlib import Path
from importlib.util import spec_from_file_location, module_from_spec
from ojt2_field_matching import field_suggestions, split_tokens
from ojt2_adaptive_core import _field_evidence, discover

HERE = Path(__file__).resolve().parent


def result(field, options):
    return _field_evidence([{'column_name': x} for x in options], field, 'PROJECT', 'DEMO.PROJECT')


def test_spelling():
    positive = [
        ('Provinsi', 'Province'),
        ('Propinsi', 'Province'),
        ('Provnsi', 'Province'),
        ('Status Projek', 'ProjectStatus'),
        ('Status Proyek', 'ProjectStatus'),
        ('Status Project', 'ProjectStatus'),
        ('Project Status', 'ProjectStatus'),
        ('Project_Status', 'ProjectStatus'),
        ('ID Project', 'ProjectID'),
        ('Nama Partner', 'PartnerName'),
        ('Nama Site', 'SiteName'),
        ('Tipe Segmen', 'SegmentType'),
        ('SO Number', 'SONumb'),
        ('Tanggal Approval', 'ApprovalDate'),
        ('Nama Pelanggan', 'CustomerName'),
        ('Nomor Request', 'RequestNumber'),
    ]
    for request, column in positive:
        mapping = result(request, [column])
        assert mapping['actual'] == column, (request, mapping)
        assert mapping['status'] in {'BUSINESS_ALIAS_REVIEW', 'ABBREVIATION_ALIAS_REVIEW',
                                     'FUZZY_ALIAS_REVIEW', 'CURATED_ALIAS_REVIEW', 'NAME_MATCH'}, (request, mapping)
        assert 0 < mapping['factor'] <= 1, (request, mapping)
    print(f'[PASS] {len(positive)} bilingual, typo, abbreviation, reorder and multi-token alias proposals')

    assert result('Provinsi',['Region'])['status'] == 'MISSING'
    assert result('Provinsi',['ProvinceID'])['status'] == 'MISSING'
    assert result('Status Projek',['ProjectStatusID'])['status'] == 'MISSING'
    assert result('Site',['SiteID'])['status'] == 'REFERENCE_KEY_REVIEW'
    assert result('Jarak Meter',['DistanceKM'])['status'] == 'MISSING'
    ambiguous=result('Status Projek',['ProjectStatus', 'StatusProject'])
    assert ambiguous['status']=='AMBIGUOUS_MATCH_REVIEW' and ambiguous['actual'] is None and ambiguous['factor']==0
    suggestions = field_suggestions([{'column_name': 'ProjectStatus'},
                                     {'column_name':'StatusProject'}], 'Status Projek')
    assert len(suggestions) == 2, suggestions
    assert result('Provinsi',['Province','ProvinceID'])['actual']=='Province'
    assert result('Status Projek',['ProjectStatus','ProjectStatusID'])['actual']=='ProjectStatus'
    print('[PASS] 8 safety/ambiguity checks: province!=region, ID!=label, explicit units, competing alternatives')


def test_catalog(live):
    spec = spec_from_file_location('stage416_fixture', HERE / '16_validate_adaptive_docs.py')
    mod = module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    data,index = mod.load_live() if live else mod.synthetic_fixture()
    req={'purpose':'Monitoring informasi proyek area dan status pembangunan',
         'source_hint':'Project Information', 'filtering':'',
         'required_fields':['ID Project','Site ID','Nama Site','Provinsi',
                            'Area','Status Projek','Nama Partner','Target RFI']}
    results = discover(data,index,req,limit=30)
    row = next((r for r in results if r['object']['object_name']=='vwProjectInformationCrossDB'),None)
    assert row, 'Expected cross-database project view missing'
    matches = {m['requested']:m for m in row['field_map']}
    assert matches['Provinsi']['actual']=='Province',matches['Provinsi']
    assert matches['Status Projek']['actual']=='ProjectStatus',matches['Status Projek']
    assert matches['Nama Site']['actual']=='SiteName',matches['Nama Site']
    assert matches['Nama Partner']['actual']=='PartnerName',matches['Nama Partner']
    assert row['total']==8,row
    assert row['matched']+row['alias_proposed']==8,(row['matched'],row['alias_proposed'],matches)
    print(f"[PASS] {'LIVE metadata' if live else 'SYNTHETIC fixture'}: project view mapped 8/8 exact + proposed aliases (NOT PIC-verified)")


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--live',action='store_true')
    args=parser.parse_args()
    test_spelling()
    test_catalog(args.live)
    print('=== STAGE 4.1.6 MULTILINGUAL SIMILARITY VALIDATION SUCCESS ===')
