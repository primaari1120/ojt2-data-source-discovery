"""Stage 4.1.3 regression: abbreviations, ambiguity and persistent PIC feedback.

Usage:
  python 18_validate_adaptive_abbreviation_learning.py
  python 18_validate_adaptive_abbreviation_learning.py --live

The --live mode only reads metadata catalog SQLite; test feedback is stored in
an isolated temporary database, not the user's actual persistent app data.
"""
from __future__ import annotations
import argparse
import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory
from ojt2_adaptive_core import _field_evidence, discover
from ojt2_field_matching import (
    get_alias_decisions, get_term_rules, record_alias_decision, record_term_rule,
    list_alias_decisions, list_term_rules,
)

HERE=Path(__file__).resolve().parent


def fixture_and_live(live: bool):
    spec=importlib.util.spec_from_file_location('stage41_tests', HERE/'16_validate_adaptive_docs.py')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.load_live() if live else mod.synthetic_fixture()


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--live',action='store_true')
    args=p.parse_args()
    data,index=fixture_and_live(args.live)
    req={
        'purpose':'Untuk bahan pembuatan dashboard XLsmart',
        'source_hint':'Dashboard XLSmart',
        'filtering':'Tidak ada',
        'required_fields':['Selection','SiteID','SONumber','Nama Site','Regional','Customer','Status DRM'],
    }
    candidates=discover(data,index,req,limit=30)
    result=next((r for r in candidates if r['object']['object_name']=='vwMKTDashboardXLSMART'),None)
    assert result, 'XLSMART View not found in metadata catalog'
    actual={m['requested']:m for m in result['field_map']}
    assert actual['SONumber']['actual']=='SONumb',actual['SONumber']
    assert actual['SONumber']['status']=='ABBREVIATION_ALIAS_REVIEW',actual['SONumber']
    assert actual['Nama Site']['status']=='BUSINESS_ALIAS_REVIEW'
    assert actual['Selection']['status']=='REFERENCE_KEY_REVIEW'
    assert actual['Selection']['factor']==0.0
    assert result['matched']==4,result['matched']
    assert result['alias_proposed']==2,result['alias_proposed']
    print('[PASS] XLSMART: 4 exact, 2 alias proposals, 1 reference key (not covered)')

    cols=[{'column_name':n} for n in ['SONumb','PO_Number','SiteName','SelectionID','StatusDRM','QtyGDL']]
    examples={
        'SO Number':('SONumb','ABBREVIATION_ALIAS_REVIEW'),
        'SO Num':('SONumb','ABBREVIATION_ALIAS_REVIEW'),
        'SONumber':('SONumb','ABBREVIATION_ALIAS_REVIEW'),
        'PO No':('PO_Number','ABBREVIATION_ALIAS_REVIEW'),
        'Nama Site':('SiteName','BUSINESS_ALIAS_REVIEW'),
        'QuantityGDL':('QtyGDL','BUSINESS_ALIAS_REVIEW'),
        'Status DRM':('StatusDRM','NAME_MATCH'),
        'Selection':('SelectionID','REFERENCE_KEY_REVIEW'),
    }
    for wanted,(name,status) in examples.items():
        match=_field_evidence(cols,wanted,'XLSMART')
        assert match['actual']==name and match['status']==status,(wanted,match)
    print('[PASS] Abbreviation, bilingual label, exact naming and identifier guard:',len(examples))
    # Ambiguous pairs must not be promoted as labels; identifier-vs-value remains unresolved.
    assert _field_evidence([{'column_name':'CustomerID'}],'Customer','XLSMART')['status']=='REFERENCE_KEY_REVIEW'
    assert _field_evidence([{'column_name':'SelectionID'}],'Selection Status','XLSMART')['status']=='MISSING'
    ambiguous=_field_evidence([{'column_name':'SONumb'},{'column_name':'SONum'}],'SO Number','XLSMART')
    assert ambiguous['status']=='AMBIGUOUS_MATCH_REVIEW' and ambiguous['actual'] is None and ambiguous['factor']==0
    print('[PASS] Negative: ID != label; ambiguous duplicate canonical aliases not auto-mapped')

    with TemporaryDirectory(prefix='ojt2-vocab-test-') as tmp:
        db=Path(tmp)/'discovery_app.sqlite'
        obj=result['object_key']
        weak=_field_evidence([{'column_name':'StnName'}],'StationName','XLSMART')
        assert weak['status']=='POTENTIAL_MATCH_REVIEW' and weak['factor']==0
        record_term_rule('XLSMART','stn','station','PIC_DEMO','Station is abbreviated Stn in approved glossary',db)
        assert len(list_term_rules(db))==1
        rule=get_term_rules('XLSMART',db)
        match=_field_evidence([{'column_name':'StnName'}],'StationName','XLSMART',obj,{},rule)
        assert match['actual']=='StnName' and match['status'] in {'BUSINESS_ALIAS_REVIEW','ABBREVIATION_ALIAS_REVIEW'},match
        print('[PASS] New abbreviation added via persistent vocabulary registry without code change')
        record_alias_decision('XLSMART',obj,'SONumber','SONumb','APPROVED','PIC_DEMO',
                              'Verified as Site Order Number in this specific view',db)
        decided=get_alias_decisions('XLSMART',db)
        approved=_field_evidence(cols,'SONumber','XLSMART',obj,decided,rule)
        assert approved['status']=='REGISTERED_ALIAS_REVIEW',approved
        # Same pair on different object/domain should not inherit scope-specific approval.
        scoped=_field_evidence(cols,'SONumber','XLSMART','another-object',decided,rule)
        assert scoped['status']=='ABBREVIATION_ALIAS_REVIEW',scoped
        assert len(list_alias_decisions(db))==1
        record_alias_decision('XLSMART',obj,'SONumber','SONumb','REJECTED','PIC_DEMO',
                              'Business validation contradicted earlier judgment',db)
        rejected=_field_evidence(cols,'SONumber','XLSMART',obj,get_alias_decisions('XLSMART',db),rule)
        assert rejected['status']=='MISSING',rejected
        try:
            record_alias_decision('XLSMART',obj,'Selection','SelectionID','APPROVED','PIC_DEMO',
                                  'Unsafe identifier equivalence',db)
        except ValueError:
            pass
        else:
            raise AssertionError('Identifier-vs-value mismatch should be blocked from alias approvals')
        print('[PASS] PIC approve/reject persists, is object-scoped and blocks unsafe ID/label approval')
    print('=== STAGE 4.1.3 ABBREVIATION & ALIAS LEARNING VALIDATION SUCCESS ===')

if __name__=='__main__': main()
