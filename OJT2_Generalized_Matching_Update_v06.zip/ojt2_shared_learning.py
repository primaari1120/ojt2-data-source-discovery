"""Read-only, domain-agnostic evidence transfer from PIC alias decisions.

Learn globally / validate locally:
- existing alias decisions remain authoritative ONLY for their own object
- OTHER objects' decisions form weak, explainable candidate-ranking evidence
- never fine-tunes an embedding, claims equivalence, overrides local rejection,
  or changes field coverage / JOIN / SQL execution permissions
- current state of each (domain, object, pair) counts once (not audit revisions)
"""
from __future__ import annotations
from collections import defaultdict
from pathlib import Path
from typing import Any

from ojt2_discovery_core import HISTORY_DB, norm

EvidenceIndex = dict[tuple[str, str], list[dict[str, str]]]


def load_shared_feedback(path: Path = HISTORY_DB) -> EvidenceIndex:
    """Load latest object-scoped decisions as a reusable in-request snapshot.

    Uses the existing persistent table; zero schema migration or history reset.
    Caller should load ONCE per discovery pass, not once per field. Works if
    older SQLite DB has no decisions yet.
    """
    from ojt2_field_matching import list_alias_decisions
    index: EvidenceIndex = defaultdict(list)
    for row in list_alias_decisions(path):
        a, b = row['requested_norm'], row['actual_norm']
        if not (a and b and row['decision'] in {'APPROVED', 'REJECTED'}):
            continue
        index[(a, b)].append({
            'domain': (row.get('domain') or 'GENERAL').upper(),
            'object_key': row['object_key'],
            'decision': row['decision'],
        })
    return dict(index)


def shared_feedback_metrics(shared: EvidenceIndex, requested: str, actual: str,
                            domain: str | None, object_key: str | None) -> dict[str, Any]:
    """Aggregate eligible evidence only; never leak other object names or reviewers."""
    if not shared:
        return {'approvals': 0, 'rejections': 0, 'same_domain_approvals': 0,
                'same_domain_rejections': 0, 'different_domain_approvals': 0,
                'different_domain_rejections': 0, 'distinct_other_domains': 0}
    this_domain = (domain or 'GENERAL').upper()
    approvals = rejections = same_approvals = same_rejections = diff_approvals = diff_rejections = 0
    other_domains = set()
    for vote in shared.get((norm(requested), norm(actual)), []):
        vote_domain = vote['domain']
        # Local approval/rejection is handled separately and has strict precedence.
        if vote_domain == this_domain and vote['object_key'] == object_key:
            continue
        other_domains.add(vote_domain)
        if vote['decision'] == 'APPROVED':
            approvals += 1
            if vote_domain == this_domain: same_approvals += 1
            else: diff_approvals += 1
        else:
            rejections += 1
            if vote_domain == this_domain: same_rejections += 1
            else: diff_rejections += 1
    return {
        'approvals': approvals, 'rejections': rejections,
        'same_domain_approvals': same_approvals,
        'same_domain_rejections': same_rejections,
        'different_domain_approvals': diff_approvals,
        'different_domain_rejections': diff_rejections,
        'distinct_other_domains': len(other_domains),
    }


def apply_shared_feedback(proposals: list[dict], columns: list[dict], requested: str,
                          *, domain: str | None = None, object_key: str | None = None,
                          decisions: dict | None = None,
                          shared: EvidenceIndex | None = None) -> list[dict]:
    """Rerank existing candidates and propose unseen names learned elsewhere.

    Rejected records from another object/domain are NEGATIVE evidence only;
    they never block an otherwise plausible candidate. Current-object rejection
    always wins and excludes that candidate. A local exact match is handled
    upstream and is never replaced by historical votes.
    """
    from ojt2_field_matching import _identifier_conflict, split_tokens, MEASUREMENT_UNITS
    if shared is None:
        shared = load_shared_feedback()
    decisions = decisions or {}
    req_norm = norm(requested)
    # Normalized text is a feedback lookup key, not a physical column identity.
    # TowerName and Tower_Name may both exist and must remain separate choices.
    existing = {p['actual']: dict(p) for p in proposals}
    req_units = set(split_tokens(requested)) & set(MEASUREMENT_UNITS)
    for col in columns:
        actual = col['column_name']
        actual_norm = norm(actual)
        if not actual_norm or actual_norm == req_norm:
            continue
        local_decision=decisions.get((object_key, req_norm, actual_norm))
        if local_decision == 'REJECTED':
            existing.pop(actual, None)
            continue
        if local_decision == 'APPROVED':
            continue  # local validation has higher precedence than any transfer
        # Transferred knowledge is NEVER permitted to override hard safety gates.
        if _identifier_conflict(requested, actual):
            continue
        col_units = set(split_tokens(actual)) & set(MEASUREMENT_UNITS)
        if req_units and col_units and req_units != col_units:
            continue
        metrics = shared_feedback_metrics(shared, requested, actual, domain, object_key)
        positive, negative = metrics['approvals'], metrics['rejections']
        if positive == 0 and negative == 0:
            continue
        current = existing.get(actual)
        if current is None and positive == 0:
            continue  # historical rejection alone must not invent a suggestion
        # Transfer is deliberately capped and remains a review signal.
        boost = min(.11, .055 * metrics['different_domain_approvals'] +
                    .075 * metrics['same_domain_approvals'])
        penalty = min(.28, .09 * metrics['different_domain_rejections'] +
                      .13 * metrics['same_domain_rejections'])
        if current is None:
            base = .69
            status = ('CROSS_DOMAIN_FEEDBACK_REVIEW'
                      if metrics['different_domain_approvals'] else 'SAME_DOMAIN_FEEDBACK_REVIEW')
            current = {'actual': actual, 'status': status, 'factor': 0.0,
                       'rank_score': base, 'evidence': 'Previously PIC-reviewed relation in another source.'}
        if current['status'] in {'REFERENCE_KEY_REVIEW', 'NAME_MATCH'}:
            continue
        # A semantic-only hit is still a hypothesis, but when cross-object PIC
        # evidence exists the visible status must identify the SHARED feedback
        # route too. Otherwise the installed model silently changes the outcome
        # from CROSS_DOMAIN_FEEDBACK_REVIEW (offline) to SEMANTIC_REVIEW (online).
        # Preserve cosine/rerank/risk fields and never make it verified.
        if current['status'] == 'SEMANTIC_REVIEW' and positive > 0:
            current['semantic_original_status'] = 'SEMANTIC_REVIEW'
            current['status'] = ('CROSS_DOMAIN_FEEDBACK_REVIEW'
                                 if metrics['different_domain_approvals']
                                 else 'SAME_DOMAIN_FEEDBACK_REVIEW')
            current['factor'] = 0.0
        current['rank_score'] = round(max(0., min(.96, float(current['rank_score']) + boost - penalty)), 3)
        current['shared_feedback'] = metrics
        current['shared_review_required'] = True
        current['evidence'] = (
            current.get('evidence', '') + ' Shared PIC knowledge: '
            f"{metrics['same_domain_approvals']} same-domain and "
            f"{metrics['different_domain_approvals']} cross-domain approval(s); "
            f"{metrics['same_domain_rejections']} same-domain and "
            f"{metrics['different_domain_rejections']} cross-domain rejection(s). "
            'These are historical signals, NOT an approval in this object. '
            + ('Conflicting feedback: verify workflow-specific meanings. ' if negative else '')
            + 'PIC must verify locally.'
        )
        current['retrieval_methods']=list(dict.fromkeys([*current.get('retrieval_methods',[]),'shared_feedback']))
        current['evidence_by_method']={**current.get('evidence_by_method',{}),
                                      'shared_feedback':current['evidence']}
        existing[actual] = current
    return sorted(existing.values(), key=lambda p: (-p['rank_score'], p['actual'].casefold()))
