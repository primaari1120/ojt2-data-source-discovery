"""Offline regression: new patterns, ambiguity, negative cases, history and integrations.

Run: python 34_validate_generalized_matching.py
No SQL, no model download, no production repository writes. Model behavior is
tested separately with 35_validate_bilingual_model.py, not claimed by this suite.
"""
from __future__ import annotations
import importlib.util
import itertools
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from ojt2_adaptive_core import _field_evidence, discover
from ojt2_field_matching import (field_suggestions, split_tokens, ordered_field_tokens,
    BASE_TERMS, record_alias_decision, get_alias_decisions, record_missing_field_correction)
from ojt2_gap_engine import _key_candidates, generalized_supporting


def columns(*names, sql_type='nvarchar'):
    return [{'column_name':n,'sql_type':sql_type} for n in names]


def mapping(requested, names, **kw):
    return _field_evidence(columns(*names),requested,None,'local|demo|dbo|Target|U',
        shared_feedback={}, **kw)


def load_file(name):
    spec=importlib.util.spec_from_file_location('test_'+name.split('_')[0],Path(__file__).with_name(name))
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fixture():
    objects=[]; all_columns=[]
    for name,names in [('Target',['POID','ContractValue','TowerName','PONumber','PONumb']),
                       ('Support',['POID','WarehouseCity']),
                       ('Unrelated',['EmployeeName','InvoiceDate'])]:
        key='local|DEMO_Test|dbo|'+name+'|U'
        objects.append({'object_key':key,'physical_server':'local','logical_server':'LOCAL_DEMO',
            'database_name':'DEMO_Test','schema_name':'dbo','object_name':name,'object_type':'U',
            'object_type_desc':'USER_TABLE','sql_definition':None})
        all_columns.extend(dict(c,object_key=key) for c in columns(*names))
    data={'objects':objects,'columns':all_columns,'edges':[]}
    explorer=load_file('11_metadata_explorer_streamlit.py')
    return data,explorer.make_index(data),explorer


class GeneralizedMatchingTests(unittest.TestCase):
    def setUp(self):
        self.model=patch('ojt2_semantic_engine.semantic_candidates',return_value=[])
        self.model.start()
        self.addCleanup(self.model.stop)

    def test_identifier_forms_across_unseen_subjects(self):
        for subject in ('PO','PR','SO','RFQ','ABC','ZX','Site','Vendor','Contract'):
            for actual in (subject+'ID',subject.upper()+'ID',subject.lower()+'id',subject+'_ID','ID'+subject):
                with self.subTest(subject=subject,actual=actual):
                    m=mapping('ID '+subject,[actual])
                    self.assertEqual(m['actual'],actual,m)
                    self.assertNotEqual(m['status'],'MISSING')
                    self.assertEqual(set(split_tokens(actual)),set(split_tokens('ID '+subject)))

    def test_bilingual_reorder_and_separator_invariance(self):
        for subject_id,subject_en in [('Tower','Tower'),('Menara','Tower'),('Pelanggan','Customer'),
                                     ('Produk','Product'),('Perusahaan','Company'),('Aset','Asset')]:
            for actual in (subject_en+'Name',subject_en.upper()+'NAME',subject_en.lower()+'name',
                           subject_en+'_Name','Name_'+subject_en,'Nama_'+subject_id):
                with self.subTest(request=subject_id,actual=actual):
                    self.assertEqual(mapping('Nama '+subject_id,[actual])['actual'],actual)

    def test_monetary_concept_not_global_value_alias(self):
        self.assertEqual(mapping('Nilai Kontrak',['ContractValue'])['actual'],'ContractValue')
        self.assertEqual(mapping('Nilai Kontrak',['ContractAmount'])['actual'],'ContractAmount')
        self.assertEqual(mapping('Nilai Kontrak',['ContractDate'])['status'],'MISSING')
        self.assertEqual(mapping('EmployeeAmount',['EmployeeValue'])['status'],'MISSING')

    def test_bundled_vocabulary_without_model_or_feedback(self):
        from ojt2_bilingual_lexicon import lexicon_status
        self.assertTrue(lexicon_status()['ready'])
        self.assertGreater(lexicon_status()['terms'],30000)
        for req,actual in [('Masa Garansi','WarrantyPeriod'),('Kelembapan Udara','AirHumidity'),
                           ('Konsumsi Bahan Bakar','FuelConsumption'),('Premi Asuransi','InsurancePremium'),
                           ('Warranty Period','MasaGaransi'),('Nama Kucing','CatName')]:
            with self.subTest(request=req,actual=actual):
                m=mapping(req,[actual])
                self.assertEqual(m['actual'],actual,m)
                self.assertEqual(m['status'],'BILINGUAL_LEXICON_REVIEW',m)

    def test_lexicon_cannot_drop_unmatched_words_or_qualifiers(self):
        for req,actual in [('Masa Garansi','WarrantyPrice'),('Kelembapan Udara','WaterTemperature'),
                           ('Premi Asuransi','InsuranceCustomer'),('Nama Kucing','DogName'),
                           ('Nilai Kontrak Sebelum','ContractValueAfter')]:
            with self.subTest(request=req,actual=actual):
                self.assertEqual(mapping(req,[actual])['status'],'MISSING')

    def test_dictionary_words_do_not_expand_to_corporate_abbreviations(self):
        self.assertEqual(mapping('Nama Kucing',['CatName'])['actual'],'CatName')
        self.assertEqual(mapping('Nama Kucing',['CategoryName'])['status'],'MISSING')

    def test_fused_evidence_preserves_both_methods_and_physical_columns(self):
        semantic=[{'actual':name,'status':'SEMANTIC_REVIEW','rank_score':.90,
                   'field_similarity':.92,'semantic_similarity':.91,
                   'semantic_risk_flags':[],'factor':0.0,'evidence':'model evidence'}
                  for name in ('TowerName','Tower_Name')]
        with patch('ojt2_semantic_engine.semantic_candidates',return_value=semantic):
            suggestions=field_suggestions(columns('TowerName','Tower_Name'),'Nama Menara',shared_feedback={})
        self.assertEqual({s['actual'] for s in suggestions},{'TowerName','Tower_Name'})
        for item in suggestions:
            self.assertEqual(set(item['retrieval_methods']),{'lexical','semantic'})
            self.assertIn('semantic',item['evidence_by_method'])
            self.assertIn('lexical',item['evidence_by_method'])
            self.assertEqual(item['field_similarity'],.92)

    def test_whole_words_do_not_invent_identifiers(self):
        for word in ('Grid','Valid','Liquid','Solid','Hybrid','Paid','Monkey','Turkey','UUID','GUID'):
            with self.subTest(word=word):
                self.assertNotIn('id',split_tokens(word))
                self.assertNotIn('key',split_tokens(word))
                self.assertEqual(mapping('Nama '+word,[word+'Name'])['actual'],word+'Name')

    def test_identifier_is_not_number_or_label(self):
        for req,col in [('ID PO','PONumber'),('Nama Tower','TowerID'),('Nilai Kontrak','ContractID'),
                        ('PO Code','POID')]:
            with self.subTest(req=req,col=col):
                m=mapping(req,[col])
                self.assertEqual(m['factor'],0)
                self.assertNotIn(m['status'],{'NAME_MATCH','BUSINESS_ALIAS_REVIEW','BILINGUAL_CONCEPT_REVIEW'})

    def test_ambiguity_is_not_missing_or_verified(self):
        for request,names in [('Nomor PO',['PONumber','PONumb']),
                              ('Nama Pelanggan',['CustomerName','NameCustomer']),
                              ('Nama Tower',['TowerName','Tower_Name'])]:
            with self.subTest(request=request):
                m=mapping(request,names)
                self.assertEqual(m['status'],'AMBIGUOUS_MATCH_REVIEW',m)
                self.assertIsNone(m['actual'])
                self.assertEqual(m['factor'],0)
                self.assertEqual({s['actual'] for s in m['suggestions']},set(names))

    def test_normalized_collision_preserves_physical_columns(self):
        m=mapping('Tower Name',['TowerName','Tower_Name'])
        self.assertEqual(m['status'],'AMBIGUOUS_MATCH_REVIEW')
        self.assertEqual(mapping('Tower_Name',['TowerName','Tower_Name'])['actual'],'Tower_Name')

    def test_negative_fields_remain_missing(self):
        for request,actual in [('Nama Kucing','ContractValue'),('InvoiceDate','WarehouseCity'),
                              ('ApprovalAmount','ApprovalDate'),('DistanceM','DistanceKM'),
                              ('StartDate','EndDate'),('NetAmount','GrossAmount')]:
            with self.subTest(request=request,actual=actual):
                self.assertEqual(mapping(request,[actual])['status'],'MISSING')

    def test_ordered_and_sorted_tokenizers_agree(self):
        for value in ('POID','Nama_Tower','ID PO','TOWERNAME','SONumb','Nama Menara'):
            self.assertEqual(tuple(sorted(ordered_field_tokens(value))),split_tokens(value))

    def test_semantic_channel_not_blocked_by_lexical_candidate(self):
        item={'actual':'ContractValue','status':'SEMANTIC_REVIEW','rank_score':.86,
              'field_similarity':.88,'semantic_risk_flags':[],'factor':0.0,'evidence':'test-only signal'}
        with patch('ojt2_semantic_engine.semantic_candidates',return_value=[item]) as semantic:
            result=field_suggestions(columns('ContractAmount','ContractValue'),'Amount Kontrak',shared_feedback={})
        self.assertTrue(semantic.called)
        self.assertEqual({r['actual'] for r in result},{'ContractAmount','ContractValue'})

    def test_multiple_semantic_candidates_retained(self):
        results=[{'actual':n,'status':'SEMANTIC_REVIEW','rank_score':s,'field_similarity':s,
                  'semantic_risk_flags':[],'factor':0.0,'evidence':'test-only signal'}
                 for n,s in [('FelineLabel',.82),('CatLabel',.81)]]
        with patch('ojt2_semantic_engine.semantic_candidates',return_value=results):
            m=mapping('Sebutan Kucing',['FelineLabel','CatLabel'])
        self.assertEqual(m['status'],'MULTIPLE_CONTEXT_OPTIONS_REVIEW')
        self.assertEqual(len(m['suggestions']),2)
        self.assertEqual(m['factor'],0)

    def test_local_history_approval_and_rejection_survive(self):
        key='local|demo|dbo|Target|U'
        with TemporaryDirectory() as temp:
            db=Path(temp)/'history.sqlite'
            record_missing_field_correction('GENERAL',key,'ID PO','POID','MISSING','tester',
                'synthetic confirmed identifier',columns('POID'),path=db)
            decisions=get_alias_decisions(None,db)
            self.assertEqual(mapping('ID PO',['POID','POIdentifier'],decisions=decisions)['status'],'REGISTERED_ALIAS_REVIEW')
            record_alias_decision('GENERAL',key,'ID PO','POID','REJECTED','tester','test reversal',path=db)
            self.assertEqual(mapping('ID PO',['POID'],decisions=get_alias_decisions(None,db))['status'],'MISSING')

    def test_discovery_explorer_and_gap_use_shared_matcher(self):
        data,index,explorer=fixture()
        from contextlib import ExitStack
        with ExitStack() as stack:
            for prefix in ('ojt2_adaptive_core','ojt2_field_matching','ojt2_gap_engine'):
                stack.enter_context(patch(prefix+'.get_alias_decisions',return_value={}))
                stack.enter_context(patch(prefix+'.get_term_rules',return_value=BASE_TERMS))
            stack.enter_context(patch('ojt2_adaptive_core.load_shared_feedback',return_value={}))
            stack.enter_context(patch('ojt2_shared_learning.load_shared_feedback',return_value={}))
            req={'purpose':'','source_hint':'','filtering':'','required_fields':['ID PO','Nilai Kontrak','Nama Tower']}
            ranked=discover(data,index,req)
            self.assertTrue(ranked)
            self.assertEqual(ranked[0]['object']['object_name'],'Target')
            self.assertEqual([m['actual'] for m in ranked[0]['field_map']],['POID','ContractValue','TowerName'])
            from ojt2_discovery_core import save_review, list_reviews
            from ojt2_adaptive_core import VERSION, RULE_VERSION
            with TemporaryDirectory() as temp:
                db=Path(temp)/'audit.sqlite'
                save_review(req,ranked[0],[],'tester','synthetic review',['DEMO_Test'],1,path=db)
                audit=list_reviews(path=db)[0]
                self.assertEqual((audit['engine_version'],audit['rule_version']),(VERSION,RULE_VERSION))
            partial=discover(data,index,dict(req,required_fields=req['required_fields']+['Nomor PO','UnicornSpeed']))
            self.assertTrue(any(r['object']['object_name']=='Target' for r in partial))
            for q,col in [('ID PO','POID'),('Nilai Kontrak','ContractValue'),('Nama Tower','TowerName')]:
                found=explorer.field_candidates(data,index,q)
                self.assertTrue(any(r['Column']==col for r in found),(q,found))
            choices=explorer.field_candidates(data,index,'Nomor PO')
            target_choices=[r for r in choices if r['ObjectKey']==data['objects'][0]['object_key']]
            self.assertEqual({r['Column'] for r in target_choices},{'PONumber','PONumb'})
            self.assertTrue(all(r['Status']=='AMBIGUOUS_MATCH_REVIEW' for r in target_choices))
            ambiguous=discover(data,index,dict(req,required_fields=['Nomor PO']))
            self.assertEqual(ambiguous[0]['field_map'][0]['status'],'AMBIGUOUS_MATCH_REVIEW')
            self.assertEqual(ambiguous[0]['coverage'],0)
            main=data['objects'][1]
            gap_req=dict(req,required_fields=['Nilai Kontrak'])
            candidate={'object':main,'field_map':[mapping('Nilai Kontrak',['WarehouseCity'])]}
            suggestions=generalized_supporting(data,index,candidate,gap_req)
            self.assertTrue(any(s['actual_field']=='ContractValue' for s in suggestions))

    def test_join_keys_still_require_type_and_identifier_compatibility(self):
        keys=_key_candidates(columns('ID_PO',sql_type='int'),columns('POID',sql_type='int'),None,BASE_TERMS,{},'target')
        self.assertEqual(keys[0]['support_column'],'POID')
        self.assertEqual(keys[0]['status'],'PROPOSED_JOIN_KEY_NOT_VERIFIED')
        self.assertFalse(_key_candidates(columns('ID_PO',sql_type='int'),columns('POID',sql_type='nvarchar'),None,BASE_TERMS,{},'target'))


if __name__=='__main__':
    unittest.main(verbosity=2)
